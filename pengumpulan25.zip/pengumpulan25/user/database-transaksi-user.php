<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="\public_html\imgs\lobaz.png" type="image/x-icon">
    <title>BAZNAS SUMBAWA</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">


    <style>
    table {
        border-collapse: collapse;
        width: 90%;
        font-size: 14px;
        margin-left: auto;
        margin-right: auto;
    }

    th,
    td {
        text-align: center;
        padding: 10px;
        text-transform: uppercase;
    }

    th {
        background-color: #fff;
        color: black;
        text-transform: uppercase;
    }

    td {
        text-align: left;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #ddd;
    }

    /* Mengatur style untuk tombol tambah dan edit */
    .btn {
        padding: 6px 12px;
        text-align: center;
        text-decoration: none;
        font-size: 14px;
        margin: 4px 2px;
        cursor: pointer;
    }

    /* Mengatur style untuk tombol tambah */
    .btn-add {
        background-color: #5cb85c;
        border: none;
        color: white;
    }

    /* Mengatur style untuk tombol edit */
    .btn-edit {
        background-color: #f0ad4e;
        border: none;
        color: white;
    }

    /* Mengatur style untuk tombol keluar */
    .btn-exit {
        background-color: #d9534f;
        border: none;
        color: white;
    }

    .hidden-button {
        position: absolute;
        top: -9999px;
        left: -9999px;
    }

    h2 {
        text-align: center;
    }

    .kecilkan {
        font-size: 15px;
        margin-left: 35px;
        margin-top: -10px;
    }

    /* Responsif menggunakan Bootstrap */
    @media (max-width: 576px) {
        table {
            width: 100%;
        }

        .kecilkan {
            font-size: 12px;
            margin-left: 10px;
            margin-top: -5px;
        }
    }


        /* membuat button melayang, untuk melihat halaman paling bawah
        * ini tidak dugunakan karena sudah ada solusi lain
        .floating-button {
            position: fixed;
            bottom: 150px;
            right: 50px;
            z-index: 999;
            transition: transform 0.3s ease-in-out;
        }

        .floating-button:hover {
            transform: scale(1.1);
        }
        */
    </style>
</head>


<body>
    <?php include 'navbar.php'; ?>


    <h2>DATABASE TRANSAKSI</h2>
    <form action="database-transaksi-user.php" method="POST" style="margin-left: 40px; margin-right: 90px;">
        <div class="form-group">
            <label for="nama_muzaki">Nama Dinas/Instansi/Sekolah/dll:</label>
            <input placeholder="masukan nama Dinas/Instansi dll disini" type="text" class="form-control" id="nama_muzaki" name="nama_muzaki" accesskey="n">
        </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" name="submit" accesskey="f">Filter</button>
        </div>
    </form>
    <div class="container" style="width: 95%;">
        <div class="row">
            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th style="width: 20%;">Nama</th>
                    <th style="width: 10%;">Status</th>
                    <th>NIM</th>
                    <th>No TrX</th>
                    <th>Jumlah</th>
                    <th>K/D</th>
                    <th style="width: 15%;">Tanggal</th>
                    <th style="width: 20%;">Pembayaran</th>
                    <th style="width: 15%;">Metode</th>
                    <th style="width: 20%;">Sumber Rek</th>
                    <th>Aksi</th>
                </tr>
                <?php

                include 'koneksi.php';

                // Mendapatkan halaman yang ditampilkan
                $page = isset($_GET['page']) ? $_GET['page'] : 1;
                $results_per_page = 24; // Jumlah data per halaman
                $start_limit = ($page - 1) * $results_per_page;

                // Mengambil data dengan query dan limit
                if (isset($_POST['submit'])) {
                    $nama_muzaki = $_POST['nama_muzaki'];
                    // Melakukan query dengan filter
                    $sql = "SELECT * FROM zakat_infaq WHERE nama_muzaki LIKE '%$nama_muzaki%' LIMIT $start_limit, $results_per_page";
                } else {
                    // Melakukan query tanpa filter
                    $sql = "SELECT * FROM zakat_infaq ORDER BY tanggal DESC LIMIT $start_limit, $results_per_page";
                }
                $hasil = $koneksi->query($sql);
                $no = $start_limit + 1;
                if ($hasil->num_rows > 0) {
                    foreach ($hasil as $row) { ?>
                        <tr>
                            <td>
                                <?php echo $no; ?>
                            </td>
                            <td>
                                <?php echo $row['nama_muzaki']; ?>
                            </td>
                            <td>
                                <?php echo $row['status_muzaki']; ?>
                            </td>
                            <td>
                                <?php echo $row['nomor_induk_muzaki']; ?>
                            </td>
                            <td>
                                <?php echo $row['nomor_transaksi']; ?>
                            </td>
                            <td>
                                <?php echo number_format($row['jumlah'], 2, ',', '.'); ?>
                            </td>
                            <td>
                                <?php echo $row['kredit_debit']; ?>
                            </td>
                            <td>
                                <?php echo $row['tanggal']; ?>
                            </td>
                            <td>
                                <?php echo $row['pembayaran']; ?>
                            </td>
                            <td>
                                <?php echo $row['metode_bayar']; ?>
                            </td>
                            <td>
                                <?php echo $row['sumber_rekening']; ?>
                            </td>
                            <?php echo "<td><a href='#kwitansiModal' class='btn btn-danger' id_muzaki='id' data-toggle='modal' data-id=" . $row['id_muzaki'] . " title='Kwitansi'>K</a></td>"; ?>
                        </tr>
                        <?php
                        $no++;
                    }
                } else {
                    echo "0 results";
                }

                // Mengambil total halaman
                $sql_total = "SELECT COUNT(*) AS total FROM zakat_infaq";
                $total_pages = ceil($koneksi->query($sql_total)->fetch_assoc()['total'] / $results_per_page);

                $koneksi->close();
                ?>
            </table>

            <!-- Tombol Next dan Previous -->
            <div class="text-center">
                <?php
                if ($page > 1) {
                    $prev_page = $page - 1;
                    echo "<a href='?page=$prev_page' class='btn btn-default'>Previous</a>";
                }

                if ($page < $total_pages) {
                    $next_page = $page + 1;
                    echo "<a href='?page=$next_page' class='btn btn-default'>Next</a>";
                }
                ?>
            </div>

            Perhatian : <br>
            Untuk mencari data nama muzaki mohon gunakan (Alt+Z)


        </div>
        

        <!-- Modal Trigger Button -->
        <button type="button" class="hidden-button" data-toggle="modal" data-target="#filterModal" accesskey="z">Filter
            (Ctrl + Z)</button>

        <!-- Modal -->
        <div class="modal fade" id="filterModal" tabindex="-1" role="dialog" aria-labelledby="filterModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="filterModalLabel">Filter Nama Muzaki</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="lihat_data.php" method="POST">
                            <div class="form-group">
                                <label for="nama_muzaki">Nama Muzaki:</label>
                                <input type="text" class="form-control" id="nama_muzaki" name="nama_muzaki"
                                    accesskey="n">
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" name="submit" accesskey="f">Filter</button>
                        <button type="button" class="btn btn-primary" data-toggle="modal"
                            data-target="#tambahDataModal">
                            Tambah Data Baru
                        </button>

                    </div>
                    </form>
                </div>
            </div>
        </div>



        <!-- Button untuk membuka modal -->
        <button type="button" class="hidden-button" data-toggle="modal" data-target="#myModal3" accesskey="q">
            Buka Modal
        </button>

        <!-- Modal -->
        <div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <h4 class="modal-title" id="myModalLabel">Navigation Menu</h4>
                    </div>
                    <div class="modal-body">
                        <ul class="nav">
                            <li><a href="rekap_data_infaq.php">Rekap Infaq</a></li>
                            <li><a href="page2.html">Halaman 2</a></li>
                            <li><a href="page3.html">Halaman 3</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Tambah Data Baru -->
        <div class="modal fade" id="tambahDataModal" tabindex="-1" role="dialog" aria-labelledby="tambahDataModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="tambahDataModalLabel">Form Tambah Data Zakat dan Infaq</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="proses_tambah_data.php">
                            <label>Nama Muzaki/UPZ:</label>
                            <input type="text" name="nama_muzaki" required class="form-control">
                            <label>Status Muzaki:</label>
                            <select name="status_muzaki" class="form-control">
                                <option value="Perorangan">Perorangan</option>
                                <option value="Dinas Instansi">Dinas Instansi</option>
                                <option value="BANK">BANK</option>
                                <option value="BUMN">BUMN</option>
                                <option value="BUMD">BUMD</option>
                                <option value="Sekolah">Sekolah</option>
                                <option value="A/N">A/N</option>
                            </select>
                            <label>Nomor Induk Muzaki:</label>
                            <input class="form-control" type="text" name="nomor_induk_muzaki" id="nomor_induk_muzaki"
                                onclick="fillRandomNumber()" pattern="[0-9]{12}" maxlength="12" required>
                            <label>Nomor Transaksi:</label>
                            <input class="form-control" type="text" name="nomor_transaksi" id="nomor_transaksi"
                                onclick="fillRandomNumber()" pattern="[0-9]{7}" maxlength="7" required>
                            <label>Jumlah:</label>
                            <input class="form-control" type="number" name="jumlah" pattern="[0-9]+([,.][0-9]{0,2})?"
                                required>
                            <label>Kredit/Debit:</label>
                            <select name="kredit_debit" class="form-control">
                                <option value="Kredit">Kredit</option>
                                <option value="Debit">Debit</option>
                            </select>
                            <label>Tanggal:</label>
                            <input class="form-control" type="date" name="tanggal" required>
                            <label>Pembayaran:</label>
                            <select name="pembayaran" class="form-control">
                                <option value="Zakat">Zakat</option>
                                <option value="Infaq dan Shadaqoh">Infaq dan Shadaqoh</option>
                            </select>
                            <label>Metode Bayar:</label>
                            <select name="metode_bayar" class="form-control">
                                <option value="Tunai">Tunai</option>
                                <option value="Transfer Bank">Transfer Bank</option>
                            </select>
                            <label>Sumber Rekening:</label>
                            <select class="form-control" name="sumber_rekening">
                                <option value="BNTB SYARIAH ZAKAT">BNTB SYARIAH ZAKAT</option>
                                <option value="BNTB SYARIAH INFAQ">BNTB SYARIAH INFAQ</option>
                                <option value="NO. REK APBD">NO. REK APBD</option>
                                <option value="BNTB SYARIAH PROVINSI 019">BNTB SYARIAH PROVINSI 019</option>
                                <option value="BANK BSI SYARIAH">BANK BSI SYARIAH</option>
                            </select><br>
                            <input type="submit" value="Simpan" class="btn btn-primary" accesskey="s">
                            <input type="reset" value="Reset" class="btn btn-primary">
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Batal</button>
                        </form>
                        <script type="text/javascript">
                            function generateRandomNumber() {
                                var randomNumber = Math.floor(Math.random() * 1000000000000);
                                return randomNumber.toString().padStart(12, '0');
                            }

                            function fillRandomNumber() {
                                var nomorIndukMuzaki = document.getElementById("nomor_induk_muzaki");
                                var nomorTransaksi = document.getElementById("nomor_transaksi");

                                nomorIndukMuzaki.value = generateRandomNumber();
                                nomorTransaksi.value = generateRandomNumber().substr(0, 7);
                            }
                        </script>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Konfirmasi Hapus -->
    <div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="confirmModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmModalLabel">Konfirmasi Hapus Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Apakah Anda yakin ingin menghapus data ini?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-danger" id="hapusButton">Hapus</button>
                </div>
            </div>
        </div>
    </div>


    <!-- buton menuju paling bawah
    <div class="floating-button">
        <a href="#bottom" class="btn btn-primary">V</a>
    </div>
    </div>

    </div>
    </div>

    <div id="bottom"></div>
     -->


    <!-- Modal tamah data berdasarkan id -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Tambah Transaksi</h4>
                </div>
                <div class="modal-body">
                    <div class="fetched-data"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal edit data berdasarkan id -->
    <div class="modal fade" id="myModal1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Edit Transaksi</h4>
                </div>
                <div class="modal-body">
                    <div class="fetched-data"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal Kwitansi berdasarkan id -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.0/jspdf.umd.min.js"></script>
    <div class="modal fade" id="kwitansiModal" tabindex="-1" role="dialog" aria-labelledby="kwitansiModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="kwitansiModalLabel">Kwitansi Transaksi ZIS</h4>
                </div>
                <div class="modal-body">
                    <!-- Kwitansi content will be inserted here dynamically -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                    <button type="button" class="btn btn-primary" id="cetakButton">Cetak</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#myModal').on('show.bs.modal', function (e) {
                var rowid = $(e.relatedTarget).data('id');
                //menggunakan fungsi ajax untuk pengambilan data
                $.ajax({
                    type: 'post',
                    url: 'detail-simpan.php',
                    data: 'rowid=' + rowid,
                    success: function (data) {
                        $('.fetched-data').html(data); //menampilkan data ke dalam modal
                    }
                });
            });
        });
    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#myModal1').on('show.bs.modal', function (e) {
                var rowid = $(e.relatedTarget).data('id');
                //menggunakan fungsi ajax untuk pengambilan data
                $.ajax({
                    type: 'post',
                    url: 'detail-edit.php',
                    data: 'rowid=' + rowid,
                    success: function (data) {
                        $('.fetched-data').html(data); //menampilkan data ke dalam modal
                    }
                });
            });
        });
    </script>

    <script>
        // Handle modal show event
        $('#kwitansiModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var id = button.data('id'); // Extract data-id attribute from button
            var modal = $(this);

            // Redirect to kwitansi.php with the ID parameter
            var redirectUrl = 'kwitansi-user.php?id=' + id;
            window.location.href = redirectUrl;
        });
    </script>

    <script>
        $(document).ready(function () {
            // Tampilkan modal konfirmasi hapus saat tombol hapus-data diklik
            $('.hapus-data').on('click', function () {
                var id = $(this).data('id');
                $('#hapusButton').data('id',
                    id); // Simpan ID data yang akan dihapus di atribut data-id pada tombol hapus

                $('#confirmModal').modal('show');
            });

            // Handle tombol hapus di dalam modal konfirmasi hapus
            $('#hapusButton').on('click', function () {
                var id = $(this).data('id');

                // Lakukan proses hapus data sesuai dengan ID yang didapatkan
                hapusData(id);

                // Sembunyikan modal konfirmasi hapus
                $('#confirmModal').modal('hide');
            });

            // Fungsi hapusData untuk mengirim permintaan AJAX untuk menghapus data
            function hapusData(id) {
                // Lakukan permintaan AJAX untuk menghapus data dengan menggunakan ID
                $.ajax({
                    url: 'proses_hapus_data.php', // Ubah dengan URL yang sesuai untuk menghapus data
                    method: 'POST',
                    data: {
                        id: id
                    },
                    success: function (response) {
                        // Lakukan tindakan sesuai dengan respons dari server setelah data berhasil dihapus
                        console.log(response);
                        // Misalnya, refresh halaman atau hapus baris data dari tabel
                        window.location.reload(); // Refresh halaman
                    },
                    error: function (xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            }
        });
    </script>


    <script type="text/javascript">
        function generateRandomNumber() {
            var randomNumber = Math.floor(Math.random() * 1000000000000);
            return randomNumber.toString().padStart(12, '0');
        }

        function fillRandomNumber() {
            var nomorIndukMuzaki = document.getElementById("nomor_induk_muzaki");
            var nomorTransaksi = document.getElementById("nomor_transaksi");

            nomorIndukMuzaki.value = generateRandomNumber();
            nomorTransaksi.value = generateRandomNumber().substr(0, 7);
        }
    </script>

    </div>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous">
        </script>

</body><br><br><br><br><br><br><br>


</html>