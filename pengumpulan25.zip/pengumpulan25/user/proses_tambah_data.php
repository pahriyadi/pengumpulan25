<?php
// Memeriksa apakah permintaan dikirimkan melalui metode POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mengambil nilai yang dikirimkan melalui form
    $nama_upz = $_POST['nama_upz'];
    $nomor_induk_upz = $_POST['nomor_induk_upz'];
    $alamat_upz = $_POST['alamat_upz'];
    $email_upz = $_POST['email_upz'];

    // Validasi data (contoh: memastikan semua field diisi)
    if (empty($nama_upz) || empty($nomor_induk_upz) || empty($alamat_upz) || empty($email_upz)) {
        echo "Harap lengkapi semua field!";
        exit;
    }

    // Koneksi ke database
    include 'koneksi.php';

    // Melakukan sanitasi input
    $nama_upz = mysqli_real_escape_string($koneksi, $nama_upz);
    $nomor_induk_upz = mysqli_real_escape_string($koneksi, $nomor_induk_upz);
    $alamat_upz = mysqli_real_escape_string($koneksi, $alamat_upz);
    $email_upz = mysqli_real_escape_string($koneksi, $email_upz);

    // Membuat query untuk menyimpan data ke dalam database
    $query = "INSERT IGNORE INTO registrasi_upz (nama_upz, nomor_induk_upz, alamat_upz, email_upz) VALUES ('$nama_upz', '$nomor_induk_upz', '$alamat_upz', '$email_upz')";

    if ($koneksi->query($query) === TRUE) {
        header('Location: /pengumpulan/user/dashboard-user.php');
    } else {
        echo "Terjadi kesalahan saat menyimpan data: " . $koneksi->error;
    }

    // Menutup koneksi ke database
    $koneksi->close();
}
?>
