<?php
session_start();

// Hapus semua data sesi
session_destroy();

// Redirect ke halaman login
header("Location: /ozakat/pengumpulan/user/login-upz.php");
exit();
?>
