<?php
session_start();

include 'koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = $koneksi->query($sql);

if ($result->num_rows == 1) {
    $_SESSION['username'] = $username;
    header("Location: /pengumpulan/user/dashboard-user.php");
    exit();
} else {
    echo "Username atau password salah.";
}

$koneksi->close();
?>
