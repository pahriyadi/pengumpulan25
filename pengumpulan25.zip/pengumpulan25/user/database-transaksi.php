<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="\public_html\imgs\lobaz.png" type="image/x-icon">
    <title>BAZNAS SUMBAWA</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


    <style>
        table {
            border-collapse: collapse;
            width: 90%;
            font-size: 14px;
            margin-left: auto;
            margin-right: auto;
        }

        th,
        td {
            text-align: center;
            padding: 10px;
            text-transform: uppercase;
        }

        th {
            background-color: #fff;
            color: black;
            text-transform: uppercase;
        }

        td {
            text-align: left;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        /* Mengatur style untuk tombol tambah dan edit */
        .btn {
            background-color: #3E8DA8;
            border: none;
            color: white;
            padding: 6px 12px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
        }

        /* Mengatur style untuk tombol tambah */
        .btn-add {
            background-color: #5cb85c;
        }

        /* Mengatur style untuk tombol edit */
        .btn-edit {
            background-color: #f0ad4e;
        }

        /* Mengatur style untuk tombol keluar */
        .btn-exit {
            background-color: #d9534f;
        }


        .hidden-button {
            position: absolute;
            top: -9999px;
            left: -9999px;
        }

        h2 {
            text-align: center;
        }

        .kecilkan {
            font-size: 15px;
            margin-left: 35px;
            margin-top: -10px;

        }

        /* membuat button melayang, untuk melihat halaman paling bawah
        * ini tidak dugunakan karena sudah ada solusi lain
        .floating-button {
            position: fixed;
            bottom: 150px;
            right: 50px;
            z-index: 999;
            transition: transform 0.3s ease-in-out;
        }

        .floating-button:hover {
            transform: scale(1.1);
        }
        */
    </style>
</head>


<body>


    <h2>DATABASE TRANSAKSI</h2>
    <div class="container" style="width: 95%;">
        <div class="row">
            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th style="width: 20%;">Nama</th>
                    <th style="width: 10%;">Status</th>
                    <th>NIM</th>
                    <th>No TrX</th>
                    <th>Jumlah</th>
                    <th>K/D</th>
                    <th style="width: 15%;">Tanggal</th>
                    <th style="width: 20%;">Pembayaran</th>
                    <th style="width: 15%;">Metode</th>
                    <th style="width: 20%;">Sumber Rek</th>
                </tr>
                <?php
                
                include 'koneksi.php';

                // Mendapatkan halaman yang ditampilkan
                $page = isset($_GET['page']) ? $_GET['page'] : 1;
                $results_per_page = 10; // Jumlah data per halaman
                $start_limit = ($page - 1) * $results_per_page;

                // Mengambil data dengan query dan limit
                if (isset($_POST['submit'])) {
                    $nama_muzaki = $_POST['nama_muzaki'];
                    // Melakukan query dengan filter
                    $sql = "SELECT * FROM zakat_infaq WHERE nama_muzaki LIKE '%$nama_muzaki%' LIMIT $start_limit, $results_per_page";
                } else {
                    // Melakukan query tanpa filter
                    $sql = "SELECT * FROM zakat_infaq ORDER BY tanggal DESC LIMIT $start_limit, $results_per_page";
                }
                $hasil = $koneksi->query($sql);
                $no = $start_limit + 1;
                if ($hasil->num_rows > 0) {
                    foreach ($hasil as $row) { ?>
                        <tr>
                            <td>
                                <?php echo $no; ?>
                            </td>
                            <td>
                                <?php echo $row['nama_muzaki']; ?>
                            </td>
                            <td>
                                <?php echo $row['status_muzaki']; ?>
                            </td>
                            <td>
                                <?php echo $row['nomor_induk_muzaki']; ?>
                            </td>
                            <td>
                                <?php echo $row['nomor_transaksi']; ?>
                            </td>
                            <td>
                                <?php echo number_format($row['jumlah'], 2, ',', '.'); ?>
                            </td>
                            <td>
                                <?php echo $row['kredit_debit']; ?>
                            </td>
                            <td>
                                <?php echo $row['tanggal']; ?>
                            </td>
                            <td>
                                <?php echo $row['pembayaran']; ?>
                            </td>
                            <td>
                                <?php echo $row['metode_bayar']; ?>
                            </td>
                            <td>
                                <?php echo $row['sumber_rekening']; ?>
                            </td>
                        </tr>
                        <?php
                        $no++;
                    }
                } else {
                    echo "0 results";
                }

                // Mengambil total halaman
                $sql_total = "SELECT COUNT(*) AS total FROM zakat_infaq";
                $total_pages = ceil($koneksi->query($sql_total)->fetch_assoc()['total'] / $results_per_page);

                $koneksi->close();
                ?>
            </table>

            <!-- Tombol Next dan Previous -->
            <div class="text-center">
                <?php
                if ($page > 1) {
                    $prev_page = $page - 1;
                    echo "<a href='?page=$prev_page' class='btn btn-default'>Previous</a>";
                }

                if ($page < $total_pages) {
                    $next_page = $page + 1;
                    echo "<a href='?page=$next_page' class='btn btn-default'>Next</a>";
                }
                ?>
            </div>
            <a href="dashboard-user.php" class="btn btn-default" style="margin-left: 1200px;">< Home</a><br>

            Perhatian : <br>
            Untuk mencari data nama muzaki mohon gunakan (Alt+Z)


        </div>

        <!-- Modal Trigger Button -->
        <button type="button" class="hidden-button" data-toggle="modal" data-target="#filterModal" accesskey="z">Filter
            (Ctrl + Z)</button>

        <!-- Modal -->
        <div class="modal fade" id="filterModal" tabindex="-1" role="dialog" aria-labelledby="filterModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="filterModalLabel">Filter Nama Muzaki</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="database-transaksi.php" method="POST">
                            <div class="form-group">
                                <label for="nama_muzaki">Nama Muzaki:</label>
                                <input type="text" class="form-control" id="nama_muzaki" name="nama_muzaki"
                                    accesskey="n">
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" name="submit" accesskey="f">Filter</button>

                    </div>
                    </form>
                </div>
            </div>
        </div>


    </div>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous">
        </script>
        

</body>

</html>