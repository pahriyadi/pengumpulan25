<?php
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location:/pengumpulan/user/login-upz.php");
    exit();
}

// Dapatkan username pengguna dari sesi
$username = $_SESSION['username'];

// Dapatkan data yang diinputkan dari form
$nomor_induk_muzaki = $_POST['nomor_induk_muzaki'];
$namaMuzaki = $_POST['nama_muzaki'];
$notlp_muzaki = $_POST['notlp_muzaki'];
$status_muzaki = $_POST['status_muzaki'];

// Koneksi ke basis data
include 'koneksi.php';

// Query untuk menambahkan data upz baru
$sql = "INSERT INTO muzaki (username,  nomor_induk_muzaki, nama_muzaki, notlp_muzaki, status_muzaki) VALUES ('$username', '$nomor_induk_muzaki', '$namaMuzaki', '$notlp_muzaki','$status_muzaki')";

if ($koneksi->query($sql) === TRUE) {
    header("Location: /pengumpulan/user/dashboard-user.php");
} else {
    echo "Error: " . $sql . "<br>" . $koneksi->error;
}

$koneksi->close();
?>
