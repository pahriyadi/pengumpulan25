<?php
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: /pengumpulan/user/login-upz.php");
    exit();
}

// Dapatkan username pengguna dari sesi
$username = $_SESSION['username'];

// Dapatkan data yang diinputkan dari form
$namaUpz = $_POST['nama_upz'];
$nomor_induk_upz = $_POST['nomor_induk_upz'];
$alamat_upz = $_POST['alamat_upz'];
$notlp_upz = $_POST['notlp_upz'];

// Koneksi ke basis data
include 'koneksi.php';

// Query untuk menambahkan data upz baru
$sql = "INSERT INTO upz (username, nama_upz, nomor_induk_upz, alamat_upz, notlp_upz) VALUES ('$username', '$namaUpz', '$nomor_induk_upz', '$alamat_upz', '$notlp_upz')";

if ($koneksi->query($sql) === TRUE) {
    header("Location: /pengumpulan/user/dashboard-user.php");
} else {
    echo "Error: " . $sql . "<br>" . $koneksi->error;
}

$koneksi->close();
?>
