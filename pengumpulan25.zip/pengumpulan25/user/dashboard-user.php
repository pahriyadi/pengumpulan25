<?php
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: /pengumpulan/user/login-upz.php");
    exit();
}

// Dapatkan username pengguna dari sesi
$username = $_SESSION['username'];

// Koneksi ke basis data
include 'koneksi.php';

// Cek koneksi ke basis data
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Dapatkan data pengguna berdasarkan username
$sql = "SELECT * FROM upz WHERE username = '$username'";
$result = $koneksi->query($sql);

?>

<!DOCTYPE html>
<html>

<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- CSS Bootstrap responsif -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">
    <style>
        body {
            padding: 20px;
        }

        .data-upz {
            margin-bottom: 20px;
        }

        .add-upz-form {
            margin-top: 20px;
        }

        .container {
            margin-top: 5px;
        }

        /* Responsif di perangkat dengan lebar maksimum 768px */
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }

            .data-upz {
                margin-bottom: 10px;
            }

            .add-upz-form {
                margin-top: 10px;
            }

            .container {
                margin-top: 2px;
            }
        }

        /* Responsif di perangkat dengan lebar maksimum 576px */
        @media (max-width: 576px) {
            body {
                padding: 5px;
            }

            .data-upz {
                margin-bottom: 5px;
            }

            .add-upz-form {
                margin-top: 5px;
            }

            .container {
                margin-top: 1px;
            }
        }
    </style>

</head>
<?php include 'navbar.php'; ?>

<body>
    <div class="container">
        <h3 style="text-align: center; "><?php echo "Selamat Datang " . $username . ". Di Dashboar Anda."; ?></h3>
        <div class="card">
            <div class="card-header">Data UPZ <?php echo " " . $username . ". "; ?> </div>
            <div class="card-body">
                <div class="data-upz">

                    <?php if ($result && $result->num_rows > 0) : ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nomor Induk UPZ</th>
                                    <th scope="col">Nama UPZ</th>
                                    <th scope="col">Alamat UPZ</th>
                                    <th scope="col">No Telp/WA</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php while ($row = $result->fetch_assoc()) : ?>
                                    <tr>
                                        <th scope="row"><?php echo $i; ?></th>
                                        <td><?php echo $row["nomor_induk_upz"]; ?></td>
                                        <td><?php echo $row["nama_upz"]; ?></td>
                                        <td><?php echo $row["alamat_upz"]; ?></td>
                                        <td><?php echo $row["notlp_upz"]; ?></td>
                                        <td>
                                            <a href="hapus_data_upz.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Hapus</a>
                                        </td>

                                    </tr>
                                    <?php $i++; ?>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else : ?>
                        <div class="alert alert-warning" role="alert">
                            Tidak ada data UPZ untuk pengguna ini.
                        </div>
                    <?php endif; ?>

                    <div class="add-upz-form">
                        <?php if ($result && $result->num_rows > 0) : ?>
                            <button style="background-color: red;" type="button" class="btn btn-primary" disabled title="hapus data UPZ terlebih dahulu, untuk menambah data baru">Data Sudah Cukup Terisi</button>
                        <?php else : ?>
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahDataModal">Tambah Data UPZ</button>
                        <?php endif; ?>

                        <p style="color: red; text-align: center;">
                            <?php echo $username . ". Anda hanya diperbolehkan menambahkan satu data saja."; ?>
                        </p>
                    </div>
                </div>
            </div>


            <!-- Modal Tambah Data -->
            <div class="modal fade" id="tambahDataModal" tabindex="-1" role="dialog" aria-labelledby="tambahDataModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="tambahDataModalLabel">Tambah Data UPZ</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="process_tambah_upz.php" method="POST">
                                <div class="form-group">
                                    <label for="nama_upz">Nama UPZ:</label>
                                    <input type="text" class="form-control" id="nama_upz" name="nama_upz" required>
                                </div>
                                <div class="form-group">
                                    <label for="nomor_induk_upz">Nomor Induk UPZ:</label>
                                    <input type="text" class="form-control" id="nomor_induk_upz" name="nomor_induk_upz" onclick="fillRandomNumber()" pattern="[0-9]{12}" maxlength="12" placeholder="klik untuk mendapatkan Nomor Induk UPZ Anda" required>
                                </div>
                                <div class="form-group">
                                    <label for="alamat_upz">Alamat UPZ:</label>
                                    <input type="text" class="form-control" id="alamat_upz" name="alamat_upz" required>
                                </div>
                                <div class="form-group">
                                    <label for="notlp_upz">Nomor Telp/WA:</label>
                                    <input type="text" class="form-control" id="notlp_upz" name="notlp_upz" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <script type="text/javascript">
                function generateRandomNumber() {
                    var randomNumber = Math.floor(Math.random() * 1000000000000);
                    return randomNumber.toString().padStart(12, '0');
                }

                function fillRandomNumber() {
                    var nomorIndukUpz = document.getElementById("nomor_induk_upz");
                    nomorIndukUpz.value = generateRandomNumber();
                }
            </script>


            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
            <!-- JavaScript Bootstrap (Bundle) -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        </div>
    </div>
</body>
<?php
$koneksi->close();
?>
</html>
<hr>



<!------------------------------------------------------------------------------ halaman tambah pengurus upz ------------------------------------------------>
<!------------------------------------------------------------------------------ halaman tambah pengurus upz ------------------------------------------------>

<?php

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: /pengumpulan/user/login-upz.php");
    exit();
}

// Dapatkan username pengguna dari sesi
$username = $_SESSION['username'];

// Koneksi ke basis data
include 'koneksi.php';

// Cek koneksi ke basis data
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Dapatkan data pengguna berdasarkan username
$sql = "SELECT * FROM pengurus_upz WHERE username = '$username'";
$result = $koneksi->query($sql);

?>

<!DOCTYPE html>
<html>

<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- CSS Bootstrap responsif -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">
    <style>
        body {
            padding: 20px;
        }

        .data-upz {
            margin-bottom: 20px;
        }

        .add-upz-form {
            margin-top: 20px;
        }

        .container {
            margin-top: 5px;
        }

        /* Responsif di perangkat dengan lebar maksimum 768px */
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }

            .data-upz {
                margin-bottom: 10px;
            }

            .add-upz-form {
                margin-top: 10px;
            }

            .container {
                margin-top: 2px;
            }
        }

        /* Responsif di perangkat dengan lebar maksimum 576px */
        @media (max-width: 576px) {
            body {
                padding: 5px;
            }

            .data-upz {
                margin-bottom: 5px;
            }

            .add-upz-form {
                margin-top: 5px;
            }

            .container {
                margin-top: 1px;
            }
        }
    </style>

</head>

<body>
    <div class="container">
        <div class="card">
            <div class="card-header">Data Pengurus UPZ <?php echo " " . $username . ". "; ?> </div>
            <div class="card-body">
                <div class="data-upz">

                    <?php if ($result && $result->num_rows > 0) : ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nama Pengurus</th>
                                    <th scope="col">Jabatan</th>
                                    <th scope="col">Nomor Hp/WA</th>
                                    <th scope="col">Alamat</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php while ($row = $result->fetch_assoc()) : ?>
                                    <tr>
                                        <th scope="row"><?php echo $i; ?></th>
                                        <td><?php echo $row["nama_pengurus_upz"]; ?></td>
                                        <td><?php echo $row["jabatan_pengurus_upz"]; ?></td>
                                        <td><?php echo $row["notlp_pengurus_upz"]; ?></td>
                                        <td><?php echo $row["alamat_pengurus_upz"]; ?></td>
                                        <td>
                                            <a href="hapus_data_pengurus_upz.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Hapus</a>
                                        </td>

                                    </tr>
                                    <?php $i++; ?>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else : ?>
                        <div class="alert alert-warning" role="alert">
                            Tidak ada data Pengurus UPZ untuk pengguna ini.
                        </div>
                    <?php endif; ?>

                    <p style="color: red; text-align: center;">
                        <?php echo $username . ". Anda hanya diperbolehkan menambahkan 7 (tujuh) data saja."; ?>
                    </p>
                    <div class="add-upz-form">
                        <?php if ($result && $result->num_rows > 6) : ?>
                            <button style="background-color: red;" type="button" class="btn btn-primary" disabled title="hapus data UPZ terlebih dahulu, untuk menambah data baru">Data Sudah Cukup Terisi</button>
                        <?php else : ?>
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahDataModalUpz">Tambah Data Pengurus UPZ</button>
                        <?php endif; ?>
                    </div><br>
                </div>



                <!-- Modal Tambah Data -->
                <div class="modal fade" id="tambahDataModalUpz" tabindex="-1" role="dialog" aria-labelledby="tambahDataModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahDataModalLabel">Tambah Data Pengurus UPZ</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="process_tambah_pengurus_upz.php" method="POST">
                                    <div class="form-group">
                                        <label for="nama_pengurus_upz">Nama Lengkap:</label>
                                        <input type="text" class="form-control" id="nama_pengurus_upz" name="nama_pengurus_upz" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="jabatan_pengurus_upz">Jabatan Pada UPZ:</label>
                                        <select name="jabatan_pengurus_upz" class="form-control">
                                            <option value="ketua">Ketua</option>
                                            <option value="Sekretaris">Sekretaris</option>
                                            <option value="Bendahara">Bendahara</option>
                                            <option value="Anggota 1">Anggota I</option>
                                            <option value="Anggota 2">Anggota II</option>
                                            <option value="Anggota 3">Anggota III</option>
                                            <option value="Anggota 4">Anggota IV</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="notlp_pengurus_upz">Nomor HP/WA Aktif:</label>
                                        <input type="text" class="form-control" id="notlp_pengurus_upz" name="notlp_pengurus_upz" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="alamat_pengurus_upz">Alamat Pengurus:</label>
                                        <input type="text" class="form-control" id="alamat_pengurus_upz" name="alamat_pengurus_upz" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


                <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
                <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
                <!-- JavaScript Bootstrap (Bundle) -->
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
            </div>
        </div>
    </div>
</body>
</html>
<hr>



<!------------------------------------------------------------------------------ halaman tambah pengurus upz ------------------------------------------------>
<!------------------------------------------------------------------------------ halaman tambah pengurus upz ------------------------------------------------>

<?php


// Periksa apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: /pengumpulan/user/login-upz.php");
    exit();
}

// Dapatkan username pengguna dari sesi
$username = $_SESSION['username'];

// Koneksi ke basis data
include 'koneksi.php';

// Cek koneksi ke basis data
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Dapatkan data pengguna berdasarkan username
$sql = "SELECT * FROM muzaki WHERE username = '$username'";
$result = $koneksi->query($sql);

?>

<!DOCTYPE html>
<html>

<body>
    <div class="container">
        <div class="card">
            <div class="card-header">Data Muzaki UPZ <?php echo " " . $username . ". "; ?> </div>
            <div class="card-body">
                <div class="data-upz">
                    <div class="add-upz-form">
                        <button style=" display: flex;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahDataModalMuzaki">
                            Tambah Data Muzaki
                        </button><br>

                        <?php if ($result && $result->num_rows > 0) : ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Nomor Induk Muzaki</th>
                                        <th scope="col">Nama Muzaki</th>
                                        <th scope="col">No Telp/WA</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php while ($row = $result->fetch_assoc()) : ?>
                                        <tr>
                                            <th scope="row"><?php echo $i; ?></th>
                                            <td><?php echo $row["nomor_induk_muzaki"]; ?></td>
                                            <td><?php echo $row["nama_muzaki"]; ?></td>
                                            <td><?php echo $row["notlp_muzaki"]; ?></td>
                                            <td><?php echo $row["status_muzaki"]; ?></td>
                                            <td>
                                                <a href="hapus_data_muzaki.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Hapus</a>
                                            </td>

                                        </tr>
                                        <?php $i++; ?>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        <?php else : ?>
                            <div class="alert alert-warning" role="alert">
                                Tidak ada data Muzaki untuk pengguna ini.
                            </div>
                        <?php endif; ?>

                        <p style="color: blue; text-align: center;">
                            <?php echo $username . ". Anda boleh menambah data sejumlah muzaki yang ada pada UPZ anda."; ?>
                        </p>
                    </div><br>
                </div>
            </div>


            <!-- Modal Tambah Data -->
            <div class="modal fade" id="tambahDataModalMuzaki" tabindex="-1" role="dialog" aria-labelledby="tambahDataModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="tambahDataModalLabel">Tambah Data Muzaki</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="process_tambah_muzaki.php" method="POST">
                                <div class="form-group">
                                    <label for="nomor_induk_muzaki">Nomor Induk Muzaki:</label>
                                    <input type="text" class="form-control" id="nomor_induk_muzaki" name="nomor_induk_muzaki" onclick="fillRandomNumber()" pattern="[0-9]{12}" maxlength="12" placeholder="klik untuk mendapatkan Nomor Induk Muzaki" required>
                                </div>
                                <div class="form-group">
                                    <label for="nama_muzaki">Nama Muzaki:</label>
                                    <input type="text" class="form-control" id="nama_muzaki" name="nama_muzaki" required>
                                </div>
                                <div class="form-group">
                                    <label for="notlp_muzaki">Nomor Telp/WA:</label>
                                    <input type="text" class="form-control" id="notlp_muzaki" name="notlp_muzaki" required>
                                </div>
                                <div class="form-group">
                                    <label for="status_muzaki">Status Muzaki:</label>
                                    <select name="status_muzaki" class="form-control">
                                        <option value="Aktif">Aktif</option>
                                        <option value="Non-Aktif">Non-Aktif</option>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <script type="text/javascript">
                function generateRandomNumber() {
                    var randomNumber = Math.floor(Math.random() * 1000000000000);
                    return randomNumber.toString().padStart(12, '0');
                }

                function fillRandomNumber() {
                    var nomorIndukMuzaki = document.getElementById("nomor_induk_muzaki");
                    var nomorIndukUpz = document.getElementById("nomor_induk_upz");
                    nomorIndukMuzaki.value = generateRandomNumber();
                    nomorIndukUpz.value = generateRandomNumber();
                }
            </script>


            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
            <!-- JavaScript Bootstrap (Bundle) -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        </div>
    </div>
</body>

<?php
$koneksi->close();
?>

</html>
