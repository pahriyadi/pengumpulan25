<!DOCTYPE html>
<html>

<head>
  <title>Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background-image: url('../../imgs/bgr.jpg');
        background-size: cover;
        background-repeat: no-repeat;
    }

    .container {
      width: 100%;
      max-width: 400px;
      padding: 20px;
      background-color: rgba(255, 255, 255, 0.5);
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    }

    .form-group {
        margin-bottom: 20px;
    }

    .btn-login {
        width: 100%;
    }

    .alert {
        margin-top: 20px;
    }

    @media (max-width: 768px) {
        .container {
            max-width: 300px;
        }
    }
  </style>
</head>

<body>
  <div class="container">
    <h1 class="text-center mt-5">Login</h1>
    <form action="process_login.php" method="POST">
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" class="form-control" id="username" name="username" required>
      </div>

      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>

      <button type="submit" class="btn btn-primary btn-login">Login</button>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>

</html>
