<?php
// Koneksi ke database (sesuaikan dengan konfigurasi Anda)
include 'koneksi.php';

// Memeriksa apakah ada permintaan POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mendapatkan ID muzaki dari URL
    $muzakiId = $_GET['id'];

    // Mengambil data dari form
    $nomorIndukMuzaki = $_POST['nomor_induk_muzaki'];
    $namaMuzaki = $_POST['nama_muzaki'];
    $notlpMuzaki = $_POST['notlp_muzaki'];
    $statusMuzaki = $_POST['status_muzaki'];

    // Mengeksekusi query untuk mengupdate data muzaki
    $sql = "UPDATE muzaki SET nomor_induk_muzaki = '$nomorIndukMuzaki', nama_muzaki = '$namaMuzaki', notlp_muzaki = '$notlpMuzaki', status_muzaki = '$statusMuzaki' WHERE id = $muzakiId";

    if ($koneksi->query($sql) === TRUE) {
        // Jika query berhasil dieksekusi, redirect kembali ke halaman utama atau halaman yang diinginkan
        header("Location: /ozakat/pengumpulan/user/dashboard-user.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $koneksi->error;
    }
}

$koneksi->close();
?>
