<?php
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: /pengumpulan/user/login-upz.php");
    exit();
}

// Dapatkan username pengguna dari sesi
$username = $_SESSION['username'];

// Dapatkan data yang diinputkan dari form
$nama_pengurus_upz = $_POST['nama_pengurus_upz'];
$jabatan_pengurus_upz = $_POST['jabatan_pengurus_upz'];
$notlp_pengurus_upz = $_POST['notlp_pengurus_upz'];
$alamat_pengurus_upz = $_POST['alamat_pengurus_upz'];

// Koneksi ke basis data
include 'koneksi.php';

// Query untuk menambahkan data upz baru
$sql = "INSERT INTO pengurus_upz (username, nama_pengurus_upz, jabatan_pengurus_upz, notlp_pengurus_upz, alamat_pengurus_upz) VALUES ('$username', '$nama_pengurus_upz', '$jabatan_pengurus_upz', '$notlp_pengurus_upz', '$alamat_pengurus_upz')";

if ($koneksi->query($sql) === TRUE) {
    header("Location: /pengumpulan/user/dashboard-user.php");
} else {
    echo "Error: " . $sql . "<br>" . $koneksi->error;
}

$koneksi->close();
?>
