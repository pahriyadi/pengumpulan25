<?php
// Menghubungkan ke database
include 'koneksi.php';


// Menerima parameter id
$id = $_GET['id'];

// Query DELETE untuk menghapus data dengan id tersebut
$sql = "DELETE FROM muzaki WHERE id = $id";

if ($koneksi->query($sql) === TRUE) {
    header("Location: /pengumpulan/user/dashboard-user.php");
} else {
    echo "Error: " . $sql . "<br>" . $koneksi->error;
}

// Menutup koneksi
$koneksi->close();
?>
