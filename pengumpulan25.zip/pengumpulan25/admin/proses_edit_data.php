<?php
include 'koneksi.php';

// tangkap data dari form
$id = $_POST['id'];
$nama_muzaki = $_POST['nama_muzaki'];
$status_muzaki = $_POST['status_muzaki'];
$nomor_induk_muzaki = $_POST['nomor_induk_muzaki'];
$nomor_transaksi = $_POST['nomor_transaksi'];
$jumlah = $_POST['jumlah'];
$kredit_debit = $_POST['kredit_debit'];
$tanggal = $_POST['tanggal'];
$pembayaran = $_POST['pembayaran'];
$metode_bayar = $_POST['metode_bayar'];
$sumber_rekening = $_POST['sumber_rekening'];

// update data ke database
$query = "UPDATE zakat_infaq SET nama_muzaki='$nama_muzaki', status_muzaki='$status_muzaki', nomor_induk_muzaki='$nomor_induk_muzaki', nomor_transaksi='$nomor_transaksi', jumlah='$jumlah', kredit_debit='$kredit_debit', tanggal='$tanggal', pembayaran='$pembayaran', metode_bayar='$metode_bayar', sumber_rekening='$sumber_rekening' WHERE id_muzaki='$id'";
$result = mysqli_query($koneksi, $query);

// cek apakah query update berhasil
if ($result) {
    header("location:database-transaksi.php");
} else {
    echo "Error updating record: " . mysqli_error($koneksi);
}

// tutup koneksi
mysqli_close($koneksi);
?>
