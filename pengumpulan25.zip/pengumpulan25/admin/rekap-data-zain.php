<div class="non-printable">
<?php
include '../../koneksi.php';
include 'navbar.php'; 
include '../admin/lap_bulanan/aset/header.php';
include '../admin/lap_bulanan/aset/pencarian.php';
include '../admin/lap_bulanan/fungsi/query.php';

// Mendefinisikan variabel $tahun dan $bulan
$tahun = isset($_POST['tahun']) ? mysqli_real_escape_string($koneksi, $_POST['tahun']) : date('Y');
$bulan = isset($_POST['bulan']) ? mysqli_real_escape_string($koneksi, $_POST['bulan']) : date('m');
?>
</div>

<div class="printable">
<div class="container">
    
     <div class="text-center"><h1>LAPORAN PENERIMAAN BULAN <?php 
        echo date('F', mktime(0, 0, 0, $bulan, 10)); ?> 
        TAHUN <?php echo $tahun; ?></h1></div>
    
           
<div class="card">
    <div class="card-header text-center"><strong>PENERIMAAN ZAKAT BULAN <?php 
        echo date('F', mktime(0, 0, 0, $bulan, 10)); ?> 
        TAHUN <?php echo $tahun; ?></strong></div>
    <div class="card-body">
        <?php
        include '../admin/lap_bulanan/bulanan_zakat_perorangan.php';
        include '../admin/lap_bulanan/bulanan_zakat_perorangan_upz.php';
        include '../admin/lap_bulanan/bulanan_zakat_badan.php';
        include '../admin/lap_bulanan/bulanan_zakat_fitrah_upz.php';
        include '../admin/lap_bulanan/bulanan_zakat_fitrah_perorangan.php';
        include '../admin/lap_bulanan/bulanan_zakat_fitrah_offbalancesheet.php';
        ?>
    </div>
</div>
<hr>

<div class="card">
    <div class="card-header text-center"><strong>PENERIMAAN INFAK/SEDEKAH BULAN <?php 
        echo date('F', mktime(0, 0, 0, $bulan, 10)); ?> 
        TAHUN <?php echo $tahun; ?></strong></div>
    <div class="card-body">
        <?php
        include '../admin/lap_bulanan/bulanan_infak_tt_perorangan.php';
        include '../admin/lap_bulanan/bulanan_infak_tt_perorangan_upz.php';
        include '../admin/lap_bulanan/bulanan_infak_terikat.php';
        include '../admin/lap_bulanan/bulanan_infak_penyaluran.php';
        include '../admin/lap_bulanan/bulanan_infak_operasional.php';
        ?>
    </div>
</div>
<hr>

<div class="card">
    <div class="card-header text-center"><strong>PENERIMAAN LAINNYA <?php 
        echo date('F', mktime(0, 0, 0, $bulan, 10)); ?> 
        TAHUN <?php echo $tahun; ?></strong></div>
    <div class="card-body">
        <?php
        include '../admin/lap_bulanan/bulanan_csr.php';
        include '../admin/lap_bulanan/bulanan_kurban.php';
        include '../admin/lap_bulanan/bulanan_kurban_upz.php';
        include '../admin/lap_bulanan/bulanan_fidyah.php';
        include '../admin/lap_bulanan/bulanan_dskl.php';
        include '../admin/lap_bulanan/bulanan_dskl_upz.php';
        include '../admin/lap_bulanan/bulanan_dana_titipan.php';
        include '../admin/lap_bulanan/bulanan_apbd.php';
        ?>
    </div>
</div>
</div>
</div>

<?php mysqli_close($koneksi); ?>