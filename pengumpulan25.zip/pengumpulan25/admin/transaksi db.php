<?php
include 'koneksi.php';
include 'navbar.php';

// Fungsi untuk mengambil data dari database
function getData($sortOrder, $searchTerm)
{
    global $koneksi;

    $sql = "SELECT * FROM zakat_infaq";

    // Tambahkan kondisi pengurutan
    if (!empty($sortOrder)) {
        $sql .= " ORDER BY $sortOrder";
    }

    $result = $koneksi->query($sql);

    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    return [];
}

// Atur pengurutan dan pencarian
$sortOrder = isset($_GET['sort']) ? $_GET['sort'] : 'id_muzaki DESC';
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Ambil data dari database
$data = getData($sortOrder, $searchTerm);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BAZNAS SUMBAWA</title>
    <!-- Sertakan Bootstrap CSS dari CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <!-- Sertakan DataTables CSS dari CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-XXX" crossorigin="anonymous" />
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">

</head>

<body>

    <div class="container border mt-5">
        
            
                <table id="muzakiTable" class="table table-responsif table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Nama</th>
                            <th>Status</th>
                            <th>NIM</th>

                            <th>Jumlah</th>
                            <th>K/D</th>
                            <th>Tgl</th>
                            <th>Bayar</th>
                            <th>Metode</th>
                            <th>Sumber</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data as $row) : ?>
                            <tr>
                                <td>
                                    <?= $row['id_muzaki'] ?>
                                </td>
                                <td>
                                    <?= $row['nama_muzaki'] ?>
                                </td>
                                <td>
                                    <?= $row['status_muzaki'] ?>
                                </td>
                                <td>
                                    <?= $row['nomor_induk_muzaki'] ?>
                                </td>

                                <td>
                                    <?= number_format($row['jumlah'], 2, ',', '.'); ?>
                                </td>
                                <td>
                                    <?= $row['kredit_debit'] ?>
                                </td>
                                <td>
                                    <?= $row['tanggal'] ?>
                                </td>
                                <td>
                                    <?= $row['pembayaran'] ?>
                                </td>
                                <td>
                                    <?= $row['metode_bayar'] ?>
                                </td>
                                <td>
                                    <?= $row['sumber_rekening'] ?>
                                </td>
                                <td>
                                    <a href='#myModal' class='btn btn-success btn-sm' id_muzaki='id' data-toggle='modal' data-id="<?php echo $row['id_muzaki']; ?>" title='Tambah Data'><i class="fas fa-plus"></i></a>
                                    <a href='#myModal1' class='btn btn-info btn-sm' id_muzaki='id' data-toggle='modal' data-id="<?php echo $row['id_muzaki']; ?>" title='Edit Data'><i class="fas fa-pencil-alt"></i></a>
                                    <a href='#' class='btn btn-warning btn-sm hapus-data' data-id="<?php echo $row['id_muzaki']; ?>" data-nama="<?php echo $row['nama_muzaki']; ?>" title='Hapus Data'><i class="fas fa-times"></i></a>
                                    <a href='#kwitansiModal' class='btn btn-danger btn-sm' id_muzaki='id' data-toggle='modal' data-id="<?php echo $row['id_muzaki']; ?>" title='Kwitansi'><i class="fas fa-file-invoice"></i></a>
                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#tambahDataModal" title='tambah data baru'><i class="fas fa-file-invoice"></i></button>
                                </td>

                            </tr>
                            <!-- Modal Edit untuk setiap baris -->
                            <!-- Modal tamah data berdasarkan id -->



                            <!-- Modal tambah muzaki-->

                        <?php endforeach; ?>
                    </tbody>
                </table>
    </div>

    <!-- Modal Tambah Data Baru -->
    <div class="modal fade" id="tambahDataModal" tabindex="-1" role="dialog" aria-labelledby="tambahDataModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="tambahDataModalLabel">Form Tambah Data Zakat dan Infaq</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="proses_tambah_data.php">
                        <label>Nama Muzaki/UPZ:</label>
                        <input type="text" name="nama_muzaki" required class="form-control">
                        <label>Status Muzaki:</label>
                        <select name="status_muzaki" class="form-control">
                            <option value="Perorangan">Perorangan</option>
                            <option value="Dinas Instansi">Dinas Instansi</option>
                            <option value="BANK">BANK</option>
                            <option value="BUMN">BUMN</option>
                            <option value="BUMD">BUMD</option>
                            <option value="Sekolah">Sekolah</option>
                            <option value="A/N">A/N</option>
                        </select>
                        <label>Nomor Induk Muzaki:</label>
                        <input class="form-control" type="text" name="nomor_induk_muzaki" id="nomor_induk_muzaki" onclick="fillRandomNumber()" pattern="[0-9]{12}" maxlength="12" required>
                        <label>Nomor Transaksi:</label>
                        <input class="form-control" type="text" name="nomor_transaksi" id="nomor_transaksi" onclick="fillRandomNumber()" pattern="[0-9]{7}" maxlength="7" required>
                        <label>Jumlah:</label>
                        <input class="form-control" type="number" name="jumlah" pattern="[0-9]+([,.][0-9]{0,2})?" required>
                        <label>Kredit/Debit:</label>
                        <select name="kredit_debit" class="form-control">
                            <option value="Kredit">Kredit</option>
                            <option value="Debit">Debit</option>
                        </select>
                        <label>Tanggal:</label>
                        <input class="form-control" type="date" name="tanggal" required>
                        <label>Pembayaran:</label>
                        <select name="pembayaran" class="form-control">
                            <option value="Zakat">Zakat</option>
                            <option value="Infaq dan Shadaqoh">Infaq dan Shadaqoh</option>
                            <option value="Infaq dan Shadaqoh Terikat">Infaq dan Shadaqoh Terikat</option>
                        </select>
                        <label>Metode Bayar:</label>
                        <select name="metode_bayar" class="form-control">
                            <option value="Tunai">Tunai</option>
                            <option value="Transfer Bank">Transfer Bank</option>
                        </select>
                        <label>Sumber Rekening:</label>
                        <select class="form-control" name="sumber_rekening">
                            <option value="BNTB SYARIAH ZAKAT">BNTB SYARIAH ZAKAT</option>
                            <option value="BNTB SYARIAH INFAQ">BNTB SYARIAH INFAQ</option>
                            <option value="NO. REK APBD">NO. REK APBD</option>
                            <option value="BNTB SYARIAH PROVINSI 019">BNTB SYARIAH PROVINSI 019</option>
                            <option value="BANK BSI SYARIAH">BANK BSI SYARIAH</option>
                        </select><br>
                        <input type="submit" value="Simpan" class="btn btn-primary" accesskey="s">
                        <input type="reset" value="Reset" class="btn btn-primary">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Batal</button>
                    </form>
                    <script type="text/javascript">
                        function generateRandomNumber() {
                            var randomNumber = Math.floor(Math.random() * 1000000000000);
                            return randomNumber.toString().padStart(12, '0');
                        }

                        function fillRandomNumber() {
                            var nomorIndukMuzaki = document.getElementById("nomor_induk_muzaki");
                            var nomorTransaksi = document.getElementById("nomor_transaksi");

                            nomorIndukMuzaki.value = generateRandomNumber();
                            nomorTransaksi.value = generateRandomNumber().substr(0, 7);
                        }
                    </script>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Tambah Transaksi</h4>
                </div>
                <div class="modal-body">
                    <div class="fetched-data"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#myModal').on('show.bs.modal', function(e) {
                var rowid = $(e.relatedTarget).data('id');
                //menggunakan fungsi ajax untuk pengambilan data
                $.ajax({
                    type: 'post',
                    url: 'detail-simpan.php',
                    data: 'rowid=' + rowid,
                    success: function(data) {
                        $('.fetched-data').html(data); //menampilkan data ke dalam modal
                    }
                });
            });
        });
    </script>

    <!-- Modal edit data berdasarkan id -->
    <div class="modal fade" id="myModal1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Edit Transaksi</h4>
                </div>
                <div class="modal-body">
                    <div class="fetched-data"></div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#myModal1').on('show.bs.modal', function(e) {
                var rowid = $(e.relatedTarget).data('id');
                //menggunakan fungsi ajax untuk pengambilan data
                $.ajax({
                    type: 'post',
                    url: 'detail-edit.php',
                    data: 'rowid=' + rowid,
                    success: function(data) {
                        $('.fetched-data').html(data); //menampilkan data ke dalam modal
                    }
                });
            });
        });
    </script>

    <script>
        // Handle modal show event
        $('#kwitansiModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var id = button.data('id'); // Extract data-id attribute from button
            var modal = $(this);

            // Redirect to kwitansi.php with the ID parameter
            var redirectUrl = 'kwitansi.php?id=' + id;
            window.location.href = redirectUrl;
        });
    </script>

    <script>
        $(document).ready(function() {
            $('.hapus-data').on('click', function(e) {
                e.preventDefault();
                var idMuzaki = $(this).data('id');
                var namaMuzaki = $(this).data('nama');

                // Tampilkan konfirmasi pengguna dengan informasi id_muzaki dan nama_muzaki
                var confirmation = confirm('Apakah Anda yakin ingin menghapus data dengan ID: ' + idMuzaki + ' dan Nama Muzaki: ' + namaMuzaki + '?');

                if (confirmation) {
                    // Lakukan permintaan Ajax untuk menghapus data
                    $.ajax({
                        type: 'post',
                        url: 'proses_hapus_data.php',
                        data: {
                            id: idMuzaki,
                            nama: namaMuzaki
                        },
                        success: function(response) {
                            // Tambahkan logika penanganan setelah penghapusan data (jika diperlukan)
                            console.log(response);
                            // Refresh atau perbarui halaman setelah penghapusan data
                            // window.location.reload(); // Uncomment ini jika ingin memperbarui halaman
                            window.location.reload();
                        }
                    });
                }
            });
        });
    </script>

    <script type="text/javascript">
        function generateRandomNumber() {
            var randomNumber = Math.floor(Math.random() * 1000000000000);
            return randomNumber.toString().padStart(12, '0');
        }

        function fillRandomNumber() {
            var nomorIndukMuzaki = document.getElementById("nomor_induk_muzaki");
            var nomorTransaksi = document.getElementById("nomor_transaksi");

            nomorIndukMuzaki.value = generateRandomNumber();
            nomorTransaksi.value = generateRandomNumber().substr(0, 7);
        }
    </script>


    <!-- Sertakan jQuery dan DataTables JS dari CDN -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>


    <script>
        $(document).ready(function() {
            // Inisialisasi DataTables
            var table = $('#muzakiTable').DataTable({
                // Pengaturan tambahan untuk DataTables
                "order": [
                    [0, "desc"]
                ], // Urutkan berdasarkan ID Muzaki secara descending
                "paging": true, // Aktifkan paging
                "lengthChange": true, // Aktifkan pilihan jumlah data per halaman
                "searching": true, // Matikan fitur pencarian bawaan DataTables, gunakan form pencarian di atas
                "info": true, // Tampilkan informasi halaman dan jumlah data
                "autoWidth": true, // Sesuaikan lebar kolom secara otomatis
                "scrollX": true,
                "scrollY": true,
                "columnDefs": true,
                "serverside": true,
            });

            // Set fokus ke kotak pencarian saat halaman dimuat
            $('#muzakiTable_filter input').focus();
        });
    </script>


    <!-- Sertakan Bootstrap JS dari CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous">
    </script>
    <script src="timeouts.js"></script>




</body>

</html>