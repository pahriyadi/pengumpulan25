<!-- Modal Tambah Data Baru -->
<div class="modal fade" id="tambahDataModal" tabindex="-1" role="dialog" aria-labelledby="tambahDataModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="tambahDataModalLabel">Form Tambah Data Zakat dan Infaq</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="proses_tambah_data.php">
                        <label>Nama Muzaki/UPZ:</label>
                        <input type="text" name="nama_muzaki" required class="form-control">
                        <div class="form-group">
                            <label>Status Muzaki:</label>
                            <select name="status_muzaki" class="form-control">
                                <?php
                                include 'status_muzaki.php';
                                generateStatusMuzakiOptions(); // Untuk tambah data, default kosong
                                ?>
                            </select>
                        </div>
                        <label>Nomor Induk Muzaki:</label>
                        <input class="form-control" type="text" name="nomor_induk_muzaki" id="nomor_induk_muzaki"
                            onclick="fillRandomNumber()" pattern="[0-9]{12}" maxlength="12" required>
                        <label>Nomor Transaksi:</label>
                        <input class="form-control" type="text" name="nomor_transaksi" id="nomor_transaksi"
                            onclick="fillRandomNumber()" pattern="[0-9]{7}" maxlength="7" required>
                        <label>Jumlah:</label>
                        <input class="form-control" type="number" name="jumlah" pattern="[0-9]+([,.][0-9]{0,2})?"
                            required>
                        <label>Kredit/Debit:</label>
                        <select name="kredit_debit" class="form-control">
                            <option value="Kredit">Kredit</option>
                            <option value="Debit">Debit</option>
                        </select>
                        <label>Tanggal:</label>
                        <input class="form-control" type="date" name="tanggal" required>
                        <label>Pembayaran:</label>
                        <select name="pembayaran" class="form-control">
                        <?php
                                include 'pembayaran.php';
                                generatePembayaranOptions(); // Untuk tambah data, default kosong
                                ?>
                        </select>
                        <label>Metode Bayar:</label>
                        <select name="metode_bayar" class="form-control">
                            <option value="Tunai">Tunai</option>
                            <option value="Transfer Bank">Transfer Bank</option>
                        </select>
                        <label>Sumber Rekening:</label>
                        <select class="form-control" name="sumber_rekening">
                        <?php
                                include 'sumber_rekening.php';
                                generateSumberRekeningOptions(); // Untuk tambah data, default kosong
                                ?>
                        </select><br>
                        <input type="submit" value="Simpan" class="btn btn-primary" accesskey="s">
                        <input type="reset" value="Reset" class="btn btn-primary">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Batal</button>
                    </form>
                    <script type="text/javascript">
                        function generateRandomNumber(length) {
                            var randomNumber = Math.floor(Math.random() * Math.pow(10, length));
                            return randomNumber.toString().padStart(length, '0');
                        }

                        function fillRandomNumber() {
                            var nomorIndukMuzaki = document.getElementById("nomor_induk_muzaki");
                            var nomorTransaksi = document.getElementById("nomor_transaksi");

                            nomorIndukMuzaki.value = generateRandomNumber(12);
                            nomorTransaksi.value = generateRandomNumber(7);
                        }
                    </script>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Tambah Transaksi</h4>
                </div>
                <div class="modal-body">
                    <div class="fetched-data"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#myModal').on('show.bs.modal', function (e) {
                var rowid = $(e.relatedTarget).data('id');
                //menggunakan fungsi ajax untuk pengambilan data
                $.ajax({
                    type: 'post',
                    url: 'detail-simpan.php',
                    data: 'rowid=' + rowid,
                    success: function (data) {
                        $('.fetched-data').html(data); //menampilkan data ke dalam modal
                    }
                });
            });
        });
    </script>

    <!-- Modal edit data berdasarkan id -->
    <div class="modal fade" id="myModal1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Edit Transaksi</h4>
                </div>
                <div class="modal-body">
                    <div class="fetched-data"></div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#myModal1').on('show.bs.modal', function (e) {
                var rowid = $(e.relatedTarget).data('id');
                //menggunakan fungsi ajax untuk pengambilan data
                $.ajax({
                    type: 'post',
                    url: 'detail-edit.php',
                    data: 'rowid=' + rowid,
                    success: function (data) {
                        $('.fetched-data').html(data); //menampilkan data ke dalam modal
                    }
                });
            });
        });
    </script>

    <script>
        // Handle modal show event
        $('#kwitansiModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var id = button.data('id'); // Extract data-id attribute from button
            var modal = $(this);

            // Redirect to kwitansi.php with the ID parameter
            var redirectUrl = 'kwitansi.php?id=' + id;
            window.location.href = redirectUrl;
        });
    </script>

    <script>
        $(document).ready(function () {
            $('.hapus-data').on('click', function (e) {
                e.preventDefault();
                var idMuzaki = $(this).data('id');
                var namaMuzaki = $(this).data('nama');

                // Tampilkan konfirmasi pengguna dengan informasi id_muzaki dan nama_muzaki
                var confirmation = confirm('Apakah Anda yakin ingin menghapus data dengan ID: ' + idMuzaki + ' dan Nama Muzaki: ' + namaMuzaki + '?');

                if (confirmation) {
                    // Lakukan permintaan Ajax untuk menghapus data
                    $.ajax({
                        type: 'post',
                        url: 'proses_hapus_data.php',
                        data: {
                            id: idMuzaki,
                            nama: namaMuzaki
                        },
                        success: function (response) {
                            // Tambahkan logika penanganan setelah penghapusan data (jika diperlukan)
                            console.log(response);
                            // Refresh atau perbarui halaman setelah penghapusan data
                            // window.location.reload(); // Uncomment ini jika ingin memperbarui halaman
                            window.location.reload();
                        }
                    });
                }
            });
        });
    </script>

    <script type="text/javascript">
        function generateRandomNumber() {
            var randomNumber = Math.floor(Math.random() * 1000000000000);
            return randomNumber.toString().padStart(12, '0');
        }

        function fillRandomNumber() {
            var nomorIndukMuzaki = document.getElementById("nomor_induk_muzaki");
            var nomorTransaksi = document.getElementById("nomor_transaksi");

            nomorIndukMuzaki.value = generateRandomNumber();
            nomorTransaksi.value = generateRandomNumber().substr(0, 7);
        }
    </script>