<?php
include 'koneksi.php';

if ($_POST['rowid']) {
    $id = $_POST['rowid'];
    // mengambil baris berdasarkan id
    // dan menampilkan baris ke dalam form modal bootstrap
    $sql = "SELECT * FROM zakat_infaq WHERE id_muzaki = $id";
    $result = $koneksi->query($sql);
    foreach ($result as $baris) { ?>


        <div class="mb-4">
            <div class="bg-primary text-white p-3">
                <h5 class="mb-0">Detail Muzaki</h5>
            </div>
            <div class="p-3">
                <form action="proses_tambah_id.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $baris['id_muzaki']; ?>">
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="tanggal" class="form-label">Tanggal:</label>
                            <input type="date" class="form-control" id="tanggal" name="tanggal" required>
                        </div>
                        <div class="col-md-4">
                            <label for="jumlah" class="form-label">Jumlah:</label>
                            <input type="number" class="form-control" id="jumlah" name="jumlah" step="0.01" min="0" required autocomplete="off">
                        </div>
                        <div class="col-md-4">
                            <label for="nomor_induk_muzaki" class="form-label">Nomor Induk Muzaki:</label>
                            <input type="text" class="form-control" id="nomor_induk_muzaki" name="nomor_induk_muzaki" value="<?php echo $baris['nomor_induk_muzaki']; ?>" pattern="[0-9]{12}" maxlength="12" required readonly>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="nama_muzaki" class="form-label">Nama Muzaki/UPZ:</label>
                            <input type="text" class="form-control" id="nama_muzaki" name="nama_muzaki" value="<?php echo $baris['nama_muzaki']; ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label for="nomor_transaksi1" class="form-label">Nomor Transaksi:</label>
                            <input type="text" class="form-control" id="nomor_transaksi1" name="nomor_transaksi" readonly onclick="fillRandomNumber()" pattern="[0-9]{7}" maxlength="7" required>
                        </div>
                        <div class="col-md-4">
                            <label for="kredit_debit" class="form-label">Kredit/Debit:</label>
                            <select name="kredit_debit" id="kredit_debit" class="form-control">
                                <option value="Kredit" <?php if ($baris['kredit_debit'] == 'Kredit') echo 'selected'; ?>>Kredit</option>
                                <option value="Debit" <?php if ($baris['kredit_debit'] == 'Debit') echo 'selected'; ?>>Debit</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="status_muzaki" class="form-label">Status Muzaki:</label>
                            <select name="status_muzaki" id="status_muzaki" class="form-control">
                                <?php
                                include 'status_muzaki.php';
                                $selectedValue = isset($baris['status_muzaki']) ? $baris['status_muzaki'] : '';
                                generateStatusMuzakiOptions($selectedValue);
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="pembayaran" class="form-label">Pembayaran:</label>
                            <select name="pembayaran" id="pembayaran" class="form-control">
                                <?php
                                include 'pembayaran.php';
                                $selectedValue = isset($baris['pembayaran']) ? $baris['pembayaran'] : '';
                                generatePembayaranOptions($selectedValue);
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="metode_bayar" class="form-label">Metode Bayar:</label>
                            <select name="metode_bayar" id="metode_bayar" class="form-control">
                                <option value="Tunai" <?php if ($baris['metode_bayar'] == 'Tunai') echo 'selected'; ?>>Tunai</option>
                                <option value="Transfer Bank" <?php if ($baris['metode_bayar'] == 'Transfer Bank') echo 'selected'; ?>>Transfer Bank</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="sumber_rekening" class="form-label">Sumber Rekening:</label>
                            <select name="sumber_rekening" id="sumber_rekening" class="form-control">
                                <?php
                                include 'sumber_rekening.php';
                                $selectedValue = isset($baris['sumber_rekening']) ? $baris['sumber_rekening'] : '';
                                generateSumberRekeningOptions($selectedValue);
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4 mt-4">
                            <button class="btn btn-success w-100" type="submit">Simpan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>


    <?php }
}
$koneksi->close();
?>



<script type="text/javascript">
    // Fungsi untuk mengisi nomor transaksi secara otomatis saat modal ditampilkan
    $('#myModal').on('shown.bs.modal', function () {
        var nomorTransaksi1 = document.getElementById("nomor_transaksi1");
        nomorTransaksi1.value = generateRandomNumber();
    });

    function generateRandomNumber() {
        var randomNumber = Math.floor(Math.random() * 10000000); // Ubah panjang nomor transaksi menjadi 7 digit
        return randomNumber.toString().padStart(7, '0');
    }
</script>

<script type="text/javascript">
    $(document).ready(function () {
        // Fungsi untuk mengatur fokus ke input tanggal saat modal ditampilkan
        $('#myModal').on('shown.bs.modal', function () {
            $('#tanggal').focus(); // Set fokus ke input tanggal
        });
    });
</script>