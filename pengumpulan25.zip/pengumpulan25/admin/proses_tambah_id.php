<!--ini code proses_tambah_id.php-->

<?php
include 'koneksi.php';

// ambil data dari form
$nama_muzaki = strtoupper($_POST['nama_muzaki']);
$status_muzaki = $_POST['status_muzaki'];
$nomor_induk_muzaki = $_POST['nomor_induk_muzaki'];
$nomor_transaksi = $_POST['nomor_transaksi'];
$jumlah = $_POST['jumlah'];
$kredit_debit = $_POST['kredit_debit'];
$tanggal = $_POST['tanggal'];
$pembayaran = $_POST['pembayaran'];
$metode_bayar = $_POST['metode_bayar'];
$sumber_rekening = $_POST['sumber_rekening'];

// tambah data ke database
$query = "INSERT INTO zakat_infaq (nama_muzaki, status_muzaki, nomor_induk_muzaki, nomor_transaksi, jumlah, kredit_debit, tanggal, pembayaran, metode_bayar, sumber_rekening) 
          VALUES ('$nama_muzaki', '$status_muzaki', '$nomor_induk_muzaki', '$nomor_transaksi', '$jumlah', '$kredit_debit', '$tanggal', '$pembayaran', '$metode_bayar', '$sumber_rekening')";
$result = mysqli_query($koneksi, $query);

// cek apakah query berhasil dijalankan atau tidak
if ($result) {
  header('Location: database-transaksi.php');
} else {
  echo "Gagal menambahkan data. Error: " . mysqli_error($koneksi);
}

// tutup koneksi database
mysqli_close($koneksi);
?>
