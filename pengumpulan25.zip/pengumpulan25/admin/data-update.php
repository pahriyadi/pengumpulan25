<h2>Update Data Produk</h2>

<form method="post" action="data-simpan.php">
    <table border="1" style="border-collapse:collapse">
        <tr bgcolor="#eee">
            <th>Nama Muzaki</th>
            <th>Status Muzaki</th>
            <th>Nomor Induk Muzaki</th>
            <th>Nomor Transaksi</th>
            <th>jumlah</th>
            <th>K/D</th>
            <th>Tanggal</th>
            <th>Pembayaran</th>
            <th>Metode Pembayaran</th>
            <th>Sumber Rekening</th>
        </tr>

        <?php
include "koneksi.php";

$id = $_POST['id'];
$jum = count($id); //menghitung jumlah ID yang dipilih

for ($i=0; $i<$jum; $i++) { // Proses Looping

    $ambildata = mysqli_query($koneksi,"select * from zakat_infaq where id_muzaki='$id[$i]'")
    or die (mysqli_error($koneksi));
    
    while($tampil = mysqli_fetch_array($ambildata)){

    echo "<tr>
    <td><input type='text' name='nama_muzaki[]' value='$tampil[nama_muzaki]' required></td>
    <td>
        <select name='status_muzaki[] value='$tampil[status_muzaki]''>
            <option value='Perorangan'>Perorangan</option>
            <option value='Dinas Instansi'>Dinas Instansi</option>
            <option value='BANK'>BANK</option>
            <option value='BUMN'>BUMN</option>
            <option value='BUMD'>BUMD</option>
            <option value='Sekolah'>Sekolah</option>
            <option value='A/N'>A/N</option>
        </select>
    </td>
    <td><input type='text' name='nomor_induk_muzaki[]' value='$tampil[nomor_induk_muzaki]' id='nomor_induk_muzaki' onclick='fillRandomNumber()' pattern='[0-9]{12}' maxlength='12' required></td>
    <td><input type='text' name='nomor_transaksi[]' value='$tampil[nomor_transaksi]' id='nomor_transaksi' onclick='fillRandomNumber()' pattern='[0-9]{7}' maxlength='7' required></td>
    <td><input type='number' name='jumlah[]' value='$tampil[jumlah]' pattern='[0-9]+([,.][0-9]{0,2})?' required></td>
    <td>
        <select name='kredit_debit[] ' value='$tampil[kredit_debit]'>
            <option value='Kredit'>Kredit</option>
            <option value='Debit'>Debit</option>
        </select>
    </td>
    <td><input type='date' name='tanggal[]' value='$tampil[tanggal]' required></td>
    <td>
        <select name='pembayaran[]' value='$tampil[pembayaran]'>
            <option value='Zakat'>Zakat</option>
            <option value='Infaq dan Shadaqoh'>Infaq dan Shadaqoh</option>
        </select>
    </td>
    <td>
        <select name='metode_bayar[]' value='$tampil[metode_bayar]'>
            <option value='Tunai'>Tunai</option>
            <option value='Transfer Bank'>Transfer Bank</option>
        </select>
    </td>
    <td>
        <select name='sumber_rekening[]' value='$tampil[sumber_rekening]'>
            <option value='BNTB SYARIAH ZAKAT'>BNTB SYARIAH ZAKAT</option>
            <option value='BNTB SYARIAH INFAQ'>BNTB SYARIAH INFAQ</option>
            <option value='NO. REK APBD'>NO. REK APBD</option>
            <option value='BNTB SYARIAH PROVINSI 019'>BNTB SYARIAH PROVINSI 019</option>
            <option value='BANK BSI SYARIAH'>BANK BSI SYARIAH</option>
        </select>
    </td>
    
            
            <input type='hidden' name='id[]' value='$tampil[id_muzaki]'>
         </tr>";    
    }
}
?>
    </table>

    <input type="hidden" name="jum" value="<?php echo $jum; ?>">

    <input type="submit" name="proses" value="Simpan" style="margin-top:5px">
    <input type="button" value="Kembali" onclick="location.href='data-tampil.php';">

</form>