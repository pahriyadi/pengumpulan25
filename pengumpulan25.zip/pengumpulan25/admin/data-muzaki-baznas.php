<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Data Muzaki</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">

  <style>
    
     body {
        width :100%;
        background:rgb(240, 248, 254);
        
    }
  
        .container {
        width: 80%; /* Mengatur lebar kontainer menjadi 80% dari lebar parent */
        margin: 0 auto; /* Mengatur kontainer untuk terpusat secara horizontal */
        padding: 20px; /* Menambahkan ruang polos di sekitar konten dalam kontainer */
        background:white;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5); /* Bayangan hitam */
        border-radius:10px;
        }
        
                        .container-cari {
        width: 100%; /* Mengatur lebar kontainer menjadi 80% dari lebar parent */
        margin: 0 auto; /* Mengatur kontainer untuk terpusat secara horizontal */
        padding: 10px; /* Menambahkan ruang polos di sekitar konten dalam kontainer */
        background:	rgb(255, 250, 250);
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5); /* Bayangan hitam */
        border-radius:10px;
        }
    
    table {
      border-collapse: collapse;
      width: 100%;
      font-size: 14px;
      margin-left: auto;
      margin-right: auto;
    }

    th,
    td {
      text-align: center;
      padding: 10px;
      text-transform: uppercase;
    }

    th {
      background-color: #fff;
      color: black;
      text-transform: uppercase;
    }

    td {
      text-align: left;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    tr:hover {
      background-color: #ddd;
    }

    .action {
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .action a {
      color: #fff;
      margin-right: 5px;
      padding: 5px 10px;
      border-radius: 5px;
      text-decoration: none;
    }

    .action a.edit {
      background-color: #5cb85c;
    }

    .action a.delete {
      background-color: #d9534f;
    }

    H1 {
      text-align: center;
      font-size: 20px;
      padding-bottom: 0px;
    }

    .ttd {
      margin-top: 20px;
      text-align: right;
      font-size: 15px;
    }

    .ttd p {
      margin-bottom: 0.5px;
      font-weight: bold;
    }

    .tebal {
      font-weight: bold;
    }

    .ttd {
      margin-top: 20px;
      font-size: 15px;
      align-items: center;
    }

    .ttd p {
      margin-bottom: 0.5px;
      font-weight: bold;
      align-items: center;
    }


    .hidden-button {
      position: absolute;
      top: -9999px;
      left: -9999px;
    }

    @media print {

      /* CSS untuk bagian yang akan diprint */
      body {
        font-size: 14px;
      }

      .printable {
        display: block;
      }

      .non-printable {
        display: none;
      }

      /* Aturan untuk mode lanskap */
      @page {
        size: Portrait;
      }
    }
  </style>
</head>

<div class="non-printable">
<?php include 'navbar.php'; ?>
</div>

<body>
    
    <div class="container">
        <div class="non-printable">
    

    <!-- Button trigger modal -->
    <button type="button" class="hidden-button" data-toggle="modal" data-target="#filterModal" accesskey="z">
      Filter
    </button>
    
    <div class="container-cari">
            <!-- Form Pencarian -->
    <form method="GET" action="" style="margin:0px; display: flex; gap:5px;">
      <select name="status" id="status" class="form form-control">
              <option value="">-- Pilih status muzaki --</option>
              <option value="Perorangan">Perorangan</option>
              <option value="Dinas Instansi">Dinas Instansi</option>
              <option value="BANK">BANK</option>
              <option value="BUMN">BUMN</option>
              <option value="BUMD">BUMD</option>
              <option value="Sekolah">Sekolah</option>
              <option value="A/N">A/N</option>
      </select>
      <button type="submit" class="btn btn-danger">Cari</button>
    </form>
    </div>
  </div><br>

  <div class="printtable">
    <h1>BAZNAS KABUPATEN SUMBAWA</h1>
    <?php
    $tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');
    ?>
    <h1>DAFTAR NAMA MUZAKI</h1>


    <table border="1">
      <tr>
        <th>No</th>
        <th>Nama Muzaki</th>
        <th>Status Muzaki</th>
        <th>NIM</th>
        <th>K/D</th>
        <th>metode_bayar</th>
      </tr>

      <?php
    include 'koneksi.php';

  if (isset($_GET['status'])) {
    $search_status = $_GET['status'];
    $query_muzaki = "SELECT DISTINCT nomor_induk_muzaki FROM zakat_infaq WHERE status_muzaki = '$search_status' ORDER BY nomor_induk_muzaki";
  } else {
    $query_muzaki = "SELECT DISTINCT nomor_induk_muzaki FROM zakat_infaq ORDER BY nomor_induk_muzaki";
  }

  $result_muzaki = mysqli_query($koneksi, $query_muzaki);

    // Loop untuk menampilkan data muzaki
    $no = 1;
    while ($muzaki = mysqli_fetch_array($result_muzaki)) {
      // Query untuk mengambil nama muzaki
      $query_nama = "SELECT nama_muzaki, status_muzaki, nomor_induk_muzaki, kredit_debit, pembayaran, metode_bayar FROM zakat_infaq WHERE nomor_induk_muzaki = '" . $muzaki['nomor_induk_muzaki'] . "' LIMIT 1";
      $result_nama = mysqli_query($koneksi, $query_nama);
      $data_muzaki = mysqli_fetch_array($result_nama);
      $nama_muzaki = $data_muzaki['nama_muzaki'];
      $status_muzaki = $data_muzaki['status_muzaki'];
      $nomor_induk_muzaki = $data_muzaki['nomor_induk_muzaki'];
      $kredit_debit = $data_muzaki['kredit_debit'];
      $pembayaran = $data_muzaki['pembayaran'];
      $metode_bayar = $data_muzaki['metode_bayar'];

      echo "<tr>";
      echo "<td style='text-align: center;'>" . $no++ . "</td>";
      echo "<td>" . $nama_muzaki . "</td>";
      echo "<td>" . $status_muzaki . "</td>";
      echo "<td>" . $nomor_induk_muzaki . "</td>";
      echo "<td>" . $kredit_debit . "</td>";
      echo "<td>" . $metode_bayar . "</td>";
      // ...Sisanya seperti sebelumnya...
    }
    ?>
  </table>

    <div class="ttd">
      <p>Sumbawa Besar,
        <?php echo date('d F Y'); ?>
      </p>
      <p>Ketua BAZNAS Kab. Sumbawa</p><br><br><br><br><br><br>
      <p>H. M. ALI TUNRU, S.Sos</p>
    </div>
  </div>

    </div>
  
  <!-- Modal -->
  <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="filterModalLabel">Filter Berdasarkan Tahun</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="GET" action="">
            <div class="form-group">
              <label for="tahun">Tahun:</label>
              <input type="number" name="tahun" id="tahun" class="form-control" min="2000"
                value="<?php echo date('Y'); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Filter</button>
          </form>
        </div>
      </div>
    </div>
  </div>


  <!-- JavaScript Bootstrap -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="timeout.js"></script>

</body>

</html>