<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chart Pengumpulan</title>
    <style>
        body {
            background-color: #f8f8f8;
            font-family: Arial, sans-serif;
            height: 50%;
        }

        #chart-container {
            width: 100%;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        #chart-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        #chart {
            height: 100px;
        }
    </style>
</head>

<body>
    <?php
    include 'koneksi.php';

    // Deklarasi variabel untuk menyimpan nilai tahun
    $tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

    // Query untuk mengambil data zakat dan infaq dari tabel zakat_infaq
    $query_zakat = "SELECT MONTH(tanggal) AS bulan, SUM(jumlah) AS jumlah FROM zakat_infaq WHERE pembayaran = 'zakat' AND YEAR(tanggal) = '$tahun' GROUP BY bulan";
    $result_zakat = mysqli_query($koneksi, $query_zakat);

    $query_infaq = "SELECT MONTH(tanggal) AS bulan, SUM(jumlah) AS jumlah FROM zakat_infaq WHERE pembayaran = 'infaq dan shadaqoh' AND YEAR(tanggal) = '$tahun' GROUP BY bulan";
    $result_infaq = mysqli_query($koneksi, $query_infaq);
    ?>

    <div id="chart-container">
        <h2 id="chart-title">Total Transaksi Zakat dan Infaq</h2>
        <canvas id="chart"></canvas>
    </div>

</body>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Ambil data dari PHP dan simpan dalam variabel JavaScript
    var data_zakat = <?php
                        $data_zakat = array();
                        while ($row = mysqli_fetch_assoc($result_zakat)) {
                            $data_zakat[] = $row;
                        }
                        echo json_encode($data_zakat);
                    ?>;

    var data_infaq = <?php
                        $data_infaq = array();
                        while ($row = mysqli_fetch_assoc($result_infaq)) {
                            $data_infaq[] = $row;
                        }
                        echo json_encode($data_infaq);
                    ?>;

    // Buat fungsi untuk membuat diagram batang
    function createBarChart() {
        var ctx = document.getElementById('chart').getContext('2d');

        var chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data_zakat.map(function (item) {
                    return item.bulan;
                }), // Ambil bulan sebagai label
                datasets: [{
                    label: 'Zakat',
                    data: data_zakat.map(function (item) {
                        return item.jumlah;
                    }), // Ambil jumlah zakat sebagai data
                    backgroundColor: 'rgba(51, 122, 183, 1)', // Warna latar belakang batang zakat
                    borderColor: 'rgba(51, 122, 183, 1)', // Warna garis batang zakat
                    borderWidth: 1
                }, {
                    label: 'Infaq',
                    data: data_infaq.map(function (item) {
                        return item.jumlah;
                    }), // Ambil jumlah infaq sebagai data
                    backgroundColor: 'rgba(220, 53, 69, 1)', // Warna latar belakang batang infaq
                    borderColor: 'rgba(220, 53, 69, 1)', // Warna garis batang infaq
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function (value, index, values) {
                                return 'Rp ' + value.toLocaleString();
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true
                    },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                return 'Rp ' + context.parsed.y.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }

    // Panggil fungsi untuk membuat diagram batang saat halaman selesai dimuat
    document.addEventListener('DOMContentLoaded', createBarChart);
</script>

</html>
