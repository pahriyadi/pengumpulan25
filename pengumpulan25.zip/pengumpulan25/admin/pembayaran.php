<?php
function generatePembayaranOptions($selectedValue = '') {
    $options = [
        "zakat maal perorangan via upz",
        "zakat maal perorangan",
        "zakat maal badan",
        "zakat fitrah via upz",
        "zakat fitrah",
        "zakat fitrah offbalacesheet",
        "infak/sedekah tidak terikat perorangan",
        "infak/sedekah tidak terikat perorangan via upz",
        "infak/sedekah terikat",
        "infak penyaluran",
        "infak operasional",
        "CSR",
        "kurban",
        "kurban via upz",
        "fidyah",
        "DSKL",
        "DSKL lainnya via upz",
        "dana titipan penyaluran",
        "dana hibah APBD/APBD-P",
    ];
    
    foreach ($options as $option) {
        $selected = ($selectedValue === $option) ? 'selected' : '';
        echo "<option value='$option' $selected>$option</option>";
    }
}
?>
