<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabel Zakat dan Donasi</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">BAZNAS KABUPATEN SUMBAWA</h2>
        <h3 class="mb-4">REKAP DATA ZAKAT, INFAQ DAN SHADAQOH</h3>
        
        <!-- Form Pencarian Data Berdasarkan Tahun -->
        <form method="get" action="">
            <div class="form-group row">
                <label for="tahun" class="col-sm-2 col-form-label">Masukkan Tahun:</label>
                <div class="col-sm-4">
                    <input type="number" class="form-control" id="tahun" name="tahun" required>
                </div>
                <div class="col-sm-2">
                    <button type="submit" class="btn btn-primary">Cari</button>
                </div>
            </div>
        </form>

        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th rowspan="2">NO</th>
                    <th rowspan="2">BULAN</th>
                    <th colspan="2">ZAKAT</th>
                    <th rowspan="2">INFAK DAN SEDEKAH</th>
                    <th rowspan="2">DSKL</th>
                    <th rowspan="2">TOTAL</th>
                </tr>
                <tr>
                    <th>ZAKAT MAAL</th>
                    <th>ZAKAT FITRAH</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'koneksi.php';

                // Deklarasi variabel untuk menyimpan nilai tahun
                $tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

                // Array bulan dalam bahasa Indonesia
                $bulan = [
                    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
                    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
                ];

                // Query untuk mengambil data zakat maal
                $query_zakat_maal = "SELECT MONTH(tanggal) AS bulan, SUM(jumlah) AS jumlah 
                                     FROM zakat_infaq 
                                     WHERE pembayaran = 'zakat' 
                                     AND YEAR(tanggal) = '$tahun' 
                                     GROUP BY bulan";
                                     
                // Query untuk mengambil data zakat fitrah
                $query_zakat_fitrah = "SELECT MONTH(tanggal_pembayaran) AS bulan, SUM(nilai_uang) AS nilai_uang 
                                     FROM zakat_fitrah
                                     WHERE niat_pembayaran = 'zakat_fitrah' 
                                     AND YEAR(tanggal_pembayaran) = '$tahun' 
                                     GROUP BY bulan";

                // Query untuk mengambil data infaq dan shadaqoh
                $query_infaq_sedekah = "SELECT MONTH(tanggal) AS bulan, SUM(jumlah) AS jumlah 
                                        FROM zakat_infaq 
                                        WHERE pembayaran = 'infaq dan shadaqoh' 
                                        AND YEAR(tanggal) = '$tahun' 
                                        GROUP BY bulan";

                $result_zakat_maal = mysqli_query($koneksi, $query_zakat_maal);
                $result_zakat_fitrah = mysqli_query($koneksi, $query_zakat_fitrah);
                $result_infaq_sedekah = mysqli_query($koneksi, $query_infaq_sedekah);

                // Mengecek hasil query dan menyimpan data dalam array
                $data_zakat_maal = [];
                $data_zakat_fitrah = [];
                $data_infaq_sedekah = [];

                if(mysqli_num_rows($result_zakat_maal) > 0) {
                    while($row = mysqli_fetch_assoc($result_zakat_maal)) {
                        $data_zakat_maal[$row['bulan']] = $row['jumlah'];
                    }
                }

                if(mysqli_num_rows($result_infaq_sedekah) > 0) {
                    while($row = mysqli_fetch_assoc($result_infaq_sedekah)) {
                        $data_infaq_sedekah[$row['bulan']] = $row['jumlah'];
                    }
                }
                
                if(mysqli_num_rows($result_zakat_fitrah) > 0) {
                    while($row = mysqli_fetch_assoc($result_zakat_fitrah)) {
                        $data_zakat_fitrah[$row['bulan']] = $row['nilai_uang'];
                    }
                }

                // Generate rows untuk setiap bulan
                $total_maal = 0;
                $total_infaq = 0;
                for ($i = 0; $i < count($bulan); $i++) {
                    $zakat_maal = isset($data_zakat_maal[$i+1]) ? $data_zakat_maal[$i+1] : 0;
                    $zakat_fitrah = isset($data_zakat_fitrah[$i+1]) ? $data_zakat_fitrah[$i+1] : 0;  // Placeholder untuk Zakat Fitrah
                    $infaq_sedekah = isset($data_infaq_sedekah[$i+1]) ? $data_infaq_sedekah[$i+1] : 0;
                    $total_bulan = $zakat_maal + $zakat_fitrah + $infaq_sedekah;

                    $total_maal += $zakat_maal;
                    $total_infaq += $infaq_sedekah;

                    echo "<tr>";
                    echo "<td>" . ($i + 1) . "</td>";
                    echo "<td>" . $bulan[$i] . "</td>";
                    echo "<td>Rp " . number_format($zakat_maal, 2, ',', '.') . "</td>";
                    echo "<td>Rp " . number_format($zakat_fitrah, 2, ',', '.') . "</td>";
                    echo "<td>Rp " . number_format($infaq_sedekah, 2, ',', '.') . "</td>";
                    echo "<td>Rp " . number_format($dskl, 2, ',', '.') . "</td>";
                    echo "<td>Rp " . number_format($total_bulan, 2, ',', '.') . "</td>";
                    echo "</tr>";
                }

                // Total keseluruhan
                $total_semua = $total_maal + $total_infaq;
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="2">TOTAL</th>
                    <th>Rp <?= number_format($total_maal, 2, ',', '.') ?></th>
                    <th>Rp 0</th>
                    <th>Rp <?= number_format($total_infaq, 2, ',', '.') ?></th>
                    <th>Rp 0</th>
                    <th>Rp <?= number_format($total_semua, 2, ',', '.') ?></th>
                </tr>
            </tfoot>
        </table>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
