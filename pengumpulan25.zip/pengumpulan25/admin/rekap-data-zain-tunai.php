<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan ZIS Langsung</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">
    <style>
    /* gaya-gaya lainnya */

    /* gaya-gaya lainnya */
    table {
        border-collapse: collapse;
        width: 90%;
        font-size: 14px;
        margin-left: auto;
        margin-right: auto;
    }

    th,
    td {
        text-align: center;
        padding: 10px;
        text-transform: uppercase;
    }

    th {
        background-color: #fff;
        color: black;
        text-transform: uppercase;
    }

    td {
        text-align: center;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #ddd;
    }

    .action a.edit {
        background-color: #5cb85c;
    }

    .action a.delete {
        background-color: #d9534f;
    }

    H1 {
        text-align: center;
        font-size: 20px;
        padding-bottom: 0px;
    }

    .ttd {
        margin-top: 20px;
        text-align: right;
        font-size: 15px;
        margin-right: 50px;
    }

    .ttd p {
        margin-bottom: 0.5px;
        font-weight: bold;
    }

    .ttd {
        margin-top: 20px;
        font-size: 15px;
        align-items: center;
    }

    .ttd p {
        margin-bottom: 0.5px;
        font-weight: bold;
        align-items: center;
    }

    body {
        font-family: "montserrat", sans-serif;
        font-size: 14px;
        padding: 5px;
    }

    .hidden-button {
        position: absolute;
        top: -9999px;
        left: -9999px;
    }

    @media print {

        /* CSS untuk bagian yang akan diprint */
        body {
            font-size: 14px;
        }

        .printable {
            display: block;
        }

        .non-printable {
            display: none;
        }

        /* Aturan untuk mode lanskap */
        @page {
            size: portrait;
        }
    }
    </style>
</head>

<body>
    <div class="non-printable">

        <!-- Button trigger modal -->
        <button type="button" class="hidden-button" data-toggle="modal" data-target="#filterModal" accesskey="z">
            Filter
        </button>

        <?php
        // Koneksi ke database
        include 'koneksi.php';

        include 'navbar.php';

        // Cek apakah form pencarian disubmit
        if (isset($_POST['submit'])) {
            // Ambil bulan dan tahun dari input form
            $bulan = $_POST['bulan'];
            $tahun = $_POST['tahun'];

            // Query untuk mengambil data dari database berdasarkan bulan dan tahun
            $query = "SELECT 
                          tanggal,
                          nama_muzaki,
                          SUM(CASE WHEN pembayaran = 'zakat' THEN jumlah ELSE 0 END) AS total_zakat,
                          SUM(CASE WHEN pembayaran = 'infaq dan shadaqoh'  THEN jumlah ELSE 0 END) AS total_infaq_shadaqah,
                          SUM(jumlah) AS total_jumlah
                      FROM zakat_infaq
                      WHERE MONTH(tanggal) = $bulan AND YEAR(tanggal) = $tahun AND metode_bayar = 'tunai'
                      GROUP BY nomor_induk_muzaki
                      ORDER BY tanggal ASC";

            $result = mysqli_query($koneksi, $query);

            // Cek apakah ada data yang ditemukan
            if (mysqli_num_rows($result) > 0) {
                echo "";
            } else {
                echo "<h3>Data tidak ditemukan</h3>";
            }
        }
        ?>
    </div>

    <div class="printtable">

        <?php
        // Cek apakah ada hasil pencarian
        if (isset($result)) {
            if (mysqli_num_rows($result) > 0) {
        ?>
        <h1>BAZNAS KABUPATEN SUMBAWA</h1>
        <h1>REKAP TRANSAKSI PENGUMPULAN ZAKAT, INFAQ, DAN SHADAQAH LANGSUNG</h1>
        <h1>BULAN <?php echo $bulan; ?> TAHUN <?php echo $tahun; ?></h1>

        <!-- Tabel untuk menampilkan data -->
        <table border="1">
            <thead>
                <tr>
                    <th style="width: 5%;">No.</th>
                    <th style="width: 15%;">Tanggal</th>
                    <th style="width: 25%;">Nama Muzaki</th>
                    <th style="width: 20%;">Zakat</th>
                    <th style="width: 20%;">Infaq dan Shadaqah</th>
                    <th style="width: 15%;">Jumlah</th>
                </tr>
            </thead>
            <tbody>
                <?php
                        $counter = 1;
                        $totalZakat = 0;
                        $totalInfaqShadaqah = 0;
                        $totalJumlah = 0;
                        while ($row = mysqli_fetch_assoc($result)) {
                            $totalZakat += $row['total_zakat'];
                            $totalInfaqShadaqah += $row['total_infaq_shadaqah'];
                            $totalJumlah += $row['total_jumlah'];
                        ?>
                <tr>
                    <td style="text-align: center;"><?php echo $counter; ?></td>
                    <td><?php echo date_format(date_create($row['tanggal']), 'd/m/Y'); ?></td>
                    <td style="text-align: left;"><?php echo $row['nama_muzaki']; ?></td>
                    <td><?php echo number_format($row['total_zakat'], 2, ',', '.'); ?></td>
                    <td><?php echo number_format($row['total_infaq_shadaqah'], 2, ',', '.'); ?></td>
                    <td><?php echo number_format($row['total_jumlah'], 2, ',', '.'); ?></td>
                </tr>
                <?php
                            $counter++;
                        }
                        ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3" style="text-align: center;">Total:</th>
                    <th><?php echo number_format($totalZakat, 2, ',', '.'); ?></th>
                    <th><?php echo number_format($totalInfaqShadaqah, 2, ',', '.'); ?></th>
                    <th><?php echo number_format($totalJumlah, 2, ',', '.'); ?></th>
                </tr>
            </tfoot>
        </table><br>

<p style="margin-left: 700px; font-weight: bold;">Sumbawa Besar, <?php echo date('d F Y'); ?></p>
<div style="display: flex; margin-left:1px;">
<div style="margin-left: 80px;">
<p style= "text-align: center;">Mengetahui,</p>
<p style= "text-align: center;">Ketua BAZNAS Kab. Sumbawa</p><br><br><br><br>
<p style= "text-align: center; font-weight: bold;">H. M. Ali Tunru, S.Sos</p>
</div>

<div style="margin-left:80px;">
<p style= "text-align: center;">Wakil Ketua I,</p>
<p style= "text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
<p style= "text-align: center; font-weight: bold;">Madroni, SHI</p>
</div>

<div style="margin-left:80px;">
<p style= "text-align: center;">Bidang Pengumpulan,</p>
<p style= "text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
<p style= "text-align: center; font-weight: bold;">Pahriyadi, S.Ap</p>
</div>
</div>
        <?php
            }
        }
        ?>
    </div>

    <?php
    // Tutup koneksi database
    mysqli_close($koneksi);
    ?>

    <!-- Modal -->
    <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="filterModalLabel">Filter Berdasarkan Tahun</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="bulan">Bulan:</label>
                            <select name="bulan" id="bulan" class="form-control">
                                <option value="1">Januari</option>
                                <option value="2">Februari</option>
                                <option value="3">Maret</option>
                                <option value="4">April</option>
                                <option value="5">Mei</option>
                                <option value="6">Juni</option>
                                <option value="7">Juli</option>
                                <option value="8">Agustus</option>
                                <option value="9">September</option>
                                <option value="10">Oktober</option>
                                <option value="11">November</option>
                                <option value="12">Desember</option>
                            </select>
                            <label for="tahun">Tahun:</label>
                            <input class="form-control" type="text" name="tahun" id="tahun"
                                value="<?php echo date('Y'); ?>">
                        </div>
                        <button type="submit" name="submit" value="Cari" class="btn btn-primary">Filter</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="timeout.js"></script>

</body>
<div class="non-printable">
    <?php include 'foother.php'; ?>
</div>

</html>