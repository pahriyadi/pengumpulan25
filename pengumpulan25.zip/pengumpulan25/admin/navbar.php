<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  
  <title>BAZNAS SUMBAWA</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
    }

    nav {
      height: 35px;
      background-color: #2c3e50;
      display: flex;
      align-items: center;
      padding: 0 10px;
    }

    nav ul {
      list-style: none;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    nav ul li {
      position: relative;
    }

    nav a {
      color: white;
      text-decoration: none;
      font-size: 14px;
      padding: 5px 8px;
      display: block;
    }

    nav a:hover {
      background-color: #34495e;
      border-radius: 3px;
    }

    .sub-menu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      background-color: #2c3e50;
      padding: 5px 0;
      z-index: 100;
      min-width: 200px;
    }

    .sub-menu li {
      width: 100%;
    }

    nav li:hover > .sub-menu {
      display: block;
    }

    .sub-menu .sub-menu {
      left: 100%;
      top: 0;
    }

    .arrow {
      margin-left: 5px;
      font-size: 10px;
    }

    @media (max-width: 768px) {
      nav ul {
        flex-direction: column;
        align-items: flex-start;
      }
    }

    /* Media query untuk tampilan mobile (lebar maksimal 767px) */
@media (max-width: 767px) {
    body {
        font-size: 14px;
        /* Ukuran font yang lebih kecil untuk perangkat mobile */
    }

    /* Contoh lain: Menyembunyikan elemen tertentu di perangkat mobile */
    .hide-on-mobile {
        display: none;
    }
}

/* Media query untuk tampilan tablet (lebar antara 768px dan 1024px) */
@media (min-width: 768px) and (max-width: 1024px) {

    /* Contoh: Mengatur lebar kontainer untuk tablet */
    .container {
        width: 80%;
    }
}

/* Media query untuk tampilan desktop (lebar minimal 1025px) */
@media (min-width: 1025px) {

    /* Contoh: Mengatur lebar kontainer untuk desktop */
    .container {
        width: 60%;
    }
}
  </style>
</head>
<body>
    
  <nav>
    <ul>
      <li><a href="dashboard.php">DASHBOARD</a></li>
      <li><a href="database-transaksi.php">DATABASE</a></li>
      <li>
        <a href="#">LAPORAN ▾</a>
        <ul class="sub-menu">
          <li>
            <a href="#">Zakat ▸</a>
            <ul class="sub-menu">
              <li><a href="laporan-harian-zakat.php">Transaksi Harian</a></li>
              <li><a href="laporan-harian-zakat-langsung.php">Transaksi Harian Tunai</a></li>
              <li><a href="laporan-zakat-bulanan.php">Transaksi Bulanan</a></li>
              <li><a href="laporan-zakat-tahunan.php">Rekap Bulan (Tahun)</a></li>
            </ul>
          </li>
          <li>
            <a href="#">Infaq ▸</a>
            <ul class="sub-menu">
              <li><a href="laporan-harian-infaq.php">Transaksi Harian</a></li>
              <li><a href="laporan-harian-infaq-langsung.php">Transaksi Harian Tunai</a></li>
              <li><a href="laporan-infaq-bulanan.php">Transaksi Bulanan</a></li>
              <li><a href="laporan-infaq-tahunan.php">Rekap Bulan (Tahun)</a></li>
            </ul>
          </li>
          <li>
            <a href="#">Triwulan ▸</a>
            <ul class="sub-menu">
              <li><a href="laporan-triwulan1.php">Triwulan 1</a></li>
              <li><a href="laporan-triwulan2.php">Triwulan 2</a></li>
              <li><a href="laporan-triwulan3.php">Triwulan 3</a></li>
              <li><a href="laporan-triwulan4.php">Triwulan 4</a></li>
            </ul>
          </li>
          <li><a href="rekap-data-zain.php">Rekap Harian ZIS</a></li>
          <li><a href="data-muzaki-baznas.php">Data Muzaki</a></li>
          <li><a href="data_upz.php">Data UPZ</a></li>
          <li><a href="data_pengurus_upz.php">Data Pengurus UPZ</a></li>
          <li><a href="hak-amil-upz.php">Hak Amil UPZ</a></li>
          <li><a href="multi-filter-zakat-infaq.php">Multi Filter</a></li>
          <li><a href="laporan-zakatinfaq-bulanan-tf-tunai.php">Rekap Bulan Zakat Infaq TF Tunai</a></li>
          <li><a href="laporan-zakatinfaq-tahunan.php">Rekap Tahun Zakat Infaq</a></li>
          <li><a href="laporan-realisasi.php">Laporan Realisasi</a></li>
        </ul>
      </li>
      <li>
        <a href="#">HARDFILE ▾</a>
        <ul class="sub-menu">
          <li><a href="../../file-data/index.php">Arsip Dokumen</a></li>
          <li><a href="status_muzaki.php">Status Muzaki</a></li>
          <li><a href="#">Peraturan BAZNAS</a></li>
          <li><a href="#">Arsip Surat</a></li>
        </ul>
      </li>
      <li><a href="/fitrah/dashboard.php">ZAFI-TDB</a></li>
      <li><a href="/index.php">LOG OUT</a></li>
    </ul>
  </nav>
 
</body>
</html>
<br>