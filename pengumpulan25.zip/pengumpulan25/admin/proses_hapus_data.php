<?php
// Mengecek apakah permintaan POST berisi ID
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // Koneksi ke database
    include 'koneksi.php';

    if ($koneksi->connect_error) {
        die("Koneksi Gagal: " . $koneksi->connect_error);
    }

    // Menghapus data berdasarkan ID muzaki
    $sql = "DELETE FROM zakat_infaq WHERE id_muzaki = $id";
    if ($koneksi->query($sql) === TRUE) {
        echo "Data berhasil dihapus";
    } else {
        echo "Error: " . $sql . "<br>" . $koneksi->error;
    }

    $koneksi->close();
}
?>
