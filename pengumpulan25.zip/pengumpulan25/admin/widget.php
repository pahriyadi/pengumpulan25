<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <title>Dashboard</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style>
/* Gaya umum yang akan diterapkan di semua perangkat */
body {
    font-size: 16px;
    background: rgb(240, 248, 254);
}



/* Media query untuk tampilan mobile (lebar maksimal 767px) */
@media (max-width: 767px) {
    body {
        font-size: 14px;
        /* Ukuran font yang lebih kecil untuk perangkat mobile */
    }

    /* Contoh lain: Menyembunyikan elemen tertentu di perangkat mobile */
    .hide-on-mobile {
        display: none;
    }
}

/* Media query untuk tampilan tablet (lebar antara 768px dan 1024px) */
@media (min-width: 768px) and (max-width: 1024px) {

    /* Contoh: Mengatur lebar kontainer untuk tablet */
    .container {
        width: 80%;
    }
}

/* Media query untuk tampilan desktop (lebar minimal 1025px) */
@media (min-width: 1025px) {

    /* Contoh: Mengatur lebar kontainer untuk desktop */
    .container {
        width: 60%;
    }
}
</style>

<body>
    <div class="container">
        
        <!-- ---------------------------------------------------------------->
        <div class="card">
            <div class="card-header">Cari Data</div>
            <div class="card-body">
                <!-- Form untuk memasukkan nama bulan -->
                <form method="GET" action="" style="display: flex; gap:5px;">
                    <select id="bulan" name="bulan" class="form-control">
                        <option value="">Pilih Bulan</option>
                        <option value="January">Januari</option>
                        <option value="February">Februari</option>
                        <option value="March">Maret</option>
                        <option value="April">April</option>
                        <option value="May">Mei</option>
                        <option value="June">Juni</option>
                        <option value="July">Juli</option>
                        <option value="August">Agustus</option>
                        <option value="September">September</option>
                        <option value="October">Oktober</option>
                        <option value="November">November</option>
                        <option value="December">Desember</option>
                    </select>
                    <label for="tahun"></label>
                    <input id="tahun" name="tahun" class="form-control" placeholder="ketikan tahun yang anda cari">
                    <button type="submit" class="btn btn-success btn-sm">Filter</button>
                </form>
            </div>
            <div class="card-footer"></div>
        </div><br>
        <!-- ---------------------------------------------------------------->
       
       <div class="card">
           <div class="card-header">Chart Pengumpulan</div>
           <div class="card-body">
               <?php include 'diagram/dbatangzakat.php'; ?>
           </div>
           <div class="card-footer"></div>
       </div><br>
        <!-- ---------------------------------------------------------------->
        
        <div class="card">
            <div class="card-header">Rekapitulasi Pengumpulan ZIS</div>
            <div class="card-body">
                <?php
include 'koneksi.php';

// Mendapatkan nama bulan dan tahun yang ingin difilter (misalnya "Maret" dan "2023")
$nama_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : '';
$nama_tahun = isset($_GET['tahun']) ? $_GET['tahun'] : '';

$bulan_condition = '';
$tahun_condition = '';
$bulan_condition_pembayaran = '';
$tahun_condition_pembayaran = '';

if ($nama_bulan) {
    $bulan = date_parse($nama_bulan)['month'];
    $bulan_condition = "AND MONTH(tanggal) = '$bulan'";
    $bulan_condition_pembayaran = "AND MONTH(tanggal_pembayaran) = '$bulan'";
}

if ($nama_tahun) {
    $tahun_condition = "AND YEAR(tanggal) = '$nama_tahun'";
    $tahun_condition_pembayaran = "AND YEAR(tanggal_pembayaran) = '$nama_tahun'";
}


// Menghitung jumlah total transaksi zakat untuk widget
$sql_total_zakat = "SELECT SUM(jumlah) AS total_zakat FROM zakat_infaq WHERE pembayaran = 'zakat' $bulan_condition $tahun_condition";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat = $result_total_zakat->fetch_assoc()['total_zakat'];

// Menghitung jumlah total transaksi infaq untuk widget
$sql_total_infaq = "SELECT SUM(jumlah) AS total_infaq FROM zakat_infaq WHERE pembayaran = 'infaq dan shadaqoh' $bulan_condition $tahun_condition";
$result_total_infaq = $koneksi->query($sql_total_infaq);
$total_infaq = $result_total_infaq->fetch_assoc()['total_infaq'];

// Menghitung jumlah total transaksi zakat dan infaq untuk widget
$sql_total_zakatinfaq = "SELECT SUM(jumlah) AS total_zakatinfaq FROM zakat_infaq WHERE pembayaran IN ('zakat', 'infaq dan shadaqoh', 'infaq dan shadaqoh terikat') $bulan_condition $tahun_condition";
$result_total_zakatinfaq = $koneksi->query($sql_total_zakatinfaq);
$total_zakatinfaq = $result_total_zakatinfaq->fetch_assoc()['total_zakatinfaq'];

// Menghitung jumlah total transaksi infaq tunai untuk widget
$sql_total_tunai = "SELECT SUM(jumlah) AS total_tunai FROM zakat_infaq WHERE pembayaran = 'infaq dan shadaqoh' AND metode_bayar = 'tunai' $bulan_condition $tahun_condition";
$result_total_tunai = $koneksi->query($sql_total_tunai);
$total_tunai = $result_total_tunai->fetch_assoc()['total_tunai'];

// Menghitung jumlah total transaksi zakat tunai untuk widget
$sql_total_trf = "SELECT SUM(jumlah) AS total_trf FROM zakat_infaq WHERE pembayaran = 'infaq dan shadaqoh' AND metode_bayar = 'transfer bank' $bulan_condition $tahun_condition";
$result_total_trf = $koneksi->query($sql_total_trf);
$total_trf = $result_total_trf->fetch_assoc()['total_trf'];

// Menghitung jumlah total transaksi infaq tunai untuk widget
$sql_total_tunai2 = "SELECT SUM(jumlah) AS total_tunai2 FROM zakat_infaq WHERE pembayaran = 'zakat' AND metode_bayar = 'tunai' $bulan_condition $tahun_condition";
$result_total_tunai2 = $koneksi->query($sql_total_tunai2);
$total_tunai2 = $result_total_tunai2->fetch_assoc()['total_tunai2'];

// Menghitung jumlah total transaksi zakat tunai untuk widget
$sql_total_trf2 = "SELECT SUM(jumlah) AS total_trf2 FROM zakat_infaq WHERE pembayaran = 'zakat' AND metode_bayar = 'transfer bank' $bulan_condition $tahun_condition";
$result_total_trf2 = $koneksi->query($sql_total_trf2);
$total_trf2 = $result_total_trf2->fetch_assoc()['total_trf2'];

// Menghitung jumlah total transaksi zakat tunai untuk PERORANGAN
$sql_total_zorang = "SELECT SUM(jumlah) AS total_zorang FROM zakat_infaq WHERE pembayaran = 'zakat' AND status_muzaki IN ('perorangan', 'A/N') $bulan_condition $tahun_condition";
$result_total_zorang = $koneksi->query($sql_total_zorang);
$total_zorang = $result_total_zorang->fetch_assoc()['total_zorang'];

// Menghitung jumlah total transaksi zakat tunai untuk DINAS/INSTANSI
$sql_total_dinas = "SELECT SUM(jumlah) AS total_dinas FROM zakat_infaq WHERE pembayaran = 'zakat' AND status_muzaki IN ('dinas instansi', 'sekolah', 'bank', 'BUMN', 'BUMD') $bulan_condition $tahun_condition";
$result_total_dinas = $koneksi->query($sql_total_dinas);
$total_dinas = $result_total_dinas->fetch_assoc()['total_dinas'];

// Menghitung jumlah total transaksi INFAQ tunai untuk PERORANGAN
$sql_total_zorang1 = "SELECT SUM(jumlah) AS total_zorang1 FROM zakat_infaq WHERE pembayaran = 'infaq dan shadaqoh' AND status_muzaki IN ('perorangan', 'A/N') $bulan_condition $tahun_condition";
$result_total_zorang1 = $koneksi->query($sql_total_zorang1);
$total_zorang1 = $result_total_zorang1->fetch_assoc()['total_zorang1'];

// Menghitung jumlah total transaksi INFAQ tunai untuk DINAS/INSTANSI
$sql_total_dinas1 = "SELECT SUM(jumlah) AS total_dinas1 FROM zakat_infaq WHERE pembayaran = 'infaq dan shadaqoh' AND status_muzaki IN ('dinas instansi', 'sekolah', 'bank', 'BUMN', 'BUMD') $bulan_condition $tahun_condition";
$result_total_dinas1 = $koneksi->query($sql_total_dinas1);
$total_dinas1 = $result_total_dinas1->fetch_assoc()['total_dinas1'];

// Menghitung jumlah total transaksi INFAQ tunai untuk DINAS/INSTANSI
$sql_total_fitrah = "SELECT SUM(nilai_uang) AS total_fitrah FROM zakat_fitrah WHERE niat_pembayaran IN ('zakat fitrah', 'infaq dan shadaqoh', 'fidyah', 'dskl') AND jenis_pembayaran IN ('uang', 'beras') $bulan_condition_pembayaran $tahun_condition_pembayaran";
$result_total_fitrah = $koneksi->query($sql_total_fitrah);
$total_fitrah = $result_total_fitrah->fetch_assoc()['total_fitrah'];


?>

               <div class="row text-center text-nowrap">
    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header bg-warning text-white">Total zakat & infak sedekah</div>
        <div class="card-body"> <?php echo number_format($total_zakatinfaq, 2, ',', '.'); ?></div>
        </div>
    </div>
    
    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header bg-success text-white"> zakat mall via ft dan tunai</div>
        <div class="card-body"> <?php echo number_format($total_zakat, 2, ',', '.'); ?></div>
        </div>
    </div>
    
    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header text-sm bg-success text-white"> zakat mall via tunai</div>
        <div class="card-body"> <?php echo number_format($total_tunai2, 2, ',', '.'); ?></div>
        </div>
    </div>
    
    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header text-sm bg-success text-white"> zakat mall via transfer/rekening</div>
        <div class="card-body"> <?php echo number_format($total_trf2, 2, ',', '.'); ?></div>
        </div>
    </div>
    
    <div class= col-sm-3 mb-4>
        <div class="card">
        <div class="card-header text-sm bg-success text-white"> zakat mall perorangan</div>
        <div class="card-body"> <?php echo number_format($total_zorang, 2, ',', '.'); ?></div>
        </div>
    </div>
    
    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header text-sm bg-success text-white"> zakat mall perorangan Via UPZ</div>
        <div class="card-body"> <?php echo number_format($total_dinas, 2, ',', '.'); ?></div>
        </div>
    </div>
    
    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header text-sm bg-primary text-white">Total infak</div>
        <div class="card-body"> <?php echo number_format($total_infaq, 2, ',', '.'); ?></div>
        </div>
    </div>

    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header text-sm bg-primary text-white"> infak via tunai</div>
        <div class="card-body"> <?php echo number_format($total_tunai, 2, ',', '.'); ?></div>
        </div>
    </div>

    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header text-sm bg-primary text-white">infak via tf/rekening</div>
        <div class="card-body"> <?php echo number_format($total_trf, 2, ',', '.'); ?></div>
        </div>
    </div>

    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header text-sm bg-primary text-white">infak perorangan</div>
        <div class="card-body"> <?php echo number_format($total_zorang1, 2, ',', '.'); ?></div>
        </div>
    </div>

    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header text-sm bg-primary text-white">infak perorangan via UPZ</div>
        <div class="card-body"> <?php echo number_format($total_dinas1, 2, ',', '.'); ?></div>
        </div>
    </div>

    <div class= "col-sm-3 mb-4">
        <div class="card">
        <div class="card-header text-sm bg-danger text-white"> Zakat fitrah (OBS)</div>
        <div class="card-body"> <?php echo number_format($total_fitrah, 2, ',', '.'); ?></div>
        </div>
    </div>
</div>


            </div>
            <div class="card-footer">Bidang Penngumpulan BAZNAS Kab. Sumbawa</div>
        </div>
    </div>

    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="timeouts.js"></script>
    
    
    
</body>

</html>