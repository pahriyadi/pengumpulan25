<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">
    <title>Kwitansi Transaksi</title>
    <STYle>
        /* Body */
body {
  background-color: #f7f7f7;
  font-family: 'Open Sans', sans-serif;
}

/* Container */
.container {
  width: 400px;
  margin: 50px auto;
  background-color: #fff;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0px 0px 10px #dcdcdc;
}

/* Table */
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 30px;
}

table th {
  font-weight: normal;
  text-align: left;
  padding: 10px;
  background-color: #f2f2f2;
  border-bottom: 1px solid #ddd;
}

table td {
  text-align: right;
  padding: 10px;
  border-bottom: 1px solid #ddd;
}

table td.bold {
  font-weight: bold;
}

/* Signature */
.signature {
  margin-top: 50px;
  text-align: center;
  font-style: italic;
}

.signature p:first-child {
  margin-bottom: 10px;
}

.signature p:last-child {
  margin-top: 50px;
}

    </STYle>
</head>
<body>
<?php
    // Mengakses database dan mengambil data sesuai dengan ID muzaki
    if(isset($_GET['id'])){
        include 'koneksi.php';

        $id_muzaki = $_GET['id'];
        $query = "SELECT * FROM zakat_infaq WHERE id_muzaki = '$id_muzaki'";
        $result = mysqli_query($koneksi, $query);

        // Menampilkan data pada halaman kwitansi
        if(mysqli_num_rows($result) > 0){
            $row = mysqli_fetch_assoc($result);
            $nomor_transaksi = $row['nomor_transaksi'];
            $tanggal = $row['tanggal'];
            $nama_muzaki = $row['nama_muzaki'];
            $jumlah = $row['jumlah'];
            echo '<div class="container">';
            echo '<h1>Kwitansi Transaksi ZIS</h1>';
            echo '<table>';
            echo '<tr>';
            echo '<th>No. Kwitansi</th>';
            echo '<td class="text-right">'.$nomor_transaksi.'</td>';
            echo '</tr>';
            echo '<tr>';
            echo '<th>Tanggal</th>';
            echo '<td class="text-right">'.$tanggal.'</td>';
            echo '</tr>';
            echo '<tr>';
            echo '<th>ID Muzaki</th>';
            echo '<td class="text-right">'.$id_muzaki.'</td>';
            echo '</tr>';
            echo '<tr>';
            echo '<th>Nama</th>';
            echo '<td class="text-right">'.$nama_muzaki.'</td>';
            echo '</tr>';
            echo '<tr>';
            echo '<th>Jumlah Donasi</th>';
            echo '<td class="text-right bold">Rp '.$jumlah.'</td>';
            echo '</tr>';
            echo '</table>';
            echo '<div class="signature">';
            echo '<p>___________________________</p>';
            echo '<p>Nama dan Tanda Tangan</p>';
            echo '<p>Terimakasih sudah menunaikan zakat di BAZNAS Kabupaten Sumbawa</p>';
            echo '</div>';
            echo '</div>';
        } else {
            echo '<p>Data tidak ditemukan.</p>';
        }
    }
?>

<script src="timeout.js"></script>
</body>
</html>



