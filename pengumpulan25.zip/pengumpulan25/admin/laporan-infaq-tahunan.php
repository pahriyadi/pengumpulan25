<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">
    <title>Rekap Total Data Infaq</title>
    <style>
 /* Mengatur tampilan tabel */
 table {
        width: 80%;
        border-collapse: collapse;
        margin-bottom: 20px;
        align-items: center;
        margin-left: auto;
        margin-right: auto;
    }

    /* Mengatur style untuk header tabel */
    th {
        background-color: #f2f2f2;
        text-align: center;
        padding: 8px;
        border: 1px solid #ddd;
    }

    /* Mengatur style untuk baris genap pada tabel */
    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    /* Mengatur style untuk baris ganjil pada tabel */
    tr:nth-child(odd) {
        background-color: #fff;
    }

    /* Mengatur style untuk sel pada tabel */
    td {
        text-align: center;
        padding: 8px;
        border: 1px solid #ddd;
    }
    h2 {
      text-align: center;
    }

.ttd {
  margin-top: 20px;
  text-align: right;
  font-size: 15px;
  Margin-right:100px;
  
}

.ttd p {
  margin-bottom: 0.5px;
  font-weight: bold;
}


@media print {

      /* CSS untuk bagian yang akan diprint */
      body {
        font-size: 14px;
      }

      .printable {
        display: block;
      }

      .non-printable {
        display: none;
      }

      /* Aturan untuk mode lanskap */
      @page {
        size: landscape;
      }
    }

    </style>
</head>
<body>
    
<div class="non-printable">
<?php include 'navbar.php'; ?>


<?php
// Mendapatkan nama bulan dan tahun yang ingin difilter (misalnya "Maret" dan "2023")
$nama_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : '';
$nama_tahun = isset($_GET['tahun']) ? $_GET['tahun'] : '';

$bulan_condition = '';
$tahun_condition = '';

if ($nama_bulan) {
    $bulan = date_parse($nama_bulan)['month'];
    $bulan_condition = "AND MONTH(tanggal) = '$bulan'";
}

if ($nama_tahun) {
    $tahun_condition = "AND YEAR(tanggal) = '$nama_tahun'";
}

?>


<!-- Form untuk memasukkan nama bulan -->
<form method="GET" action="" style="margin-left: 80px; margin-right: 100px; display: flex;">
    <label for="tahun"></label>
    <input class="form-control" id="tahun" name="tahun" class="form-control" placeholder="ketikan tahun yang anda cari">
    <button type="submit" class="btn btn-primary">Filter</button>
</form><br>
</div>

<?php
include 'koneksi.php';

// Mendapatkan nilai tahun dari input atau menggunakan nilai default jika tidak ada input
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// Query untuk mengambil data infaq dan shadaqoh dari tabel zakat_infaq berdasarkan tahun
$query = "SELECT MONTH(tanggal) AS bulan, SUM(jumlah) AS jumlah FROM zakat_infaq WHERE (pembayaran = 'infaq dan shadaqoh' OR pembayaran = 'infaq dan shadaqoh') AND YEAR(tanggal) = $tahun GROUP BY bulan";
$result = mysqli_query($koneksi, $query);

// Mengecek apakah query berhasil dieksekusi
if (mysqli_num_rows($result) > 0) {
    // Menampilkan tabel rekap data infaq dan shadaqoh
    echo '<h2>BAZNAS KABUPATEN SUMBAWA</h2>';
    echo '<h2>REKAP DATA TAHUNAN INFAQ DAN SHADAQOH TAHUN ' . $tahun . '</h2>';
    echo '<table>';
    echo '<thead>';
    echo '<tr>';
    echo '<th style="width: 20%;">NO</th>';
    echo '<th>BULAN</th>';
    echo '<th>JUMLAH</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . $no . '</td>';
        echo '<td>' . date('F', mktime(0, 0, 0, $row['bulan'], 10)) . '</td>';
        echo '<td>Rp ' . number_format($row['jumlah'], 2, ',', '.') . '</td>';
        echo '</tr>';
        $no++;
    }
    echo '</tbody>';
    echo '<tfoot>';
    echo '<tr>';
    echo '<th colspan="2">TOTAL</th>';
    $query_total = "SELECT SUM(jumlah) AS total FROM zakat_infaq WHERE (pembayaran = 'infaq dan shadaqoh' OR pembayaran = 'infaq dan shadaqoh') AND YEAR(tanggal) = $tahun";
    $result_total = mysqli_query($koneksi, $query_total);
    $row_total = mysqli_fetch_assoc($result_total);
    echo '<td>Rp ' . number_format($row_total['total'], 2, ',', '.') . '</td>';
    echo '</tr>';
    echo '</tfoot>';
    echo '</table>';
} else {
    echo '<p>Belum Ada Data.</p>';
}

// Menutup koneksi ke database
mysqli_close($koneksi);
?>


<p style="margin-left: 700px; font-weight: bold;">Sumbawa Besar, <?php echo date('d F Y'); ?></p>
<div style="display: flex; margin-left:10px;">
<div style="margin-left: 100px;">
<p style= "text-align: center;">Mengetahui,</p>
<p style= "text-align: center;">Ketua BAZNAS Kab. Sumbawa</p><br><br><br><br>
<p style= "text-align: center; font-weight: bold;">H. M. Ali Tunru, S.Sos</p>
</div>

<div style="margin-left:100px;">
<p style= "text-align: center;">Wakil Ketua I,</p>
<p style= "text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
<p style= "text-align: center; font-weight: bold;">Madroni, SHI</p>
</div>

<div style="margin-left:100px;">
<p style= "text-align: center;">Bidang Pengumpulan,</p>
<p style= "text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
<p style= "text-align: center; font-weight: bold;">Pahriyadi, S.Ap</p>
</div>
</div>

<script src="timeout.js"></script>

</body>
</html>



