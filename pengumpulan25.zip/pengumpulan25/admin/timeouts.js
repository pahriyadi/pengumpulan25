
        // Atur waktu timeout dalam milidetik (1 menit = 60000 milidetik)
        var timeoutInMilliseconds = 900000; // 1 menit

        // Fungsi untuk melakukan logout
        function logout() {
            // Lakukan tindakan logout di sini, seperti mengarahkan pengguna ke halaman logout
            window.location.href = "../../index.php";
            
            // Hapus riwayat navigasi
            window.history.pushState({}, '', '/');
            window.addEventListener('popstate', function () {
                if (document.location.pathname === '/') {
                    window.history.pushState({}, '', '/');
                }
            });
        }

        // Fungsi untuk mereset timeout
        function resetTimeout() {
            clearTimeout(timeout);
            timeout = setTimeout(logout, timeoutInMilliseconds);
        }

        // Event listener untuk setiap aktivitas pengguna
        document.addEventListener('mousemove', resetTimeout);
        document.addEventListener('keypress', resetTimeout);

        // Mulai timeout pertama kali
        var timeout = setTimeout(logout, timeoutInMilliseconds);
