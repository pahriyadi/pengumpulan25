<?php
include 'koneksi.php';
include 'navbar.php';

// Fungsi untuk mengambil data dari database
function getData($sortOrder, $searchTerm)
{
    global $koneksi;

    $sql = "SELECT * FROM zakat_infaq";

    // Tambahkan kondisi pengurutan
    if (!empty($sortOrder)) {
        $sql .= " ORDER BY $sortOrder";
    }

    $result = $koneksi->query($sql);

    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    return [];
}

// Atur pengurutan dan pencarian
$sortOrder = isset($_GET['sort']) ? $_GET['sort'] : 'id_muzaki DESC';
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Ambil data dari database
$data = getData($sortOrder, $searchTerm);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BAZNAS SUMBAWA</title>
    <!-- Sertakan Bootstrap CSS dari CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <!-- Sertakan DataTables CSS dari CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-XXX" crossorigin="anonymous" />
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .table thead th {
            background-color: #007bff;
            color: #ffffff;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .btn {
            margin-right: 5px;
        }

        .modal-header {
            background-color: #007bff;
            color: #ffffff;
        }

        .modal-footer .btn {
            background-color: #007bff;
            color: #ffffff;
        }

        .modal-footer .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>

    <div class="container">
        <h2 class="text-center">DATABASE TRANSAKSI</h2>

        <table id="muzakiTable" class="table table-responsive table-bordered table-hover">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Nama</th>
                    <th>Status</th>
                    <th>NIM</th>
                    <th>Jumlah</th>
                    <th>K/D</th>
                    <th>Tgl</th>
                    <th>Bayar</th>
                    <th>Metode</th>
                    <th>Sumber</th>
                    <th>Act</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $row): ?>
                    <tr>
                        <td>
                            <?= $row['id_muzaki'] ?>
                        </td>
                        <td>
                            <?= $row['nama_muzaki'] ?>
                        </td>
                        <td>
                            <?= $row['status_muzaki'] ?>
                        </td>
                        <td>
                            <?= $row['nomor_induk_muzaki'] ?>
                        </td>
                        <td>
                            <?= number_format($row['jumlah'], 2, ',', '.'); ?>
                        </td>
                        <td>
                            <?= $row['kredit_debit'] ?>
                        </td>
                        <td>
                            <?= $row['tanggal'] ?>
                        </td>
                        <td>
                            <?= $row['pembayaran'] ?>
                        </td>
                        <td>
                            <?= $row['metode_bayar'] ?>
                        </td>
                        <td>
                            <?= $row['sumber_rekening'] ?>
                        </td>
                        <td>
                            <a href='#myModal' class='btn btn-success btn-sm' id_muzaki='id' data-toggle='modal'
                                data-id="<?php echo $row['id_muzaki']; ?>" title='Tambah Data'><i
                                    class="fas fa-plus"></i></a>
                            <a href='#myModal1' class='btn btn-info btn-sm' id_muzaki='id' data-toggle='modal'
                                data-id="<?php echo $row['id_muzaki']; ?>" title='Edit Data'><i
                                    class="fas fa-pencil-alt"></i></a>
                            <a href='#' class='btn btn-warning btn-sm hapus-data' data-id="<?php echo $row['id_muzaki']; ?>"
                                data-nama="<?php echo $row['nama_muzaki']; ?>" title='Hapus Data'><i
                                    class="fas fa-times"></i></a>
                            <a href='#kwitansiModal' class='btn btn-danger btn-sm' id_muzaki='id' data-toggle='modal'
                                data-id="<?php echo $row['id_muzaki']; ?>" title='Kwitansi'><i
                                    class="fas fa-file-invoice"></i></a>
                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                data-target="#tambahDataModal" title='Tambah Data Baru'><i
                                    class="fas fa-file-invoice"></i></button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php include 'modal_tambah_data.php' ?>

    <!-- Sertakan jQuery dan DataTables JS dari CDN -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready(function () {
            // Inisialisasi DataTables
            var table = $('#muzakiTable').DataTable({
                // Pengaturan tambahan untuk DataTables
                "order": [
                    [0, "desc"]
                ], // Urutkan berdasarkan ID Muzaki secara descending
                "paging": true, // Aktifkan paging
                "lengthChange": true, // Aktifkan pilihan jumlah data per halaman
                "searching": true, // Matikan fitur pencarian bawaan DataTables, gunakan form pencarian di atas
                "info": true, // Tampilkan informasi halaman dan jumlah data
                "autoWidth": true, // Sesuaikan lebar kolom secara otomatis
                "scrollX": true,
                "scrollY": true,
                "columnDefs": true,
                "serverside": true,
            });

            // Set fokus ke kotak pencarian saat halaman dimuat
            $('#muzakiTable_filter input').focus();
        });
    </script>

    <!-- Sertakan Bootstrap JS dari CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous">
    </script>
    <script src="timeouts.js"></script>

</body>

</html>