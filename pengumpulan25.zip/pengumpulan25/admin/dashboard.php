<?php include 'navbar.php'?>
<?php include 'widget.php'?>

    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">
    <title>BAZNAS SUMBAWA</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">