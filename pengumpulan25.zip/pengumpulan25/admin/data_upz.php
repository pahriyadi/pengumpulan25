<?php
// Koneksi ke database
include 'koneksi.php';

// Fungsi untuk melakukan pencarian berdasarkan semua field
function searchUPZ($keyword)
{
    global $koneksi;

    $query = "SELECT * FROM upz WHERE 
        id LIKE '%$keyword%' OR
        username LIKE '%$keyword%' OR
        nama_upz LIKE '%$keyword%' OR
        nomor_induk_upz LIKE '%$keyword%' OR
        alamat_upz LIKE '%$keyword%' OR
        notlp_upz LIKE '%$keyword%' OR
        created_at LIKE '%$keyword%'";
        
    $result = mysqli_query($koneksi, $query);

    return $result;
}

// Inisialisasi variabel pencarian
$keyword = "";
if (isset($_GET['keyword'])) {
    $keyword = $_GET['keyword'];
}

// Lakukan pencarian jika keyword tidak kosong
if (!empty($keyword)) {
    $result = searchUPZ($keyword);
} else {
    // Query untuk menampilkan semua data UPZ
    $query = "SELECT * FROM upz";
    $result = mysqli_query($koneksi, $query);
}
?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="icon" href="\imgs\lobaz.png" type="image/x-icon">
    <title>upz baznas sumbawa</title>
    <style>
    body {
        padding: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        border: 1px solid black;
    }

    th,
    td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: left;
        border: 1px solid black;

    }

    th {
        background-color: #f2f2f2;
        text-align: center;
    }

    @media screen and (max-width: 600px) {
        table {
            font-size: 12px;
        }
    }

    .kop {
        text-align: center;
        margin: 1px;
    }

    .judul {
        text-align: center;
        margin-bottom: 10pxs;
    }

    @media print {

        /* CSS untuk bagian yang akan diprint */
        body {
            font-size: 14px;
        }

        .printable {
            display: block;
        }

        .non-printable {
            display: none;
        }

        /* Aturan untuk mode lanskap */
        @page {
            size: portrait;
        }
    }
    </style>


</head>

<body>
    <div class="non-printable">
        <?php include 'navbar.php'; ?>

        <form style="margin-left: 70px; display: flex; margin-bottom: 10px;" action="" method="get">
            <input class="form-control" style="width: 85%; margin-right: 10px;" type="text" name="keyword"
                value="<?php echo $keyword; ?>" placeholder="Cari data menurut kata kunci....">
            <button class="btn btn-danger" type="submit">Cari</button>
        </form>
    </div>

    <div class="printable">
        <div class="kop">
            <H3>BAZNAS KABUPATEN SUMBAWA</H3>
            <P>Jl. Hasanuddin No. 1 Kelurahan Bugis Sumbawa Besar</P>
            <p>-----------------------------------------------------------------------------------------------</p>
        </div>


        <h3 style="text-align: center;">DAFTAR NAMA UPZ BAZNAS KABUPATEN SUMBAWA</h3>


        <table border="1">
            <tr>
                <th>No</th>
                <th>ID</th>
                <th>Username</th>
                <th>Nama UPZ</th>
                <th>No. Induk UPZ</th>
                <th>Alamat</th>
                <th>No. Tlp</th>
                <th>Tgl Registrasi</th>
                <th>Tgl Kadaluarsa</th>
            </tr>
            <?php
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
        $created_at = $row['created_at'];
        $kadaluarsa = date('d F Y', strtotime('+5 years', strtotime($created_at)));

        setlocale(LC_TIME, 'id_ID');
        $created_at_indonesia = strftime('%d %B %Y', strtotime($created_at));

        $is_expired = strtotime('+5 years', strtotime($created_at)) < time();

        echo "<tr>
                <td style='text-align: center;'>" . $no++ . "</td>
                <td>".$row['id']."</td>
                <td>".$row['username']."</td>
                <td>".$row['nama_upz']."</td>
                <td>".$row['nomor_induk_upz']."</td>
                <td>".$row['alamat_upz']."</td>
                <td>".$row['notlp_upz']."</td>
                <td>".$created_at_indonesia."</td>
                <td style='".($is_expired ? 'color: red;' : '')."'>".$kadaluarsa."</td>
            </tr>";
    }
    ?>
        </table><br>


        <p style="margin-left: 700px; font-weight: bold;">Sumbawa Besar, <?php echo date('d F Y'); ?></p>
        <div style="display: flex; margin-left:10px;">
            <div style="margin-left: 100px;">
                <p style="text-align: center;">Mengetahui,</p>
                <p style="text-align: center;">Ketua BAZNAS Kab. Sumbawa</p><br><br><br><br>
                <p style="text-align: center; font-weight: bold;">H. M. Ali Tunru, S.Sos</p>
            </div>

            <div style="margin-left:100px;">
                <p style="text-align: center;">Wakil Ketua I,</p>
                <p style="text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
                <p style="text-align: center; font-weight: bold;">Madroni, SHI</p>
            </div>

            <div style="margin-left:100px;">
                <p style="text-align: center;">Bidang Pengumpulan,</p>
                <p style="text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
                <p style="text-align: center; font-weight: bold;">Pahriyadi, S.Ap</p>
            </div>
        </div>


</body>

<!-- JavaScript Bootstrap -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="timeout.js"></script>


</html>

<?php
// Tutup koneksi
mysqli_close($koneksi);
?>