<?php
function generateStatusMuzakiOptions($selectedValue = '') {
    $options = [
        "", "Perorangan", "Dinas Instansi", "BANK", "BUMN", "BUMD", "Sekolah", "Masjid/Mushalla"
    ];
    
    foreach ($options as $option) {
        $selected = ($selectedValue === $option) ? 'selected' : '';
        echo "<option value='$option' $selected>$option</option>";
    }
}
?>
