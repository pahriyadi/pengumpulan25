<?php
function generateSumberRekeningOptions($selectedValue = '') {
    $options = [
        "ntb syariah zakat-006",
        "ntb syariah zakat-019",
        "ntb syariah Operasional APBD-018",
        "ntb syariah infak/sedekah-015",
        "rekening penerimaan lainnya",
        "BRI",
        "BSI zakat",
        "BSI infak"
    ];
    
    foreach ($options as $option) {
        $selected = ($selectedValue === $option) ? 'selected' : '';
        echo "<option value='$option' $selected>$option</option>";
    }
}
?>
