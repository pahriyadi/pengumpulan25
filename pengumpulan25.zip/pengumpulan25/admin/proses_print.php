<?php
require_once 'koneksi.php';
require_once 'vendor/autoload.php';

use Dompdf\Dompdf;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$pembayaran = $_POST['pembayaran'];

	$query = "SELECT id, nomor_transaksi, nama_muzaki, pembayaran, jumlah FROM zakat_infaq WHERE pembayaran = '$pembayaran' ORDER BY id ASC";
	$result = mysqli_query($koneksi, $query);

	if (mysqli_num_rows($result) > 0) {
		// Menghasilkan tabel HTML dari hasil filter
		$output = '<table border="1">
						<tr>
							<th>No</th>
							<th>Nomor Transaksi</th>
							<th>Nama Muzaki</th>
							<th>Pembayaran</th>
							<th>Jumlah</th>
						</tr>';

		$no = 1;
		while ($row = mysqli_fetch_assoc($result)) {
			$output .= '<tr>
							<td>'.$no.'</td>
							<td>'.$row['nomor_transaksi'].'</td>
							<td>'.$row['nama_muzaki'].'</td>
							<td>'.$row['pembayaran'].'</td>
							<td>'.$row['jumlah'].'</td>
						</tr>';
			$no++;
		}

		$output .= '</table>';

		// Membuat file PDF dari tabel HTML yang telah dihasilkan
		$dompdf = new Dompdf();
		$dompdf->loadHtml($output);
		$dompdf->setPaper('A4', 'landscape');
		$dompdf->render();
		$dompdf->stream('Data Zakat-Infaq - Pembayaran '.$pembayaran.'.pdf', ['Attachment' => 0]);
	} else {
		echo 'Tidak ada data yang cocok dengan filter yang diberikan';
	}
}
?>
