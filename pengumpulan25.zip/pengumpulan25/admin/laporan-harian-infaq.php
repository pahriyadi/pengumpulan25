<?php
include 'koneksi.php';

// cek apakah form sudah di-submit
if (isset($_POST['submit'])) {
  // filter bulan
  $bulan = mysqli_real_escape_string($koneksi, $_POST['bulan']);

  // filter tahun
  $tahun = mysqli_real_escape_string($koneksi, $_POST['tahun']);

  // filter pembayaran
  $pembayaran = mysqli_real_escape_string($koneksi, $_POST['pembayaran']);

      // filter pembayaran
      $status_muzaki = mysqli_real_escape_string($koneksi, $_POST['status_muzaki']);

  // query untuk filter data berdasarkan bulan, tahun, dan pembayaran
  $query = "SELECT * FROM zakat_infaq WHERE MONTH(tanggal) = '$bulan' AND YEAR(tanggal) = '$tahun' AND pembayaran = '$pembayaran'";

  $result = mysqli_query($koneksi, $query);

  // cek apakah query berhasil
  if (!$result) {
    die("Query error: " . mysqli_error($koneksi));
  }
} else {
  // tampilkan semua data jika form belum di-submit
  $query = "SELECT * FROM zakat_infaq";
  $result = mysqli_query($koneksi, $query);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Filter Data</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">

  <style>
    @media print {

      /* CSS untuk bagian yang akan diprint */
      body {
        font-size: 14px;
      }

      .printable {
        display: block;
      }

      .non-printable {
        display: none;
      }
    }


    .ttd {
      margin-top: 20px;
      text-align: center;
      font-size: 15px;
      align-items: center;
    }

    .ttd p {
      margin-bottom: 0.5px;
      font-weight: bold;
      align-items: center;
    }

    table {
      border-collapse: collapse;
      width: 90%;
      font-size: 14px;
      margin-left: auto;
      margin-right: auto;
    }

    th,
    td {
      text-align: center;
      padding: 10px;
      text-transform: uppercase;
    }

    th {
      background-color: #fff;
      color: black;
      text-transform: uppercase;
    }

    td {
      text-align: left;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    tr:hover {
      background-color: #ddd;
    }

    .action {
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .action a {
      color: #fff;
      margin-right: 5px;
      padding: 5px 10px;
      border-radius: 5px;
      text-decoration: none;
    }

    .action a.edit {
      background-color: #5cb85c;
    }

    .action a.delete {
      background-color: #d9534f;
    }

    H1 {
      text-align: center;
      font-size: 20px;
      padding-bottom: 0px;
    }

    h2 {
      text-align: center;
    }

    .ttd {
      margin-top: 20px;
      text-align: right;
      font-size: 15px;

    }


    .tebal {
      font-weight: bold;
      text-align: center;
    }

    .ttd {
      margin-top: 20px;
      font-size: 15px;
      align-items: center;
    }

    .ttd p {
      margin-bottom: 0.5px;
      font-weight: bold;
      align-items: center;
      margin-right: 50px;
    }


    .hidden-button {
      position: absolute;
      top: -9999px;
      left: -9999px;
    }
  </style>

</head>

<body>

  <div class="non-printable">
    <?php include 'navbar.php'; ?>
    <!-- Button trigger modal -->
    <button type="button" class="hidden-button" data-toggle="modal" data-target="#filterModal" accesskey="z">
      Filter
    </button>
  </div>


  <div class="printable">

    <div class="head">
      <h2>BAZNAS KABUPATEN SUMBAWA</h2>
      <h1>LAPORAN PENGUMPULAN INFAQ DAN SHADAQOH</h1>
      <h1>TRANSAKSI HARIAN MELALUI TRANSFER DAN TUNAI</h1>
    </div>

    <?php
    $tahun = isset($_POST['tahun']) ? mysqli_real_escape_string($koneksi, $_POST['tahun']) : date('Y');
    ?>
    <?php
    $bulan = isset($_POST['bulan']) ? mysqli_real_escape_string($koneksi, $_POST['bulan']) : date('M');
    ?>
    <h1>BULAN
      <?php echo $bulan; ?> TAHUN
      <?php echo $tahun; ?>
    </h1>

    <table border="1">
      <tr>
        <th>No.</th>
        <th>Tanggal</th>
        <th>Nomor Transaksi</th>
        <th>Nama Muzaki</th>
        <th>Jumlah</th>
      </tr>
      <?php

      $no = 1;
      $total = 0;
      while ($data = mysqli_fetch_array($result)) {
        ?>
        <tr>
          <td>
            <?php echo $no++; ?>
          </td>
          <td>
            <?php echo date('d/m/Y', strtotime($data['tanggal'])); ?>
          </td>
          <td>
            <?php echo $data['nomor_transaksi']; ?>
          </td>
          <td>
            <?php echo $data['nama_muzaki']; ?>
          </td>
          <td>
            <?php echo number_format($data['jumlah'], 2, ',', '.'); ?>
          </td>
        </tr>
        <?php
        $total += $data['jumlah'];
      }
      ?>
      <tr>
        <td colspan="4" class="tebal">Total:</td>
        <td class="tebal">
          <?php echo number_format($total, 2, ',', '.'); ?>
        </td>
      </tr>
    </table><br>
    
    <?php
$tahun = isset($_POST['tahun']) ? mysqli_real_escape_string($koneksi, $_POST['tahun']) : date('Y');
$bulan = isset($_POST['bulan']) ? mysqli_real_escape_string($koneksi, $_POST['bulan']) : date('m');

// Query untuk filter data berdasarkan bulan, tahun, dan pembayaran
$query = "SELECT nama_muzaki, tanggal, SUM(jumlah) AS total_jumlah
          FROM zakat_infaq
          WHERE pembayaran IN ('zakat', 'infaq dan shadaqoh', 'infaq dan shadaqoh terikat')
          AND sumber_rekening IN ('NO. REK APBD', 'BANK BSI SYARIAH', 'BNTB SYARIAH PROVINSI 019')
          AND MONTH(tanggal) = '$bulan'
          AND YEAR(tanggal) = '$tahun'
          GROUP BY nama_muzaki
          ORDER BY tanggal ASC";

$result = mysqli_query($koneksi, $query);

?>

<div class="printable">
  <h1>PENERIMAAN DARI SUMBER LAINNYA</h1>

  <?php
  $tahun = isset($_POST['tahun']) ? mysqli_real_escape_string($koneksi, $_POST['tahun']) : date('Y');
  $bulan = isset($_POST['bulan']) ? mysqli_real_escape_string($koneksi, $_POST['bulan']) : date('M');
  ?>
  <h1>
    BULAN
    <?php echo $bulan; ?> 
    TAHUN
    <?php echo $tahun; ?>
  </h1>

  <?php
  if (mysqli_num_rows($result) > 0) {
    // Tampilkan data
    ?>
    <table border="1">
      <tr>
        <th>No.</th>
        <th>Tanggal</th>
        <th>Sumber Penerimaan Lainnya</th>
        <th>Jumlah</th>
      </tr>
      <?php
      $no = 1;
      $total = 0;
      while ($data = mysqli_fetch_array($result)) {
        ?>
        <tr>
          <td><?php echo $no++; ?></td>
          <td><?php echo date('d/m/Y', strtotime($data['tanggal'])); ?></td>
          <td><?php echo $data['nama_muzaki']; ?></td>
          <td><?php echo number_format($data['total_jumlah'], 2, ',', '.'); ?></td>
        </tr>
        <?php
        $total += $data['total_jumlah'];
      }
      ?>
      <tr style="font-weight: bold;">
        <td colspan="3" class="tebal">Total:</td>
        <td class="tebal">
          <?php echo number_format($total, 2, ',', '.'); ?>
        </td>
      </tr>
    </table><br>
  <?php
  } else {
    // Tampilkan pesan jika tidak ada data
    ?>
    <table border="1">
      <tr>
        <th>No.</th>
        <th>Tanggal</th>
        <th>Sumber Penerimaan Lainnya</th>
        <th>Jumlah</th>
      </tr>
      <tr>
        <td colspan="4" style="text-align: center;">Tidak ada data transaksi dari sumber lain pada tabel ini</td>
      </tr>
    </table><br>
  <?php
  }
  ?>
</div>
    
<p style="margin-left: 700px; font-weight: bold;">Sumbawa Besar, <?php echo date('d F Y'); ?></p>
<div style="display: flex; margin-left:10px;">
<div style="margin-left: 100px;">
<p style= "text-align: center;">Mengetahui,</p>
<p style= "text-align: center;">Ketua BAZNAS Kab. Sumbawa</p><br><br><br><br>
<p style= "text-align: center; font-weight: bold;">H. M. Ali Tunru, S.Sos</p>
</div>

<div style="margin-left:100px;">
<p style= "text-align: center;">Wakil Ketua I,</p>
<p style= "text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
<p style= "text-align: center; font-weight: bold;">Madroni, SHI</p>
</div>

<div style="margin-left:100px;">
<p style= "text-align: center;">Bidang Pengumpulan,</p>
<p style= "text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
<p style= "text-align: center; font-weight: bold;">Pahriyadi, S.Ap</p>
</div>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="filterModalLabel">Filter Data</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="post">
            <div class="form-group">
              <label for="bulan">Bulan:</label>
              <select name="bulan" class="form-control">
                <option value="">Pilih Bulan</option>
                <option value="01">Januari</option>
                <option value="02">Februari</option>
                <option value="03">Maret</option>
                <option value="04">April</option>
                <option value="05">Mei</option>
                <option value="06">Juni</option>
                <option value="07">Juli</option>
                <option value="08">Agustus</option>
                <option value="09">September</option>
                <option value="10">Oktober</option>
                <option value="11">November</option>
                <option value="12">Desember</option>
              </select>
              <label for="pembayaran">Pembayaran:</label>
              <select id="pembayaran" name="pembayaran" class="form-control" required>
                <option value="Infaq dan Shadaqoh">Infaq dan Shadaqoh</option>
                <option value="Infaq dan Shadaqoh terikat">Infaq dan Shadaqoh Terikat</option>
              </select>
              
              <label for="pembayaran">Tahun:</label>
              <input id="tahun" name="tahun" type="text" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Filter</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- JavaScript Bootstrap -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="timeout.js"></script>

</body>

</html>