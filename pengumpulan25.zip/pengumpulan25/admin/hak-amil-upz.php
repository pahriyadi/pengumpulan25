<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rekap Data Pembayaran Zakat infaq</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">

  <style>
    table {
      border-collapse: collapse;
      width: 90%;
      font-size: 14px;
      margin-left: auto;
      margin-right: auto;
    }

    th,
    td {
      text-align: center;
      padding: 10px;
      text-transform: uppercase;
    }

    th {
      background-color: #fff;
      color: black;
      text-transform: uppercase;
    }

    td {
      text-align: left;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    tr:hover {
      background-color: #ddd;
    }

    .action {
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .action a {
      color: #fff;
      margin-right: 5px;
      padding: 5px 10px;
      border-radius: 5px;
      text-decoration: none;
    }

    .action a.edit {
      background-color: #5cb85c;
    }

    .action a.delete {
      background-color: #d9534f;
    }

    H1 {
      text-align: center;
      font-size: 20px;
      padding-bottom: 0px;
      text-transform: uppercase;
    }

    p {
      text-align: center;
      font-size: 13px;
      padding-bottom: 0px;
    }

    .ttd {
      margin-top: 20px;
      text-align: right;
      font-size: 15px;
    }

    .ttd p {
      margin-bottom: 0.5px;
      font-weight: bold;
    }

    .tebal {
      font-weight: bold;
    }

    .ttd {
      margin-top: 20px;
      font-size: 15px;
      align-items: center;
    }

    .ttd p {
      margin-bottom: 0.5px;
      font-weight: bold;
      align-items: center;
    }


    .hidden-button {
      position: absolute;
      top: -9999px;
      left: -9999px;
    }

    @media print {

      /* CSS untuk bagian yang akan diprint */
      body {
        font-size: 14px;
      }

      .printable {
        display: block;
      }

      .non-printable {
        display: none;
      }

      /* Aturan untuk mode lanskap */
      @page {
        size: landscape;
      }
    }
  </style>
</head>


<body>
  <div class="non-printable">
    <?php include 'navbar.php'; ?>

    <!-- Button trigger modal -->
    <button type="button" class="hidden-button" data-toggle="modal" data-target="#filterModal" accesskey="z">
      Filter
    </button>

    <!-- Button trigger modal -->
    <button type="button" class="hidden-button" data-toggle="modal" data-target="#filterModalzakatinfaq" accesskey="x">
      Filter</button>

    <form method="GET" action="hak-amil-upz.php">
      <div class="form-group" style="width: 80%; margin: 0 auto; display: flex; gap: 5px;">

        <select name="nama_muzaki" class="form-control">
          <option value="">-- Pilih Nama Muzaki --</option>
          <?php
          // Koneksi ke database (ganti dengan informasi koneksi sesuai dengan database Anda)
          include 'koneksi.php';

          // Query untuk mengambil data nama muzaki dari tabel (ganti dengan query sesuai dengan struktur tabel Anda)
          $query = "SELECT nama_muzaki FROM zakat_infaq GROUP BY nomor_induk_muzaki";
          $result = mysqli_query($koneksi, $query);

          // Loop untuk memasukkan data nama muzaki ke dalam elemen option
          while ($row = mysqli_fetch_assoc($result)) {
            $nama_muzaki = $row['nama_muzaki'];
            echo '<option value="' . $nama_muzaki . '">' . $nama_muzaki . '</option>';
          }

          // Tutup koneksi ke database
          mysqli_close($koneksi);
          ?>
        </select>

        <select name="status_muzaki" class="form-control">
          <option value="">-- Pilih status muzaki --</option>
          <option value="Perorangan">Perorangan</option>
          <option value="Dinas Instansi">Dinas Instansi</option>
          <option value="BANK">BANK</option>
          <option value="BUMN">BUMN</option>
          <option value="BUMD">BUMD</option>
          <option value="Sekolah">Sekolah</option>
          <option value="A/N">A/N</option>
        </select>

        <select name="pembayaran" class="form-control">
          <option value="">-- Pilih Pembayaran --</option>
          <option value="zakat">zakat</option>
          <option value="infaq dan shadaqoh">infaq dan shadaqoh</option>
          <option value="infaq dan shadaqoh terikat">infaq dan shadaqoh terikat</option>
        </select>

        <select name="metode_bayar" id="metode_bayar" class="form-control">
          <option value="">-- Pilih metode bayar --</option>
          <option value="transfer bank">Tranfer Bank</option>
          <option value="tunai">Tunai</option>
        </select>

        <input type="number" name="tahun" id="tahun" class="form-control" min="2000" value="<?php echo date('Y'); ?>">

        <button type="submit" class="btn btn-primary">Cari</button>

      </div>
    </form>
    <hr>

    <form action="" method="post">
      <div class="form-group" style="width: 80%; margin: 0 auto; display: flex; gap: 5px;">
        <input type="date" id="tanggal_mulai" name="tanggal_mulai" class="form-control" required
          placeholder="Tanggal Mulai">
        <input type="date" id="tanggal_akhir" name="tanggal_akhir" class="form-control" required
          placeholder="Tanggal Akhir">
        <button type="submit" class="btn btn-primary">Cari</button>
      </div>
    </form><br>


    <?php
    include 'koneksi.php'; // Sesuaikan dengan file koneksi database
    
    // Dapatkan tanggal awal dan akhir dari formulir atau sumber lainnya
    $tanggal_mulai = isset($_POST['tanggal_mulai']) ? $_POST['tanggal_mulai'] : '';
    $tanggal_akhir = isset($_POST['tanggal_akhir']) ? $_POST['tanggal_akhir'] : '';


    // Menghitung jumlah total transaksi zakat tunai untuk PERORANGAN
    $sql_total_zorang = "SELECT SUM(jumlah) AS total_zorang FROM zakat_infaq WHERE pembayaran = 'zakat' AND status_muzaki IN ('perorangan', 'A/N') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_zorang = $koneksi->query($sql_total_zorang);
    $total_zorang = $result_total_zorang->fetch_assoc()['total_zorang'];

    // Menghitung jumlah total transaksi zakat tunai untuk DINAS/INSTANSI
    $sql_total_dinas = "SELECT SUM(jumlah) AS total_dinas FROM zakat_infaq WHERE pembayaran = 'zakat' AND status_muzaki IN ('dinas instansi', 'sekolah') AND sumber_rekening IN ('BNTB SYARIAH ZAKAT') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_dinas = $koneksi->query($sql_total_dinas);
    $total_dinas = $result_total_dinas->fetch_assoc()['total_dinas'];

    // Menghitung jumlah total transaksi zakat tunai untuk DINAS/INSTANSI
    $sql_total_badan = "SELECT SUM(jumlah) AS total_badan FROM zakat_infaq WHERE pembayaran = 'zakat' AND status_muzaki IN ('BUMN', 'BUMD') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_badan = $koneksi->query($sql_total_badan);
    $total_badan = $result_total_badan->fetch_assoc()['total_badan'];

    // Menghitung jumlah total transaksi INFAQ tunai untuk DINAS/INSTANSI
    $sql_total_fitrah = "SELECT SUM(nilai_uang) AS total_fitrah FROM zakat_fitrah WHERE niat_pembayaran IN ('zakat fitrah') AND jenis_pembayaran IN ('uang', 'beras') AND tanggal_pembayaran BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_fitrah = $koneksi->query($sql_total_fitrah);
    $total_fitrah = $result_total_fitrah->fetch_assoc()['total_fitrah'];

    // Menghitung jumlah total transaksi INFAQ tunai untuk PERORANGAN
    $sql_total_zorang1 = "SELECT SUM(jumlah) AS total_zorang1 FROM zakat_infaq WHERE pembayaran = 'infaq dan shadaqoh' AND status_muzaki IN ('perorangan', 'A/N') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_zorang1 = $koneksi->query($sql_total_zorang1);
    $total_zorang1 = $result_total_zorang1->fetch_assoc()['total_zorang1'];

    // Menghitung jumlah total transaksi INFAQ tunai untuk DINAS/INSTANSI
    $sql_total_dinas1 = "SELECT SUM(jumlah) AS total_dinas1 FROM zakat_infaq WHERE pembayaran = 'infaq dan shadaqoh' AND status_muzaki IN ('dinas instansi', 'sekolah', 'bank', 'BUMN', 'BUMD') AND sumber_rekening IN ('BNTB SYARIAH INFAQ') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_dinas1 = $koneksi->query($sql_total_dinas1);
    $total_dinas1 = $result_total_dinas1->fetch_assoc()['total_dinas1'];
    
        // Menghitung jumlah total transaksi INFAQ terikat
    $sql_total_terikat = "SELECT SUM(jumlah) AS total_terikat FROM zakat_infaq WHERE pembayaran = 'infaq dan shadaqoh terikat' AND status_muzaki IN ('dinas instansi', 'sekolah', 'bank', 'BUMN', 'BUMD','perorangan', 'A/N') AND sumber_rekening IN ('BNTB SYARIAH INFAQ') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_terikat = $koneksi->query($sql_total_terikat);
    $total_terikat = $result_total_terikat->fetch_assoc()['total_terikat'];

    // Menghitung jumlah total transaksi INFAQ tunai untuk DINAS/INSTANSI
    $sql_total_fitrah1 = "SELECT SUM(nilai_uang) AS total_fitrah1 FROM zakat_fitrah WHERE niat_pembayaran IN ('fidyah','dskl') AND jenis_pembayaran IN ('uang', 'beras') AND tanggal_pembayaran BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_fitrah1 = $koneksi->query($sql_total_fitrah1);
    $total_fitrah1 = $result_total_fitrah1->fetch_assoc()['total_fitrah1'];

    // Menghitung jumlah total transaksi zakat tunai untuk DINAS/INSTANSI
    $sql_total_apbd = "SELECT SUM(jumlah) AS total_apbd FROM zakat_infaq WHERE pembayaran = 'zakat' AND sumber_rekening IN ('NO. REK APBD') AND nama_muzaki IN ('penerimaan APBD') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_apbd = $koneksi->query($sql_total_apbd);
    $total_apbd = $result_total_apbd->fetch_assoc()['total_apbd'];

    // Menghitung jumlah total transaksi zakat tunai untuk DINAS/INSTANSI
    $sql_total_apbn = "SELECT SUM(jumlah) AS total_apbn FROM zakat_infaq WHERE pembayaran = 'zakat' AND sumber_rekening IN ('BANK BSI SYARIAH') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_apbn = $koneksi->query($sql_total_apbn);
    $total_apbn = $result_total_apbn->fetch_assoc()['total_apbn'];

    // Menghitung jumlah bagi hasil
    $sql_total_bagi_hasil = "SELECT SUM(jumlah) AS total_bagi_hasil FROM zakat_infaq WHERE pembayaran = 'zakat' AND sumber_rekening IN ('BNTB SYARIAH PROVINSI 019') AND nama_muzaki IN ('dana bagi hasil tahap 1', 'dana bagi hasil tahap 2') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_bagi_hasil = $koneksi->query($sql_total_bagi_hasil);
    $total_bagi_hasil = $result_total_bagi_hasil->fetch_assoc()['total_bagi_hasil'];

    // Menghitung jumlah total dana mahyani
    $sql_total_mahyani = "SELECT SUM(jumlah) AS total_mahyani FROM zakat_infaq WHERE pembayaran = 'zakat' AND sumber_rekening IN ('BNTB SYARIAH PROVINSI 019') AND nama_muzaki IN ('dana mahyani') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
    $result_total_mahyani = $koneksi->query($sql_total_mahyani);
    $total_mahyani = $result_total_mahyani->fetch_assoc()['total_mahyani'];

    if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();

      // Tampilkan data dalam tabel
      echo "<table border='1'>";
      echo "<tr>";
      echo "<th>zakat Perorangan <br>" . number_format($total_zorang, 2, ',', '.') . "</th>";
      echo "<th>zakat Perorangan Via UPZ <br>" . number_format($total_dinas, 2, ',', '.') . "</th>";
      echo "<th>zakat Badan <br>" . number_format($total_badan, 2, ',', '.') . "</th>";
      echo "<th>zakat Fitrah <br>" . number_format($total_fitrah, 2, ',', '.') . "</th>";
      echo "<th>Infaq/Sedekah Terikat <br>" . number_format($total_terikat, 2, ',', '.') . "</th>";
      echo "<th>Infaq/Sedekah Tidak Terikat <br>" . number_format($total_zorang1, 2, ',', '.') . "</th>";
      echo "<th>Infaq/Sedekah Tidak Terikat Via UPZ<br>" . number_format($total_dinas1, 2, ',', '.') . "</th>";
      echo "<th>Penerimaan CSR <br>" . number_format($total_badan, 2, ',', '.') . "</th>";
      echo "<th>Penerimaan DSKL <br>" . number_format($total_fitrah1, 2, ',', '.') . "</th>";
      echo "<th>Penerimaan DSKL Via UPZ <br>" . number_format($total_badan, 2, ',', '.') . "</th>";
      echo "<th>Penerimaan Dana Hibah APBD<br>" . number_format($total_apbd, 2, ',', '.') . "</th>";
      echo "<th>Penerimaan Dana Hibah APBN<br>" . number_format($total_apbn, 2, ',', '.') . "</th>";
      echo "<th>Penerimaan Dana Bagi Hasil<br>" . number_format($total_bagi_hasil, 2, ',', '.') . "</th>";
      echo "<th>Penerimaan Dana mahyani<br>" . number_format($total_mahyani, 2, ',', '.') . "</th>";
      echo "</tr>";

      echo "</table>";
    } else {
      echo "Tidak ada data.";

    }

    $koneksi->close(); // Tutup koneksi database
    ?>
  </div><br>


  <div class="printtable">
    <h1>BAZNAS KABUPATEN SUMBAWA</h1>
    <?php
    $tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');
    $nama_muzaki = isset($_GET['nama_muzaki']) ? $_GET['nama_muzaki'] : '';
    $status_muzaki = isset($_GET['status_muzaki']) ? $_GET['status_muzaki'] : '';
    $pembayaran = isset($_GET['pembayaran']) ? $_GET['pembayaran'] : '';
    $metode_bayar = isset($_GET['metode_bayar']) ? $_GET['metode_bayar'] : '';

    if (empty($pembayaran)) {
      echo '<h1>REKAP TRANSAKSI PENGUMPULAN BULANAN ZAKAT, INFAQ DAN SHADAQOH</h1>';
    } else {
      echo '<h1>REKAP TRANSAKSI PENGUMPULAN BULANAN ' . $pembayaran . ' TAHUN ' . $tahun . '</h1>';
    }
    ?>


    <p>Hasil filter berdasarkan :
      <?php echo $pembayaran; ?> --
      <?php echo $status_muzaki; ?> --
      <?php echo $metode_bayar; ?> --
      <?php echo $nama_muzaki; ?>
      <?php echo $tahun; ?>
    </p>

    <table border="1">
      <tr>
        <th>No</th>
        <th>Nama Muzaki</th>
        <th>Januari</th>
        <th>Februari</th>
        <th>Maret</th>
        <th>April</th>
        <th>Mei</th>
        <th>Juni</th>
        <th>Juli</th>
        <th>Agustus</th>
        <th>September</th>
        <th>Oktober</th>
        <th>November</th>
        <th>Desember</th>
        <th>Jumlah</th>
        <th>Hak AmiL</th>
      </tr>

      <?php
      include 'koneksi.php';


      // Deklarasi variabel untuk menyimpan nilai tahun
      $tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');
      $nama_muzaki = isset($_GET['nama_muzaki']) ? $_GET['nama_muzaki'] : '';
      $status_muzaki = isset($_GET['status_muzaki']) ? $_GET['status_muzaki'] : '';
      $pembayaran = isset($_GET['pembayaran']) ? $_GET['pembayaran'] : '';
      $metode_bayar = isset($_GET['metode_bayar']) ? $_GET['metode_bayar'] : '';

      $query_muzaki = "SELECT DISTINCT nomor_induk_muzaki FROM zakat_infaq WHERE YEAR(tanggal) = $tahun AND (pembayaran = 'zakat' OR pembayaran = 'infaq dan shadaqoh' OR pembayaran = 'infaq dan shadaqoh terikat') AND sumber_rekening in ('BNTB SYARIAH ZAKAT', 'BNTB SYARIAH INFAQ')";

      // Tambahkan kondisi pencarian berdasarkan status_muzaki jika dipilih
      if (!empty($status_muzaki)) {
        $query_muzaki .= " AND status_muzaki = '$status_muzaki'";
      }

      if (!empty($pembayaran)) {
        $query_muzaki .= " AND pembayaran = '$pembayaran'";
      }

      if (!empty($nama_muzaki)) {
        $query_muzaki .= " AND nama_muzaki = '$nama_muzaki'";
      }

      if (!empty($metode_bayar)) {
        $query_muzaki .= " AND metode_bayar = '$metode_bayar'";
      }



      $query_muzaki .= " ORDER BY nomor_induk_muzaki";

      $result_muzaki = mysqli_query($koneksi, $query_muzaki);

      // Inisialisasi total bulanan dan total jumlah
      $total_bulanan = array();
      for ($i = 1; $i <= 12; $i++) {
        $total_bulanan[$i] = 0;
      }
      $total_jumlah = 0;
      $total_semua = 0;
      $total_hak_amil = 0;

      // Loop untuk menampilkan data muzaki
      $no = 1;
      while ($muzaki = mysqli_fetch_array($result_muzaki)) {
        // Query untuk mengambil nama muzaki
        $query_nama = "SELECT nama_muzaki FROM zakat_infaq WHERE nomor_induk_muzaki = '" . $muzaki['nomor_induk_muzaki'] . "' AND (pembayaran = 'zakat' OR pembayaran = 'infaq dan shadaqoh' OR pembayaran = 'infaq dan shadaqoh terikat') AND sumber_rekening in ('BNTB SYARIAH ZAKAT', 'BNTB SYARIAH INFAQ')";

        // Tambahkan kondisi pencarian berdasarkan status_muzaki jika dipilih
        if (!empty($status_muzaki)) {
          $query_nama .= " AND status_muzaki = '$status_muzaki'";
        }

        if (!empty($pembayaran)) {
          $query_nama .= " AND pembayaran = '$pembayaran'";
        }

        if (!empty($metode_bayar)) {
          $query_nama .= " AND metode_bayar = '$metode_bayar'";
        }

        if (!empty($tahun)) {
          $query_nama .= " AND YEAR(tanggal) = $tahun";
      }


        $query_nama .= " LIMIT 1";
        $result_nama = mysqli_query($koneksi, $query_nama);
        $nama_muzaki = mysqli_fetch_array($result_nama)['nama_muzaki'];

        echo "<tr>";
        echo "<td style='text-align: center;'>" . $no++ . "</td>";
        echo "<td>" . $nama_muzaki . "</td>";

        // Loop untuk menampilkan data pembayaran per bulan
        $total_jumlah = 0; // inisialisasi total_jumlah untuk setiap baris
        for ($bulan = 1; $bulan <= 12; $bulan++) {
          $query = "SELECT SUM(jumlah) as total FROM zakat_infaq WHERE nomor_induk_muzaki = '" . $muzaki['nomor_induk_muzaki'] . "' AND MONTH(tanggal) = $bulan AND (pembayaran = 'zakat' OR pembayaran = 'infaq dan shadaqoh' OR pembayaran = 'infaq dan shadaqoh terikat') AND sumber_rekening in ('BNTB SYARIAH ZAKAT', 'BNTB SYARIAH INFAQ') ";

          // Tambahkan kondisi pencarian berdasarkan status_muzaki jika dipilih
          if (!empty($status_muzaki)) {
            $query .= " AND status_muzaki = '$status_muzaki'";
          }

          if (!empty($pembayaran)) {
            $query .= " AND pembayaran = '$pembayaran'";
          }

          if (!empty($nama_muzaki)) {
            $query .= " AND nama_muzaki = '$nama_muzaki'";
          }

          if (!empty($metode_bayar)) {
            $query .= " AND metode_bayar = '$metode_bayar'";
          }

          if (!empty($tahun)) {
            $query .= " AND YEAR(tanggal) = $tahun";
        }

          $result = mysqli_query($koneksi, $query);
          $data = mysqli_fetch_array($result);
          $jumlah = $data['total'];

          $total_bulanan[$bulan] += $jumlah;
          $total_jumlah += $jumlah;

          echo "<td>" . number_format($jumlah, 2, ',', '.') . "</td>";
        }
        
        echo "<td style='font-weight: bold;'>" . number_format($total_jumlah, 2, ',', '.') . "</td>";
        
        // Menghitung dan menampilkan total hak amil
          $hak_amil = $total_jumlah * 0.03; // Menggunakan persentase 3%
          $total_hak_amil += $hak_amil; // Menambahkan total hak amil ke variabel $total_hak_amil
  echo "<td style='font-weight: bold; color:red;'>" . number_format($hak_amil, 2, ',', '.') . "</td>"; // Menampilkan total hak amil
        
        $total_semua += $total_jumlah; // Menambahkan total_jumlah ke variabel $total_semua
        

      
        echo "</tr>";
      }
      
      

      // Menampilkan total bulanan pada baris terakhir
      echo "<tr>";
      echo "<td colspan='2' style='text-align: center; font-weight: bold;'><b>Total</b></td>";
      for ($bulan = 1; $bulan <= 12; $bulan++) {
        echo "<td style='font-weight: bold;'>" . number_format($total_bulanan[$bulan], 2, ',', '.') . "</td>";
      }

      echo "<td style='font-weight: bold;'>" . number_format($total_semua, 2, ',', '.') . "</td>"; // Menampilkan total dari semua jumlah
        echo "<td style='font-weight: bold; color: red;'>" . number_format($total_hak_amil, 2, ',', '.') . "</td>"; // Menampilkan total dari semua jumlah
      echo "</tr>";
      ?>


    </table>
    <hr>
    
    <!---- pemisahan tabel transaksi lainnya ---->
    
    
    <div class="printtable">
    <?php
    $tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');
    $nama_muzaki = isset($_GET['nama_muzaki']) ? $_GET['nama_muzaki'] : '';
    $status_muzaki = isset($_GET['status_muzaki']) ? $_GET['status_muzaki'] : '';
    $pembayaran = isset($_GET['pembayaran']) ? $_GET['pembayaran'] : '';
    $metode_bayar = isset($_GET['metode_bayar']) ? $_GET['metode_bayar'] : '';

    if (empty($pembayaran)) {
      echo '<h1>REKAP TRANSAKSI PENGUMPULAN LAINNYA DARI DANA ZAKAT, INFAQ DAN SHADAQOH</h1>';
    } else {
      echo '<h1>REKAP TRANSAKSI PENGUMPULAN BULANAN ' . $pembayaran . ' TAHUN ' . $tahun . '</h1>';
    }
    ?>


    <p>Hasil filter berdasarkan :
      <?php echo $pembayaran; ?> --
      <?php echo $status_muzaki; ?> --
      <?php echo $metode_bayar; ?> --
      <?php echo $nama_muzaki; ?>
      <?php echo $tahun; ?>
    </p>

    <table border="1">
      <tr>
        <th>No</th>
        <th>Nama Muzaki</th>
        <th>Januari</th>
        <th>Februari</th>
        <th>Maret</th>
        <th>April</th>
        <th>Mei</th>
        <th>Juni</th>
        <th>Juli</th>
        <th>Agustus</th>
        <th>September</th>
        <th>Oktober</th>
        <th>November</th>
        <th>Desember</th>
        <th>Jumlah</th>
      </tr>

      <?php
      include 'koneksi.php';


      // Deklarasi variabel untuk menyimpan nilai tahun
      $tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');
      $nama_muzaki = isset($_GET['nama_muzaki']) ? $_GET['nama_muzaki'] : '';
      $status_muzaki = isset($_GET['status_muzaki']) ? $_GET['status_muzaki'] : '';
      $pembayaran = isset($_GET['pembayaran']) ? $_GET['pembayaran'] : '';
      $metode_bayar = isset($_GET['metode_bayar']) ? $_GET['metode_bayar'] : '';

      $query_muzaki = "SELECT DISTINCT nomor_induk_muzaki FROM zakat_infaq WHERE YEAR(tanggal) = $tahun AND (pembayaran = 'zakat' OR pembayaran = 'infaq dan shadaqoh' OR pembayaran = 'infaq dan shadaqoh terikat') AND sumber_rekening in ('NO. REK APBD', 'BNTB SYARIAH PROVINSI 019', 'BANK BSI SYARIAH')";

      // Tambahkan kondisi pencarian berdasarkan status_muzaki jika dipilih
      if (!empty($status_muzaki)) {
        $query_muzaki .= " AND status_muzaki = '$status_muzaki'";
      }

      if (!empty($pembayaran)) {
        $query_muzaki .= " AND pembayaran = '$pembayaran'";
      }

      if (!empty($nama_muzaki)) {
        $query_muzaki .= " AND nama_muzaki = '$nama_muzaki'";
      }

      if (!empty($metode_bayar)) {
        $query_muzaki .= " AND metode_bayar = '$metode_bayar'";
      }



      $query_muzaki .= " ORDER BY nomor_induk_muzaki";

      $result_muzaki = mysqli_query($koneksi, $query_muzaki);

      // Inisialisasi total bulanan dan total jumlah
      $total_bulanan = array();
      for ($i = 1; $i <= 12; $i++) {
        $total_bulanan[$i] = 0;
      }
      $total_jumlah = 0;
      $total_semua = 0;

      // Loop untuk menampilkan data muzaki
      $no = 1;
      while ($muzaki = mysqli_fetch_array($result_muzaki)) {
        // Query untuk mengambil nama muzaki
        $query_nama = "SELECT nama_muzaki FROM zakat_infaq WHERE nomor_induk_muzaki = '" . $muzaki['nomor_induk_muzaki'] . "' AND (pembayaran = 'zakat' OR pembayaran = 'infaq dan shadaqoh' OR pembayaran = 'infaq dan shadaqoh terikat') AND sumber_rekening in ('NO. REK APBD', 'BNTB SYARIAH PROVINSI 019', 'BANK BSI SYARIAH')";

        // Tambahkan kondisi pencarian berdasarkan status_muzaki jika dipilih
        if (!empty($status_muzaki)) {
          $query_nama .= " AND status_muzaki = '$status_muzaki'";
        }

        if (!empty($pembayaran)) {
          $query_nama .= " AND pembayaran = '$pembayaran'";
        }

        if (!empty($metode_bayar)) {
          $query_nama .= " AND metode_bayar = '$metode_bayar'";
        }

        if (!empty($tahun)) {
          $query_nama .= " AND YEAR(tanggal) = $tahun";
      }


        $query_nama .= " LIMIT 1";
        $result_nama = mysqli_query($koneksi, $query_nama);
        $nama_muzaki = mysqli_fetch_array($result_nama)['nama_muzaki'];

        echo "<tr>";
        echo "<td style='text-align: center;'>" . $no++ . "</td>";
        echo "<td>" . $nama_muzaki . "</td>";

        // Loop untuk menampilkan data pembayaran per bulan
        $total_jumlah = 0; // inisialisasi total_jumlah untuk setiap baris
        for ($bulan = 1; $bulan <= 12; $bulan++) {
          $query = "SELECT SUM(jumlah) as total FROM zakat_infaq WHERE nomor_induk_muzaki = '" . $muzaki['nomor_induk_muzaki'] . "' AND MONTH(tanggal) = $bulan AND (pembayaran = 'zakat' OR pembayaran = 'infaq dan shadaqoh' OR pembayaran = 'infaq dan shadaqoh terikat') AND sumber_rekening in ('NO. REK APBD', 'BNTB SYARIAH PROVINSI 019', 'BANK BSI SYARIAH') ";

          // Tambahkan kondisi pencarian berdasarkan status_muzaki jika dipilih
          if (!empty($status_muzaki)) {
            $query .= " AND status_muzaki = '$status_muzaki'";
          }

          if (!empty($pembayaran)) {
            $query .= " AND pembayaran = '$pembayaran'";
          }

          if (!empty($nama_muzaki)) {
            $query .= " AND nama_muzaki = '$nama_muzaki'";
          }

          if (!empty($metode_bayar)) {
            $query .= " AND metode_bayar = '$metode_bayar'";
          }

          if (!empty($tahun)) {
            $query .= " AND YEAR(tanggal) = $tahun";
        }

          $result = mysqli_query($koneksi, $query);
          $data = mysqli_fetch_array($result);
          $jumlah = $data['total'];

          $total_bulanan[$bulan] += $jumlah;
          $total_jumlah += $jumlah;

          echo "<td>" . number_format($jumlah, 2, ',', '.') . "</td>";
        }

        echo "<td style='font-weight: bold;'>" . number_format($total_jumlah, 2, ',', '.') . "</td>";
        $total_semua += $total_jumlah; // Menambahkan total_jumlah ke variabel $total_semua
      
        echo "</tr>";
      }

      // Menampilkan total bulanan pada baris terakhir
      echo "<tr>";
      echo "<td colspan='2' style='text-align: center; font-weight: bold;'><b>Total</b></td>";
      for ($bulan = 1; $bulan <= 12; $bulan++) {
        echo "<td style='font-weight: bold;'>" . number_format($total_bulanan[$bulan], 2, ',', '.') . "</td>";
      }

      echo "<td style='font-weight: bold;'>" . number_format($total_semua, 2, ',', '.') . "</td>"; // Menampilkan total dari semua jumlah
      echo "</tr>";
      ?>


    </table>
    <hr>



    <div class="container">
      <div class="row">

      </div>
    </div>

    <p style=" font-weight: bold;">Sumbawa Besar,
      <?php echo date('d F Y'); ?>
    </p>
    <div style="display: flex; margin-left:10px;">
      <div style="margin-left: 500px;">
        <p style="text-align: center;">Mengetahui,</p>
        <p style="text-align: center;">Ketua BAZNAS Kab. Sumbawa</p><br><br><br><br>
        <p style="text-align: center; font-weight: bold;">H. M. Ali Tunru, S.Sos</p>
      </div>

      <div style="margin-left:100px;">
        <p style="text-align: center;"></p>
        <p style="text-align: center;"></p><br><br><br><br>
        <p style="text-align: center; font-weight: bold;"></p>
      </div>

      <div style="margin-left:500px;">
        <p style="text-align: center;">Bidang Pengumpulan,</p>
        <p style="text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
        <p style="text-align: center; font-weight: bold;">Pahriyadi, S.Ap</p>
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="filterModalLabel">Filter Berdasarkan Tahun</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form method="GET" action="laporan-zakat-bulanan.php">
              <div class="form-group">
                <label for="tahun">Tahun:</label>
                <input type="number" name="tahun" id="tahun" class="form-control" min="2000"
                  value="<?php echo date('Y'); ?>">
              </div>
              <button type="submit" class="btn btn-primary">Filter</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="filterModalzakatinfaq" tabindex="-1" aria-labelledby="filterModalLabel"
      aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="filterModalLabel1">Filter Berdasarkan Status Muzaki</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form method="GET" action="laporan-zakatinfaq-bulanan-tf-tunai.php">
              <div class="form-group">
                <label for="status_muzaki">Status Muzaki:</label>
                <select name="status_muzaki" class="form-control">
                  <option value="Perorangan">Perorangan</option>
                  <option value="Dinas Instansi">Dinas Instansi</option>
                  <option value="BANK">BANK</option>
                  <option value="BUMN">BUMN</option>
                  <option value="BUMD">BUMD</option>
                  <option value="Sekolah">Sekolah</option>
                  <option value="A/N">A/N</option>
                </select>
                <label for="pembayaran">Pembayaran:</label>
                <select name="pembayaran" class="form-control">
                  <option value="zakat">zakat</option>
                  <option value="infaq dan shadaqoh">infaq dan shadaqoh</option>
                </select>
              </div>
              <button type="submit" class="btn btn-primary">Filter</button>
            </form>
          </div>
        </div>
      </div>
    </div>


    <!-- JavaScript Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="timeout.js"></script>

</body>

</html>