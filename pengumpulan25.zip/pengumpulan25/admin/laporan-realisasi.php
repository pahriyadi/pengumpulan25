<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rekap Data Pembayaran Zakat</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="icon" href="\public_html\imgs\lobaz.png" type="image/x-icon">

  <style>
    table {
      border-collapse: collapse;
      width: 90%;
      font-size: 14px;
      margin-left: auto;
      margin-right: auto;
    }

    th,
    td {
      text-align: center;
      padding: 10px;
      text-transform: uppercase;
    }

    th {
      background-color: #fff;
      color: black;
      text-transform: uppercase;
    }

    td {
      text-align: left;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    tr:hover {
      background-color: #ddd;
    }

    .action {
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .action a {
      color: #fff;
      margin-right: 5px;
      padding: 5px 10px;
      border-radius: 5px;
      text-decoration: none;
    }

    .action a.edit {
      background-color: #5cb85c;
    }

    .action a.delete {
      background-color: #d9534f;
    }

    H1 {
      text-align: center;
      font-size: 20px;
      padding-bottom: 0px;
    }

    .ttd {
      margin-top: 20px;
      text-align: right;
      font-size: 15px;
    }

    .ttd p {
      margin-bottom: 0.5px;
      font-weight: bold;
    }

    .tebal {
      font-weight: bold;
    }

    .ttd {
      margin-top: 20px;
      font-size: 15px;
      align-items: center;
    }

    .ttd p {
      margin-bottom: 0.5px;
      font-weight: bold;
      align-items: center;
    }


    .hidden-button {
      position: absolute;
      top: -9999px;
      left: -9999px;
    }

    @media print {

      /* CSS untuk bagian yang akan diprint */
      body {
        font-size: 14px;
      }

      .printable {
        display: block;
      }

      .non-printable {
        display: none;
      }

      /* Aturan untuk mode lanskap */
      @page {
        size: landscape;
      }
    }
  </style>
</head>


<body>
    

  <!-- Form pencarian -->
  <form action="" method="GET">
    <label for="tanggal_awal">Tanggal Awal:</label>
    <input type="date" id="tanggal_awal" name="tanggal_awal">
    <label for="tanggal_akhir">Tanggal Akhir:</label>
    <input type="date" id="tanggal_akhir" name="tanggal_akhir">
    <input type="submit" value="Cari">
  </form>
    
<?php
include 'koneksi.php';
include 'navbar.php';

// Mendapatkan nama bulan dan tahun yang ingin difilter (misalnya "Maret" dan "2023")
$nama_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : '';
$nama_tahun = isset($_GET['tahun']) ? $_GET['tahun'] : '';

$bulan_condition = '';
$tahun_condition = '';
$bulan_condition_pembayaran = '';
$tahun_condition_pembayaran = '';

// Menghitung jumlah total realisasi zakat maal perorangan
$sql_total_zakat = "SELECT SUM(jumlah) AS total_zakat FROM zakat_infaq WHERE pembayaran IN ('zakat') AND status_muzaki IN ('perorangan', 'A/N')";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat = $result_total_zakat->fetch_assoc()['total_zakat'];

// Menghitung jumlah total realisasi zakat maal badan
$sql_total_zakat = "SELECT SUM(jumlah) AS total_zakat1 FROM zakat_infaq WHERE pembayaran IN ('zakat') AND status_muzaki IN ('BUMN', 'BUMD') ";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat1 = $result_total_zakat->fetch_assoc()['total_zakat1'];

// Menghitung jumlah total realisasi zakat maal Perorangan via upz
$sql_total_zakat = "SELECT SUM(jumlah) AS total_zakat2 FROM zakat_infaq WHERE pembayaran IN ('zakat') AND status_muzaki IN ('dinas instansi', 'sekolah', 'BANK') AND sumber_rekening IN ('BNTB SYARIAH ZAKAT')";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat2 = $result_total_zakat->fetch_assoc()['total_zakat2'];

// Menghitung jumlah total realisasi zakat fitrah Perorangan
$sql_total_zakat = "SELECT SUM(nilai_uang) AS total_zakat001 FROM zakat_fitrah WHERE niat_pembayaran IN ('zakat fitrah') AND jenis_pembayaran IN ('uang', 'beras')";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat001 = $result_total_zakat->fetch_assoc()['total_zakat001'];

// Menghitung jumlah total realisasi infaq ramadhan
$sql_total_zakat = "SELECT SUM(nilai_uang) AS total_zakat002 FROM zakat_fitrah WHERE niat_pembayaran IN ('infaq dan shadaqoh') AND jenis_pembayaran IN ('uang') ";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat002 = $result_total_zakat->fetch_assoc()['total_zakat002'];

// Menghitung jumlah total realisasi fidyah ramadhan
$sql_total_zakat = "SELECT SUM(nilai_uang) AS total_zakat003 FROM zakat_fitrah WHERE niat_pembayaran IN ('fidyah') AND jenis_pembayaran IN ('uang')";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat003 = $result_total_zakat->fetch_assoc()['total_zakat003'];

// Menghitung jumlah total realisasi infaq  perorangan
$sql_total_zakat = "SELECT SUM(jumlah) AS total_zakat01 FROM zakat_infaq WHERE pembayaran IN ('infaq dan shadaqoh') AND status_muzaki IN ('perorangan', 'A/N')";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat01 = $result_total_zakat->fetch_assoc()['total_zakat01'];

// Menghitung jumlah total realisasi infaq  perorangan
$sql_total_zakat = "SELECT SUM(jumlah) AS total_zakat02 FROM zakat_infaq WHERE pembayaran IN ('infaq dan shadaqoh') AND status_muzaki IN ('dinas instansi', 'sekolah', 'BANK')";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat02 = $result_total_zakat->fetch_assoc()['total_zakat02'];

// Menghitung jumlah total realisasi infaq  terikat
$sql_total_zakat = "SELECT SUM(jumlah) AS total_zakat03 FROM zakat_infaq WHERE pembayaran IN ('infaq dan shadaqoh terikat') AND status_muzaki IN ('dinas instansi', 'sekolah', 'BANK','perorangan','A/N')";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat03 = $result_total_zakat->fetch_assoc()['total_zakat03'];

// Menghitung jumlah total realisasi dana hibah APBD
$sql_total_zakat = "SELECT SUM(jumlah) AS total_zakat0001 FROM zakat_infaq WHERE pembayaran IN ('zakat') AND status_muzaki IN ('dinas instansi') AND sumber_rekening IN ('NO. REK APBD')";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat0001 = $result_total_zakat->fetch_assoc()['total_zakat0001'];

// Menghitung jumlah total realisasi dana hibah APBD
$sql_total_zakat = "SELECT SUM(jumlah) AS total_zakat0002 FROM zakat_infaq WHERE pembayaran IN ('zakat') AND status_muzaki IN ('dinas instansi') AND sumber_rekening IN ('BANK BSI SYARIAH')";
$result_total_zakat = $koneksi->query($sql_total_zakat);
$total_zakat0002 = $result_total_zakat->fetch_assoc()['total_zakat0002'];


//JUMLAH DANA HIBAH
$total_hibah = "0";
$total_hibah = $total_zakat0001 + $total_zakat0002;

//JUMLAH DANA zakat
$total_zakat = "0";
$total_zakat = $total_zakat + $total_zakat1 + $total_zakat2 + $totol_zakat001;

//jumlah dana infaq
$total_infaq = "0";
$total_infaq = $total_zakat002 + $total_zakat003 + $total_zakat01 +$total_zakat02 + $total_zakat03;


echo '<table border="1">
        <tr>
            <th>NO</th>
            <th>KETERANGAN</th>
            <th>RENCANA</th>
            <th>REALISASI</th>
            <th>CAPAIAN</th>
        </tr>
        <tr>
            <td style="background-color:yellow;">1</td>
            <td style="background-color:yellow;">PENERIMAAN DANA ZAKAT</td>
            <td style="background-color:yellow;"></td>
            <td style="background-color:yellow;font-weight:bold;">'. number_format($total_zakat, 2, ',', '.') .'</td>
            <td style="background-color:yellow;"></td>
        </tr>
        <tr>
            <td>2</td>
            <td>PENERIMAAN DANA ZAKAT MAAL PERORANGAN</td>
            <td></td>
            <td>'. number_format($total_zakat, 2, ',', '.') .'</td>
            <td></td>
        </tr>
        <tr>
            <td>3</td>
            <td>PENERIMAAN DANA ZAKAT MAAL BADAN</td>
            <td></td>
            <td>'. number_format($total_zakat1, 2, ',', '.') .'</td>
            <td></td>
        </tr>
        <tr>
            <td>4</td>
            <td>PENERIMAAN DANA ZAKAT MAAL PERORANGAN VIA UPZ</td>
            <td></td>
            <td>'. number_format($total_zakat2, 2, ',', '.') .'</td>
            <td></td>
        </tr>
        <tr>
            <td>5</td>
            <td>PENERIMAAN DANA ZAKAT FITRAH (ONBS)</td>
            <td></td>
            <td>'. number_format($total_zakat001, 2, ',', '.') .'</td>
            <td></td>
        </tr>
        <tr>
            <td>6</td>
            <td>PENERIMAAN DANA ZAKAT FITRAH VIA UPZ (ONBS)</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td style="background-color:yellow;">7</td>
            <td style="background-color:yellow;">PENERIMAAN DANA INFAQ/SEDEKAH</td>
            <td style="background-color:yellow;"></td>
            <td style="background-color:yellow;font-weight:bold;">'. number_format($total_infaq, 2, ',', '.') .'</td>
            <td style="background-color:yellow;"></td>
        </tr>
        <tr>
            <td>8</td>
            <td>PENERIMAAN DANA INFAQ/SEDEKAH TIDAK TERIKAT</td>
            <td></td>
            <td>'. number_format($total_zakat01, 2, ',', '.') .'</td>
            <td></td>
        </tr>
        <tr>
            <td>9</td>
            <td>PENERIMAAN DANA INFAQ/SEDEKAH TERIKAT</td>
            <td></td>
            <td>'. number_format($total_zakat03, 2, ',', '.') .'</td>
            <td></td>
        </tr>
        <tr>
            <td>10</td>
            <td>PENERIMAAN DANA INFAQ/SEDEKAH TIDAK TERIKAT VIA UPZ</td>
            <td></td>
            <td>'. number_format($total_zakat02, 2, ',', '.') .'</td>
            <td></td>
        </tr>
        <tr>
            <td>11</td>
            <td>PENERIMAAN DANA INFAQ/SEDEKAH RAMADHAN</td>
            <td></td>
            <td>'. number_format($total_zakat002, 2, ',', '.') .'</td>
            <td></td>
        </tr>
        <tr>
            <td>12</td>
            <td>PENERIMAAN DANA INFAQ/SEDEKAH RAMADHAN VIA UPZ</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td style="background-color:yellow;">13</td>
            <td style="background-color:yellow;">PENERIMAAN DANA CORPORATE SOCIAL RESPONSIBILITY</td>
            <td style="background-color:yellow;"></td>
            <td style="background-color:yellow;"></td>
            <td style="background-color:yellow;"></td>
        </tr>
        <tr>
            <td>14</td>
            <td>PENERIMAAN DANA CSR</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td style="background-color:yellow;">15</td>
            <td style="background-color:yellow;">PENERIMAAN DANA SOSIAL KEAGAMAAN LAINNYA (DSKL) ONBS</td>
            <td style="background-color:yellow;"></td>
            <td style="background-color:yellow;"></td>
            <td style="background-color:yellow;"></td>
        </tr>
        <tr>
            <td>16</td>
            <td>PENEMERIMAAN DANA DSKL LAINNYA (HIBAH, NAZAR, PUSAKA YANG TIDAK MEMILIKI AHLI WARIS, QURBAN, KAFARAT, FIDYAH, DENDA ATAU SITAAN PENGADILAN AGAMA DAN LAIN SEBAGAINYA) ONBS</td>
            <td></td>
            <td>'. number_format($total_zakat003, 2, ',', '.') .'</td>
            <td></td>
        </tr>
        <tr>
            <td>17</td>
            <td>PENERIMAAN DANA DSKL LAINNYA VIA UPZ (ONBS)</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td style="background-color:yellow; font-weight:bold;">18</td>
            <td style="background-color:yellow;font-weight:bold;">PENERIMAAN DANA HIBAH</td>
            <td style="background-color:yellow;font-weight:bold;"></td>
            <td style="background-color:yellow;font-weight:bold;">'. number_format($total_hibah, 2, ',', '.') .'</td>
            <td style="background-color:yellow;font-weight:bold;"></td>
        </tr>
        <tr>
            <td>19</td>
            <td>PENERIMAAN DANA HIBAH APBD</td>
            <td></td>
            <td>'. number_format($total_zakat0001, 2, ',', '.') .'</td>
            <td></td>
        </tr>
        <tr>
            <td>20</td>
            <td>PENERIMAAN DANA HIBAH APBN</td>
            <td></td>
            <td>'. number_format($total_zakat0002, 2, ',', '.') .'</td>
            <td></td>
        </tr>
    </table>';
?>
<script src="timeout.js"></script>
</body>
