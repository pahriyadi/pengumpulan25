<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">
    <style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background-image: url('../../imgs/bgr.jpg');
        background-size: cover;
        background-repeat: no-repeat;
    }

    .container {
      width: 100%;
      max-width: 400px;
      padding: 20px;
      background-color: rgba(255, 255, 255, 0.5);
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    }

    .form-group {
        margin-bottom: 20px;
    }

    .btn-login {
        width: 100%;
    }

    .alert {
        margin-top: 20px;
    }

    @media (max-width: 768px) {
        .container {
            max-width: 300px;
        }
    }
</style>
</head>

<?php
// Koneksi ke database
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Tangkap data dari form login
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk mencari user dengan username dan password yang sesuai
    $login_query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $login_result = $koneksi->query($login_query);
    if ($login_result->num_rows > 0) {
        // Jika data ditemukan, login berhasil
        header("Location:/pengumpulan25/admin/dashboard.php");
        exit();
    } else {
        // Jika data tidak ditemukan, berikan pesan kesalahan
        $error_message = "Username atau password salah!";
    }
}

$koneksi->close();
?>

<body>
    <div class="container">
        <h2 class="text-center">Login</h2>
        <?php if (isset($error_message)) : ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-login">Login</button>
        </form>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="successModalLabel">Login Berhasil!</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Login berhasil!</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="timeout.js"></script>
</body>

</html>
