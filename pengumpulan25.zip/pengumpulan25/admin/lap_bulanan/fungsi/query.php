<?php
function getLaporanZakatMaalPerorangan($koneksi, $bulan, $tahun, $nama = '', $status = '', $metode = '') {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);
    
    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'zakat maal perorangan'
            AND sumber_rekening = 'ntb syariah zakat-006'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
    ";

    if (!empty($nama)) {
        $nama = mysqli_real_escape_string($koneksi, $nama);
        $query .= " AND nama_muzaki LIKE '%$nama%'";
    }

    if (!empty($status)) {
        $status = mysqli_real_escape_string($koneksi, $status);
        $query .= " AND status_muzaki = '$status'";
    }

    if (!empty($metode)) {
        $metode = mysqli_real_escape_string($koneksi, $metode);
        $query .= " AND metode_bayar = '$metode'";
    }

    $query .= " GROUP BY nama_muzaki, tanggal ORDER BY tanggal ASC";

    $result = mysqli_query($koneksi, $query);
    if (!$result) {
        die("Query gagal: " . mysqli_error($koneksi));
    }
    return $result;
}


function getLaporanZakatMaalPeroranganUPZ($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'zakat maal perorangan via upz'
            AND sumber_rekening = 'ntb syariah zakat-006'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanZakatMaalBadan($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'zakat maal badan'
            AND sumber_rekening = 'ntb syariah zakat-006'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanZakatFitrahUPZ($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'zakat fitrah via upz'
            AND sumber_rekening = 'rekening penerimaan lainnya'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanZakatFitrahPerorangan($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'zakat fitrah'
            AND sumber_rekening = 'rekening penerimaan lainnya'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanZakatFitrahOffbs($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'zakat fitrah offbalacesheet'
            AND sumber_rekening = 'rekening penerimaan lainnya'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanInfakTTPeorangan($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'infak/sedekah tidak terikat perorangan'
            AND sumber_rekening = 'ntb syariah infak/sedekah-015'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanInfakTTPeoranganUPZ($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'infak/sedekah tidak terikat perorangan via upz'
            AND sumber_rekening = 'ntb syariah infak/sedekah-015'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanInfakTerikat($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'infak/sedekah terikat'
            AND sumber_rekening = 'ntb syariah infak/sedekah-015'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanInfakPenyaluran($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'infak penyaluran'
            AND sumber_rekening = 'ntb syariah infak/sedekah-015'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanInfakOperasional($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'infak operasional'
            AND sumber_rekening = 'ntb syariah infak/sedekah-015'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanCSR($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'CSR'
            AND sumber_rekening = 'rekening penerimaan lainnya'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanKurban($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'kurban'
            AND sumber_rekening = 'rekening penerimaan lainnya'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanKurbanUPZ($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'kurban via upz'
            AND sumber_rekening = 'rekening penerimaan lainnya'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanFidyah($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'Fidyah'
            AND sumber_rekening = 'ntb syariah zakat-006'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanDSKL($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'DSKL'
            AND sumber_rekening = 'rekening penerimaan lainnya'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanDSKLUPZ($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'DSKL lainnya via upz'
            AND sumber_rekening = 'rekening penerimaan lainnya'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanDanaTitipan($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'dana titipan penyaluran'
            AND sumber_rekening IN ('rekening penerimaan lainnya', 'ntb syariah infak/sedekah-015',
             'ntb syariah zakat-006', 'ntb syariah zakat-019')
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}

function getLaporanAPBD($koneksi, $bulan, $tahun) {
    $bulan = mysqli_real_escape_string($koneksi, $bulan);
    $tahun = mysqli_real_escape_string($koneksi, $tahun);

    $query = "
        SELECT 
            nama_muzaki, 
            status_muzaki, 
            tanggal, 
            SUM(jumlah) AS total_jumlah
        FROM zakat_infaq 
        WHERE 
            pembayaran = 'dana hibah APBD/APBD-P'
            AND sumber_rekening = 'ntb syariah Operasional APBD-018'
            AND MONTH(tanggal) = '$bulan'
            AND YEAR(tanggal) = '$tahun'
        GROUP BY nama_muzaki
        ORDER BY tanggal ASC
    ";

    return mysqli_query($koneksi, $query);
}
?>
