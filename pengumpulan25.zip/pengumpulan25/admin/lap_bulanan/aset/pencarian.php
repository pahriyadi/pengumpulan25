<div class="container">
<div class="non-printable">
    <div class="card">
        <div class="card-header">
        <div class="card-body">
            <form method="POST" action="">
                <div class="form-row align-items-end mb-3">
                    <div class="col">
                        <label for="bulan">Bulan</label>
                        <select name="bulan" class="form-control">
                            <?php for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php if (isset($_POST['bulan']) && $_POST['bulan'] == $i) echo 'selected'; ?>><?php echo date('F', mktime(0, 0, 0, $i, 10)); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col">
                        <label for="tahun">Tahun</label>
                        <input type="number" name="tahun" class="form-control" value="<?php echo isset($_POST['tahun']) ? $_POST['tahun'] : date('Y'); ?>">
                    </div>
                    <div class="col">
                        <label for="nama_muzaki">Nama Muzaki</label>
                        <input type="text" name="nama_muzaki" class="form-control" value="<?php echo isset($_POST['nama_muzaki']) ? $_POST['nama_muzaki'] : ''; ?>">
                    </div>
                    <div class="col">
                        <label for="status_muzaki">Status Muzaki</label>
                        <input type="text" name="status_muzaki" class="form-control" value="<?php echo isset($_POST['status_muzaki']) ? $_POST['status_muzaki'] : ''; ?>">
                    </div>
                    <div class="col">
                        <button type="submit" class="btn btn-primary">Cari</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>
<hr>
</div>
