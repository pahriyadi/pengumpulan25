<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan ZIS</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="icon" href="/pengumpulan/admin/imgs/lobaz.png" type="image/x-icon">
    <style>
        body {
            width: 100%;
            font-family: "montserrat", sans-serif;
            font-size: 14px;
            padding: 5px;
            
        }

        table {
            border-collapse: collapse;
            font-size: 14px;
        }

        th,
        td {
           
            padding: 10px;
            text-transform: uppercase;
            border: 1px solid black;
        }

        th {
            background-color: #fff;
            color: black;
            border: 1px solid black;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
            border: 1px solid black;
        }

        tr:hover {
            background-color: #ddd;
        }

        h1 {
            text-align: center;
            font-size: 20px;
            padding-bottom: 0;
        }

        .ttd {
            margin-top: 20px;
            text-align: right;
            font-size: 15px;
            margin-right: 50px;
        }

        .ttd p {
            margin-bottom: 0.5px;
            font-weight: bold;
        }

        .hidden-button {
            position: absolute;
            top: -9999px;
            left: -9999px;
        }

        @media print {
    body {
        font-size: 14px;
    }

    .printable {
        display: block;
    }

    .non-printable,
    .card-footer {
        display: none;
    }

    @page {
        size: portrait;
    }

    /* Penambahan untuk tabel agar border tebal hitam saat dicetak */
    table, th, td, tr, thead {
        border: 2px solid black !important;
        border-collapse: collapse;
    }

    th, td, tr, thead {
        padding: 6px;
    }

    thead {
        background-color: #f0f0f0;
        -webkit-print-color-adjust: exact; /* untuk background warna di print */
        print-color-adjust: exact;
    }
        }
    </style>
</head>