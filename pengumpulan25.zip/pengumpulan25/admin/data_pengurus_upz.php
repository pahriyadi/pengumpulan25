<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="icon" href="\imgs\lobaz.png" type="image/x-icon">
    <title>upz baznas sumbawa</title>
    <style>
        body {
            width: 100%;
            background: rgb(240, 248, 254);
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
            border-radius: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid black;
        }

        th,
        td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
            border: 1px solid black;
        }

        th {
            background-color: #f2f2f2;
            text-align: center;
        }

        @media screen and (max-width: 600px) {
            table {
                font-size: 12px;
            }
        }

        .kop {
            text-align: center;
            margin: 1px;
        }

        .judul {
            text-align: center;
            margin-bottom: 10px;
        }

        @media print {
            body {
                font-size: 14px;
            }

            .printable {
                display: block;
            }

            .non-printable {
                display: none;
            }

            @page {
                size: portrait;
            }
        }
    </style>
</head>

<body>
    <div class="non-printable">
        <?php include 'navbar.php'; ?>
    </div>

    <div class="container">
        <div class="non-printable">
            <form style="margin-left: 70px; display: flex; margin-bottom: 10px;" action="" method="get">
                <input class="form-control" style="width: 85%; margin-right: 10px;" type="text" name="keyword"
                    value="<?php echo $keyword; ?>" placeholder="Cari data menurut kata kunci....">
                <button class="btn btn-danger" type="submit">Cari</button>
            </form>
        </div>

        <div class="printable">
            <div class="kop">
                <h3>BAZNAS KABUPATEN SUMBAWA</h3>
                <p>Jl. Hasanuddin No. 1 Kelurahan Bugis Sumbawa Besar</p>
                <p>-----------------------------------------------------------------------------------------------</p>
            </div>

            <h3 style="text-align: center;">DAFTAR NAMA PENGURUS UPZ BAZNAS KABUPATEN SUMBAWA</h3>

            <?php
            // Koneksi ke database
            include 'koneksi.php';

            // Fungsi untuk melakukan pencarian berdasarkan semua field
            function searchUPZ($keyword)
            {
                global $koneksi;

                $query = "SELECT * FROM pengurus_upz WHERE username = '$keyword'";
                $result = mysqli_query($koneksi, $query);

                return $result;
            }

            // Inisialisasi variabel pencarian
            $keyword = "";
            if (isset($_GET['keyword'])) {
                $keyword = $_GET['keyword'];
            }

            // Lakukan pencarian jika keyword tidak kosong
            if (!empty($keyword)) {
                $result = searchUPZ($keyword);
            } else {
                // Query untuk menampilkan semua data UPZ
                $query = "SELECT * FROM pengurus_upz";
                $result = mysqli_query($koneksi, $query);
            }
            ?>

            <?php
            $username = ""; // Inisialisasi variabel username

            // Ambil data username dari baris pertama (jika ada)
            if ($row = mysqli_fetch_assoc($result)) {
                $username = $row['username'];
            }
            ?>
            <?php if ($keyword !== ""): ?>
                <h3 style="text-align: center;"><?php echo "Pada " . $username; ?></h3>
            <?php endif; ?>

            <table border="1">
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Nama Pengurus UPZ</th>
                    <th>Jabatan Pengurus UPZ</th>
                    <th>No. Tlp Pengurus UPZ</th>
                    <th>Alamat Pengurus UPZ</th>
                </tr>
                <?php
                $no = 1;
                mysqli_data_seek($result, 0); // Kembalikan pointer data ke awal

                while ($row = mysqli_fetch_assoc($result)) {
                    // Tampilkan data dalam tabel
                    $created_at = $row['created_at'];
                    $kadaluarsa = date('d F Y', strtotime('+5 years', strtotime($created_at)));

                    setlocale(LC_TIME, 'id_ID');
                    $created_at_indonesia = strftime('%d %B %Y', strtotime($created_at));

                    $is_expired = strtotime('+5 years', strtotime($created_at)) < time();

                    // Ganti username dengan nilai pencarian jika ada
                    if (!empty($keyword)) {
                        $username = $keyword;
                    }

                    echo "<tr>
                <td style='text-align: center;'>" . $no++ . "</td>
                <td>" . $row['username'] . "</td>
                <td>" . $row['nama_pengurus_upz'] . "</td>
                <td>" . $row['jabatan_pengurus_upz'] . "</td>
                <td>" . $row['notlp_pengurus_upz'] . "</td>
                <td>" . $row['alamat_pengurus_upz'] . "</td>
            </tr>";
                }
                ?>
            </table><br>

            <p style="margin-left: 700px; font-weight: bold;">Sumbawa Besar, <?php echo date('d F Y'); ?></p>
            <div style="display: flex; margin-left:10px;">
                <div style="margin-left: 100px;">
                    <p style="text-align: center;">Mengetahui,</p>
                    <p style="text-align: center;">Ketua BAZNAS Kab. Sumbawa</p><br><br><br><br>
                    <p style="text-align: center; font-weight: bold;">H. M. Ali Tunru, S.Sos</p>
                </div>

                <div style="margin-left:100px;">
                    <p style="text-align: center;">Wakil Ketua I,</p>
                    <p style="text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
                    <p style="text-align: center; font-weight: bold;">Madroni, SHI</p>
                </div>

                <div style="margin-left:100px;">
                    <p style="text-align: center;">Bidang Pengumpulan,</p>
                    <p style="text-align: center;">BAZNAS Kab. Sumbawa</p><br><br><br><br>
                    <p style="text-align: center; font-weight: bold;">Pahriyadi, S.Ap</p>
                </div>
            </div>
        </div>
    </div>
</body>

<!-- JavaScript Bootstrap -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="timeout.js"></script>

<?php
// Tutup koneksi
mysqli_close($koneksi);
?>
</html>
