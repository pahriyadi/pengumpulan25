<?php
function getQueryLaporanBulanan($bulan, $tahun) {
    return "
        SELECT 
            tanggal,
            nama_muzaki,
            status_muzaki,
            metode_bayar,
            SUM(CASE 
                WHEN pembayaran = 'zakat maal perorangan via upz' THEN jumlah 
                WHEN pembayaran = 'zakat maal perorangan' THEN jumlah 
                WHEN pembayaran = 'zakat maal badan' THEN jumlah 
                WHEN pembayaran = 'zakat fitrah via upz' THEN jumlah 
                WHEN pembayaran = 'zakat fitrah' THEN jumlah 
                ELSE 0 
            END) AS total_zakat,

            SUM(CASE 
                WHEN pembayaran = 'infak/sedekah tidak terikat perorangan' THEN jumlah 
                WHEN pembayaran = 'infak/sedekah tidak terikat perorangan via upz' THEN jumlah 
                WHEN pembayaran = 'infak/sedekah terikat' THEN jumlah 
                WHEN pembayaran = 'infak penyaluran' THEN jumlah 
                WHEN pembayaran = 'infak operasional' THEN jumlah 
                ELSE 0 
            END) AS total_infaq_shadaqah,

            SUM(CASE 
                WHEN pembayaran = 'CSR' THEN jumlah 
                WHEN pembayaran = 'kurban' THEN jumlah 
                WHEN pembayaran = 'kurban via upz' THEN jumlah 
                WHEN pembayaran = 'fidyah' THEN jumlah 
                WHEN pembayaran = 'DSKL' THEN jumlah 
                WHEN pembayaran = 'DSKL lainnya via upz' THEN jumlah 
                ELSE 0 
            END) AS total_lainnya,

            SUM(jumlah) AS total_jumlah

        FROM zakat_infaq
        WHERE sumber_rekening IN (
            'bank ntb syariah zakat-006', 
            'bank ntb syariah zakat baznas-019', 
            'bank ntb syariah infak/sedekah-015', 
            'rekening penerimaan lainnya',
            'bank BRI', 
            'bank BSI zakat', 
            'bank BSI infak'
        )
        AND MONTH(tanggal) = $bulan 
        AND YEAR(tanggal) = $tahun
    ";
}
?>
