<!DOCTYPE html>
<html>

<head>
    <title>Data Dokumen</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">
    <style>
    .hidden-button {
        position: absolute;
        top: -9999px;
        left: -9999px;
    }
    </style>
</head>

<body>
    <?php include 'navbar.php'; ?>

    <div class="container">
        <h2>Arsip Dokumen BAZNAS</h2>
        Masukan semua dokumen penting di dalam tabel ini
        
        <table class="table">
            <thead>
                <tr>
                    <th>Nama Dokumen</th>
                    <th>Jenis File</th>
                    <th>Tanggal Upload</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Koneksi ke database
                include 'koneksi.php';

                if ($koneksi->connect_error) {
                    die("Koneksi gagal: " . $koneksi->connect_error);
                }
                    
                // Mendapatkan nilai pencarian
                $namaDokumen = isset($_POST['name']) ? $_POST['name'] : '';

                // Filter karakter khusus pada nama dokumen untuk mencegah serangan SQL injection
                $namaDokumen = mysqli_real_escape_string($koneksi, $namaDokumen);

                // Mendapatkan data dokumen dari tabel
                $sql = "SELECT id, name, file_type, created_at FROM documents WHERE name LIKE '%$namaDokumen%'";
                $result = $koneksi->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $id = $row["id"];
                        $name = $row["name"];
                        $fileType = $row["file_type"];
                        $createdAt = $row["created_at"];

                        echo "<tr>";
                        echo "<td>$name</td>";
                        echo "<td>$fileType</td>";
                        echo "<td>$createdAt</td>";
                        echo "<td>";
                        echo "<a href='download.php?id=$id' class='btn btn-primary'>Download</a> ";
                        echo "<a href='edit.php?id=$id' class='btn btn-info'>Edit</a> ";
                        echo "<a href='hapus.php?id=$id' class='btn btn-danger'>Hapus</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>Tidak ada data dokumen.</td></tr>";
                }

                $koneksi->close();
                ?>
            </tbody>
        </table>

        <button type="button" class="hidden-button" data-toggle="modal" data-target="#tambahDataModal"
            accesskey="z">Tambah
            Data</button>

        <div class="modal fade" id="tambahDataModal" tabindex="-1" role="dialog" aria-labelledby="tambahDataModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="tambahDataModalLabel">Form Tambah Data Dokumen</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="nama_dokumen">Nama Dokumen:</label>
                                <input type="text" id="nama_dokumen" name="nama_dokumen" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="jenis_file">Jenis File:</label>
                                <select id="jenis_file" name="jenis_file" class="form-control" required>
                                    <option value="PDF">PDF</option>
                                    <option value="Word">Word</option>
                                    <option value="Excel">Excel</option>
                                    <option value="JPG">JPG</option>
                                    <option value="PNG">PNG</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="file_dokumen">Pilih Dokumen:</label>
                                <input type="file" id="file_dokumen" name="file_dokumen" class="form-control-file"
                                    required>
                            </div>

                            <button type="submit" class="btn btn-primary">Tambah Data</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Trigger Button -->
        <button type="button" class="hidden-button" data-toggle="modal" data-target="#filterModal" accesskey="q">Filter
            (Ctrl + Z)</button>

        <!-- Modal untuk mencari data documen -->
        <div class="modal fade" id="filterModal" tabindex="-1" role="dialog" aria-labelledby="filterModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="filterModalLabel">Cari Dokumen BAZNAS</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="file.php" method="POST">
                            <div class="form-group">
                                <label for="nama_muzaki">Nama Dokumen:</label>
                                <input type="text" class="form-control" id="search_input" name="name"
                                    accesskey="n">
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" name="submit" accesskey="f">Filter</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>