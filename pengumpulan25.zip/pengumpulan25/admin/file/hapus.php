<?php
// Koneksi ke database
include 'koneksi.php';

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Mendapatkan ID dari parameter URL
$id = $_GET['id'];

// Menyiapkan pernyataan SQL untuk menghapus dokumen
$stmt = $koneksi->prepare("DELETE FROM documents WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header('Location: index.php');
} else {
    echo "Terjadi kesalahan saat menghapus dokumen: " . $stmt->error;
}

$stmt->close();
$koneksi->close();
?>
