<?php
// Koneksi ke database
include 'koneksi.php';

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Variabel untuk mengontrol kapan menampilkan animasi
$showSpinner = true; // Atur menjadi true sebelum memproses pengunggahan file

// Mengambil informasi file yang diunggah
$file = $_FILES['file_dokumen'];
$fileName = $_FILES['file_dokumen']['name'];
$fileType = pathinfo($fileName, PATHINFO_EXTENSION); // Mendapatkan ekstensi file
$fileTmpName = $_FILES['file_dokumen']['tmp_name'];
$fileSize = $_FILES['file_dokumen']['size'];

// Batasan ukuran maksimal (3 GB)
$maxFileSize = 3 * 1024 * 1024 * 1024; // 3 GB dalam bytes

if ($fileSize > $maxFileSize) {
    echo "Ukuran file terlalu besar. Maksimal ukuran file adalah 3 GB.";
    exit;
}

// Membaca data file
$fileData = file_get_contents($fileTmpName);

// Menyiapkan pernyataan SQL
$stmt = $koneksi->prepare("INSERT INTO documents (name, file_type, file_data) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $fileName, $fileType, $fileData);

// Menjalankan pernyataan SQL
if ($stmt->execute()) {
    $showSpinner = false; // Atur variabel untuk menyembunyikan animasi setelah proses selesai

    // Redirect atau tampilkan pesan sukses
    // Misalnya, jika Anda ingin melakukan redirect ke halaman file.php setelah berhasil
    header('Location: index.php');
} else {
    echo "Terjadi kesalahan saat mengunggah file: " . $stmt->error;
}

$stmt->close();
$koneksi->close();
?>
