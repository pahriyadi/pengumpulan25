<head>
    <title>Contoh Footer Responsif</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        .content {
            min-height: calc(100vh - 100px); /* 100px adalah tinggi footer */
            padding: 20px;
        }

        .footer {
            background-color: #3498db;
            color: #fff;
            padding: 20px;
            text-align: center;
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
        }

        .footer p {
            margin: 0;
        }

        @media (max-width: 768px) {
            .footer {
                position: static;
            }
        }
    </style>
</head>


    <footer class="footer">
        <div class="container">
            <p>&copy; 2023 Baznas Kabupaten Sumbawa. All rights reserved.</p>
        </div>
    </footer>

