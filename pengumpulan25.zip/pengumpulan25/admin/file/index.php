<!DOCTYPE html>
<html>

<head>
    <title>Data Dokumen</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" href="\pengumpulan\admin\imgs\lobaz.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-ixp8RSG//Dx27NDO8DBLSdsDO0tOjXszCkprBqJNAIhB6feqMWx5oC4c3UdqJ/y2Nv68PgNO4Csq0qUVfnSeUg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        .documents-container {
            display: flex;
            flex-wrap: wrap;
        }

        .document {
            width: calc(33.33% - 20px);
            margin: 10px;
            border: 1px solid #ccc;
            padding: 10px;
        }

        .document-info {
            margin-bottom: 10px;
        }

        .document-name {
            font-weight: bold;
        }

        .document-actions {
            display: flex;
        }

        .document-actions a {
            margin-right: 10px;
        }

        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.5);
            z-index: 9999;
            display: none;
            justify-content: center;
            align-items: center;
        }

        .loading-spinner {
            border: 6px solid #f3f3f3;
            border-top: 6px solid #3498db;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style>

</head>

<body>
    <?php include 'navbar.php'; ?>

    <!-- Bagian konten dinamis -->
    <div class="container">
        <h2>Arsip Dokumen BAZNAS</h2>
        Masukan semua dokumen penting di dalam tabel ini

        <div class="card">
            <div class="card-header">Upload dokumen disini</div>
            <div class="card-body">
                <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-group col-md-3">
                            <label for="nama_dokumen">Nama Dokumen:</label>
                            <input type="text" id="nama_dokumen" name="nama_dokumen" class="form-control" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="jenis_file">Jenis File:</label>
                            <select id="jenis_file" name="jenis_file" class="form-control" required>
                                <option value="PDF">PDF</option>
                                <option value="Word">docx</option>
                                <option value="Excel">Excel</option>
                                <option value="JPG">JPG</option>
                                <option value="PNG">PNG</option>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="file_dokumen">Pilih Dokumen:</label>
                            <input type="file" id="file_dokumen" name="file_dokumen" class="form-control-file" required>
                        </div>
                        <div class="form-group col-md-3">
                            <button type="submit" class="btn btn-primary">Tambah Data</button>
                        </div>
                    </div>
                </form>
            </div>

        </div>


        <div class="card">
            <div class="card-header">Daftar Dokumen</div>
            <div class="card-body">
                <div class="documents-container">
                    <?php
                    include 'koneksi.php';

                    if ($koneksi->connect_error) {
                        die("Koneksi gagal: " . $koneksi->connect_error);
                    }

                    $namaDokumen = isset($_POST['name']) ? $_POST['name'] : '';
                    $namaDokumen = mysqli_real_escape_string($koneksi, $namaDokumen);

                    $sql = "SELECT id, name, file_type, created_at FROM documents WHERE name LIKE '%$namaDokumen%'";
                    $result = $koneksi->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $id = $row["id"];
                            $name = $row["name"];
                            $fileType = $row["file_type"];
                            $createdAt = $row["created_at"];

                            // Memilih ikon berdasarkan jenis file
                            $icon = '';
                            if ($fileType == 'PDF') {
                                $icon = 'fa-file-pdf';
                            } elseif ($fileType == 'Word') {
                                $icon = 'fa-file-word';
                            } elseif ($fileType == 'Excel') {
                                $icon = 'fa-file-excel';
                            } elseif ($fileType == 'JPG' || $fileType == 'PNG') {
                                $icon = 'fa-file-image';
                            } else {
                                $icon = 'fa-file'; // Default icon
                            }

                            echo "<div class='document'>";
                            echo "<div class='document-icon'><i class='fas $icon'></i></div>";
                            echo "<div class='document-info'>";
                            echo "<span class='document-name'>$name</span>";
                            echo "<span class='document-type'>$fileType</span>";
                            echo "<span class='document-date'>$createdAt</span>";
                            echo "</div>";
                            echo "<div class='document-actions'>";
                            echo "<a href='download.php?id=$id' class='btn btn-primary'>Download</a>";
                            echo "<a href='edit.php?id=$id' class='btn btn-info'>Edit</a>";
                            echo "<a href='hapus.php?id=$id' class='btn btn-danger'>Hapus</a>";
                            echo "<a href='lihat_file.php?id=$id' class='btn btn-success'>Lihat</a>";
                            echo "</div>";
                            echo "</div>";
                        }
                    } else {
                        echo "<div class='no-documents'>Tidak ada data dokumen.</div>";
                    }

                    $koneksi->close();
                    ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>