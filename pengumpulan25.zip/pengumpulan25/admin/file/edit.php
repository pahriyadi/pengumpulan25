<?php
// Koneksi ke database
include 'koneksi.php';

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Mendapatkan ID dari parameter URL
$id = $_GET['id'];

// Jika form disubmit, proses perubahan data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mendapatkan data yang diubah dari form
    $newName = $_POST['nama_dokumen'];

    // Menyiapkan pernyataan SQL untuk mengupdate nama dokumen
    $stmt = $koneksi->prepare("UPDATE documents SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $newName, $id);

    if ($stmt->execute()) {
        header('Location: index.php');
    } else {
        echo "Terjadi kesalahan saat memperbarui data dokumen: " . $stmt->error;
    }

    $stmt->close();
}

// Mendapatkan data dokumen berdasarkan ID
$stmt = $koneksi->prepare("SELECT name FROM documents WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($name);
$stmt->fetch();

$stmt->close();
$koneksi->close();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Dokumen</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <h2>Edit Dokumen</h2>
    <form action="" method="post">
        <label for="nama_dokumen">Nama Dokumen:</label>
        <input type="text" id="nama_dokumen" name="nama_dokumen" value="<?php echo $name; ?>" required><br><br>
        <input type="submit" value="Simpan">
    </form>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</html>