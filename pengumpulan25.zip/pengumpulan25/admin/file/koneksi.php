<?php
$host = "localhost"; // nama host database
$user = "n1579664_baznassbw"; // nama user database
$password = "kQR*8rgk"; // password database
$database = "n1579664_ozakat"; // nama database

// membuat koneksi ke database
$koneksi = mysqli_connect($host, $user, $password, $database);

// mengecek apakah koneksi berhasil atau tidak
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>