<!DOCTYPE html>
<html>
<head>
    <title>Form Tambah Data Dokumen</title>
</head>
<body>
    <h2>Form Tambah Data Dokumen</h2>
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="nama_dokumen">Nama Dokumen:</label>
        <input type="text" id="nama_dokumen" name="nama_dokumen" required><br><br>
        
        <label for="jenis_file">Jenis File:</label>
        <select id="jenis_file" name="jenis_file" required>
            <option value="PDF">PDF</option>
            <option value="Word">Word</option>
            <option value="Excel">Excel</option>
            <option value="JPG">JPG</option>
            <option value="PNG">PNG</option>
        </select><br><br>
        
        <label for="file_dokumen">Pilih Dokumen:</label>
        <input type="file" id="file_dokumen" name="file_dokumen" required><br><br>
        
        <input type="submit" value="Tambah Data">
    </form>
</body>
</html>
