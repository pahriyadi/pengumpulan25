<?php
// Koneksi ke database
include 'koneksi.php';

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Mendapatkan ID dari parameter URL
$id = $_GET['id'];

// Menyiapkan pernyataan SQL untuk mendapatkan informasi dokumen
$stmt = $koneksi->prepare("SELECT name, file_type, file_data FROM documents WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($name, $fileType, $fileData);
$stmt->fetch();

// Mengatur header untuk tipe konten
header("Content-type: $fileType");
header("Content-Disposition: attachment; filename=$name");

// Menampilkan data file
echo $fileData;

$stmt->close();
$koneksi->close();
?>
